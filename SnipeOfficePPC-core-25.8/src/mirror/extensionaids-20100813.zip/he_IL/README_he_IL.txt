This Hebrew dictionary in Myspell format was generated automatically from
data prepared by the Hspell project:

	http://ivrix.org.il/projects/spell-checker

Hspell version 1.0 was used.

This dictionary is Copyright (C) 2000-2006, Nadav Har'El (nyh@math.technion.ac.il) and Dan Kenigsberg (danken@cs.technion.ac.il).
It is licensed under the GNU General Public License (GPL), the text of which can be found at http://www.gnu.org/licenses/gpl-3.0.txt .

The dictionary was converted to UTF-8 by Alan Yaniger (alan@tkos.co.il) , Sept. 24, 2009.
