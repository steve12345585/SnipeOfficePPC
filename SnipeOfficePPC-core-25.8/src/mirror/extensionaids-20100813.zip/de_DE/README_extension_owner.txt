COMMENT OF THE EXTENSION OWNER
========================================================================================


This extension is based on:

Spell checking:
===============
de-DE_frami spell checking - Version: 2010-03-05
Author: Franz Michael Baumann <frami.baumann@web.de>
License: GNU GPL Version 2 or later or OASIS 0.1

The "frami"-dictionary contains the complete word list of Bj�rn Jacke's "igerman98" 
(Version: 2009-10-06) and numerous supplements by Franz Michael Baumann according to
the reform of 2006-08-01.

Hyphenation:
============
Authors: Marco Huggenberger <marco@by-night.ch> / Daniel Naber <naber at danielnaber de>
Version: 2010-01-13 (bug and license problems in Readme file fixed)
License: GNU LGPL

Thesaurus:
==========
OpenThesaurus - Deutscher Thesaurus - Synonyme und Assoziationen
Version: 2010-05-25
License: GNU LGPL
http://www.openthesaurus.de

Please note:
Even though having built and published the dictionary extension, the extension owner has
no responsibility for maintaining related dictionaries. For contacting the author of 
dictionaries, please read his related README files. Updated extension is intended to be 
published, as soon related dictionaries will have been actualized.

For contacting the extension owner write to:
karl<dot>zeiler<at>t-online.de
