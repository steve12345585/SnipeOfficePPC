Dicionario en Galego para Hunspell
www.mancomun.org coas normas da RAE do 22-05-06
Creado para thunderbird por Frco. Javier Rial Rodr�guez para Mancom�n

1. Copyright
2. Contido

1. Copyright

Liberado faixo os termos da licenza GNU GPL (version 2).

2. Contido

O paquete cont�n o seguinte:

	gl_ES.dic,  diccionario galego.
	gl_ES.aff,  regras para derivar palabras do diccionario galego.
	README-gl-ES.txt, este ficheiro.
