﻿The Slovenian hyphenation rules were created by: Matjaz Vrecko,
MG-SOFT Corp. <matjaz.vrecko@mg-soft.si> and are covered by the
GNU/LGPL and GNU/GPL License and supports Slovenian language (sl_SI).

Slovenske vzorce za deljenje besed je ustvaril Matjaž Vrečko, MG-SOFT Corp.
<matjaz.vrecko@mg-soft.si> in so izdani pod licencama 
GNU/LGPL in GNU/GPL ter so namenjeni podpori za slovenski jezik (sl_SI).

For use in OpenOffice.org adapted by/Za rabo v OpenOffice.org priredil:
Robert Ludvik, <r@aufbix.org>

The OpenOffice.org extension by/Razširitev OpenOffice.org pripravil:
Martin Srebotnjak, <miles@filmsi.net>

HYPH sl SI hyph_sl_SI

=======================================================================
http://external.openoffice.org/ form data:

Product Name: Slovenian patterns for hyphenation
Product Version: 1.0
Vendor or Owner Name: Matjaz Vrecko
Vendor or Owner Contact: matjaz.vrecko@mg-soft.si
OpenOffice.org Contact: bobe@openoffice.org
Date of First Use / date of License: 1990/October 2006
URL for Product Information:
http://vlado.fmf.uni-lj.si/texceh/kako/delilni/delilni.htm
URL for License: http://www.gnu.org/copyleft/lgpl.html
Purpose: Patterns for Slovenian hyphenation
Type of Encryption: none
Binary or Source Code: Source
=======================================================================

For the avoidance of doubt, except that if any license choice other
than GPL or LGPL is available it will apply instead, Sun elects to use
only the Lesser General Public License version 2.1 (LGPLv2) at this
time for any software where a choice of LGPL license versions is made
available with the language indicating that LGPLv2.1 or any later
version may be used, or where a choice of which version of the LGPL is
applied is otherwise unspecified.
