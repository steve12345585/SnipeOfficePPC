Licenca:
Sve datoteke su izdate pod Gnuovom Slabijom opštom javnom licencom (GNU LGPL) kako je objavljuje Zadužbina za Slobodni Softver (FSF); bilo verzije 3 te Licence, bilo (po vašem nahođenju) koje novije verzije.

Saznajte više o srpskoj lokalizaciji OpenOffice.org paketa na:
http://sr.openoffice.org
http://ooo.matf.bg.ac.rs

Realizovali članovi srpskog OpenOffice.org tima za lokalizaciju.

Autori proširenja su Miloš Popović (gpopac@gmail.com) i Goran Rakić (grakic@devbase.net) kao prirodni nastavak na rs4ooo paket koji je izdao Aleksandar Urošević (urke.dd@urosevic.net).

Provera pisanja je zasnovana na srpskom GNU aspel rečniku koji je priredio Goran Rakić (http://srpski.org/aspell).

Rastavljanje na slogove je preuzeto iz srpskih obrazaca za rastavljanje za TeX koje je priredio Dejan Muhamedagić (dejan@hello-penguin.com) izdanje 2.02 od 22. juna 2008. godine.

