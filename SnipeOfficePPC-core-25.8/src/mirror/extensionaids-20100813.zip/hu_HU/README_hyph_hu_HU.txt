OOo Huhyphn - magyar elválasztási szótár kiegészítve a kettőzött többjegyű
mássalhangzók és a Magyar Ispell helyesírási szótár csak Unicode
karakterkészlettel leírható idegen szavainak elválasztásának képességével.

A legteljesebb magyar elválasztási mintagyűjtemény TeX, OpenOffice.org és
valamennyi kibővített LibHnj könyvtárat
(L. http://www.sourceforge.net/project/hunspell) használó program számára.

A Huhyphn szótárat Nagy Bence <gimb (at) freemail (dot) hu> készítette.
Változatszáma: v20060713.
Honlap: http://www.tipogral.hu
Licenc: GPL v2, 2006

A kibővítés Németh László <nemeth (at) OOo> munkája.
A kiadás dátuma: 2010-05-06
Honlap: http://sourceforge.net/project/magyarispell (OOo Huhyphn package)
Licenc:  MPL/GPL/LGPL

------------------------------------------------------------------
Hungarian hyphenation patterns with non-standard hyphenation patch

The most complete collection of hyphenation patterns for TeX, OpenOffice.org
and all programs using the LibHnj library.

Language: Hungarian (hu HU)
Origin:   http://www.tipogral.hu/ 
License:  GPL v2 license, 2006
Author:   Nagy Bence <gimb (at) freemail (dot) hu>
Version:  v20060713
Patch:    László Németh <nemeth (at) OOo>
          source: http://sourceforge.net/project/magyarispell (OOo huhyphn)
          license: MPL/GPL/LGPL
Patch version: 2010-05-06
