_______________________________________________________________________________

   Dictionnaire des synonymes fran�ais myThes
   version 2.2
   
   Dicollecte: http://dicollecte.free.fr/
   
   Licence: LGPL
_______________________________________________________________________________

   Ce dictionnaire des synonymes est encore en cours d'�laboration.
   Actuellement, seules les graphies pr�c�dant la r�forme de l'orthographe
   de 1990 sont reconnues.

_______________________________________________________________________________

   Historique
_______________________________________________________________________________

 * myThes est le format de thesaurus de OOo � partir de la version 2.0
   developp� par Kevin Hendricks sur la base des travaux de l'universit� de
   Priceton: http://lingucomponent.openoffice.org/thesaurus.html

   Cette version est incompatible avec le format binaire utilis� pour les
   versions 1.x d'OpenOffice.org.

 * La conception du thesaurus dans le format 1.0 a �t� initi�e par Frederic Labb�.

 * La version 2 a �t� transform�e par la soci�t� Indesko.
   Laurent Godard (lgodard@indesko.com)
   
   Les cat�gories grammaticales des mots ont �t� compl�t�es sur la base de
   InDico, dictionnaire taggu� developp� par InDesko et issu de la
   transformation des listes de l'abu (http://abu.cnam.fr/)

 * La version 2.1 n'apporte que la reconnaissance des mots avec ligatures.
   Ce thesaurus a �t� d�couvert ici:
   http://user.services.openoffice.org/fr/forum/viewtopic.php?p=15783#15783

 * La version 2.2 est g�n�r�e � partir de la base de donn�es de Dicollecte.
   Pour l'instant, seules quelques modifications ont �t� faites.
_______________________________________________________________________________