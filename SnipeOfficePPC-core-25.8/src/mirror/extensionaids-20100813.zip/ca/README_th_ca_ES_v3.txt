
Diccionari català de sinònims myThes per a l'OpenOffice.org 2.1 (o superior)
________________________________________________________________________________

Autor: Joan Montané (joan@montane.cat) i molts altres col·laboradors.
Aquest diccionari de sinònims està en fase experimental.
Els resultats que ofereix han de considerar-se orientatius i potencialment erronis.

myThes és el format del tesaure de l'OOo a partir de la versió 2.0, desenvolupat per en Kevin Hendricks,
basat en treballs de la Universitast de Priceton
http://lingucomponent.openoffice.org/thesaurus.html

Aquesta versió és incompatible amb el format binari utilitzat per les versions 1.x de l'Openoffice.org

Les primeres dades d'aquest diccionari s'ha obtingut de la versió retallada del wordnet català
del projecte Freeling, http://garraf.epsevg.upc.es/freeling/ sota llicència GPL o LGPL, segons la versió



________________________________________________________________________________

INSTAL·LACIÓ
________________________________________________________________________________

1.- Tanqueu l'OpenOffice.org

2.- Copieu els fitxers th_ca_ES_v2.dat i th_ca_ES_v2.idx al directori
<ooo>/share/dict/ooo. On <ooo> indica el directori d'instal·lació de l'OpenOffice.org,

    En els sistemes Linux aquest directori normalment es troba a
    "/usr/local" o "/opt".
    En els sistemes Windows aquest directori normalment es troba a
    "C:\Archivos de Programa" o "C:\Program Files".
 
3.- Editeu el fitxer "dictionary.lst" que es troba al mateix directori i 
afegiu la línia THES ca ES th_ca_ES_v2, deseu els canvis al fitxer.

4.- Finalitzat.

________________________________________________________________________________

LLICÈNCIA
________________________________________________________________________________

Aquest diccionari es troba sota llicència dual GPL/LGPL
http://www.gnu.org/copyleft/gpl.html
http://www.gnu.org/copyleft/lgpl.html


Copyright (C) 2009 Joan Montané <joan@montane.cat>
