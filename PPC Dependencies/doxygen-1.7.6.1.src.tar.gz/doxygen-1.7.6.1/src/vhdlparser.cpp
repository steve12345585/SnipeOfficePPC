/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0

/* Substitute the variable and function names.  */
#define yyparse vhdlScanYYparse
#define yylex   vhdlScanYYlex
#define yyerror vhdlScanYYerror
#define yylval  vhdlScanYYlval
#define yychar  vhdlScanYYchar
#define yydebug vhdlScanYYdebug
#define yynerrs vhdlScanYYnerrs


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     t_ABSTRLIST = 258,
     t_CHARLIST = 259,
     t_DIGIT = 260,
     t_STRING = 261,
     t_LETTER = 262,
     t_ACCESS = 263,
     t_AFTER = 264,
     t_ALIAS = 265,
     t_ALL = 266,
     t_AND = 267,
     t_ARCHITECTURE = 268,
     t_ARRAY = 269,
     t_ASSERT = 270,
     t_ATTRIBUTE = 271,
     t_BEGIN = 272,
     t_BLOCK = 273,
     t_BODY = 274,
     t_BUFFER = 275,
     t_BUS = 276,
     t_CASE = 277,
     t_COMPONENT = 278,
     t_CONFIGURATION = 279,
     t_CONSTANT = 280,
     t_DISCONNECT = 281,
     t_DOWNTO = 282,
     t_ELSE = 283,
     t_ELSIF = 284,
     t_END = 285,
     t_ENTITY = 286,
     t_EXIT = 287,
     t_FILE = 288,
     t_FOR = 289,
     t_FUNCTION = 290,
     t_GENERATE = 291,
     t_GENERIC = 292,
     t_GUARDED = 293,
     t_IF = 294,
     t_IN = 295,
     t_INOUT = 296,
     t_IS = 297,
     t_LABEL = 298,
     t_LIBRARY = 299,
     t_LINKAGE = 300,
     t_LOOP = 301,
     t_MAP = 302,
     t_NAND = 303,
     t_NEW = 304,
     t_NEXT = 305,
     t_NOR = 306,
     t_NULL = 307,
     t_OF = 308,
     t_ON = 309,
     t_OPEN = 310,
     t_OR = 311,
     t_OTHERS = 312,
     t_OUT = 313,
     t_PACKAGE = 314,
     t_PORT = 315,
     t_PROCEDURE = 316,
     t_PROCESS = 317,
     t_RANGE = 318,
     t_RECORD = 319,
     t_REGISTER = 320,
     t_REPORT = 321,
     t_RETURN = 322,
     t_SELECT = 323,
     t_SEVERITY = 324,
     t_SIGNAL = 325,
     t_SUBTYPE = 326,
     t_THEN = 327,
     t_TO = 328,
     t_TRANSPORT = 329,
     t_TYPE = 330,
     t_UNITS = 331,
     t_UNTIL = 332,
     t_USE = 333,
     t_VARIABLE = 334,
     t_WAIT = 335,
     t_WHEN = 336,
     t_WHILE = 337,
     t_WITH = 338,
     t_XOR = 339,
     t_IMPURE = 340,
     t_PURE = 341,
     t_GROUP = 342,
     t_POSTPONED = 343,
     t_SHARED = 344,
     t_XNOR = 345,
     t_SLL = 346,
     t_SRA = 347,
     t_SLA = 348,
     t_SRL = 349,
     t_ROR = 350,
     t_ROL = 351,
     t_UNAFFECTED = 352,
     t_ASSUME_GUARANTEE = 353,
     t_ASSUME = 354,
     t_CONTEXT = 355,
     t_COVER = 356,
     t_DEFAULT = 357,
     t_FAIRNESS = 358,
     t_FORCE = 359,
     t_INERTIAL = 360,
     t_LITERAL = 361,
     t_PARAMETER = 362,
     t_PROTECTED = 363,
     t_PROPERTY = 364,
     t_REJECT = 365,
     t_RELEASE = 366,
     t_RESTRICT = 367,
     t_RESTRICT_GUARANTEE = 368,
     t_SEQUENCE = 369,
     t_STRONG = 370,
     t_VMODE = 371,
     t_VPROP = 372,
     t_VUNIT = 373,
     t_SLSL = 374,
     t_SRSR = 375,
     t_QQ = 376,
     t_QGT = 377,
     t_QLT = 378,
     t_QG = 379,
     t_QL = 380,
     t_QEQU = 381,
     t_QNEQU = 382,
     t_GESym = 383,
     t_GTSym = 384,
     t_LESym = 385,
     t_LTSym = 386,
     t_NESym = 387,
     t_EQSym = 388,
     t_Ampersand = 389,
     t_Minus = 390,
     t_Plus = 391,
     MED_PRECEDENCE = 392,
     t_REM = 393,
     t_MOD = 394,
     t_Slash = 395,
     t_Star = 396,
     MAX_PRECEDENCE = 397,
     t_NOT = 398,
     t_ABS = 399,
     t_DoubleStar = 400,
     t_Apostrophe = 401,
     t_LeftParen = 402,
     t_RightParen = 403,
     t_Comma = 404,
     t_VarAsgn = 405,
     t_Colon = 406,
     t_Semicolon = 407,
     t_Arrow = 408,
     t_Box = 409,
     t_Bar = 410,
     t_Dot = 411,
     t_Q = 412,
     t_At = 413,
     t_Neg = 414,
     t_LEFTBR = 415,
     t_RIGHTBR = 416,
     t_ToolDir = 417
   };
#endif
/* Tokens.  */
#define t_ABSTRLIST 258
#define t_CHARLIST 259
#define t_DIGIT 260
#define t_STRING 261
#define t_LETTER 262
#define t_ACCESS 263
#define t_AFTER 264
#define t_ALIAS 265
#define t_ALL 266
#define t_AND 267
#define t_ARCHITECTURE 268
#define t_ARRAY 269
#define t_ASSERT 270
#define t_ATTRIBUTE 271
#define t_BEGIN 272
#define t_BLOCK 273
#define t_BODY 274
#define t_BUFFER 275
#define t_BUS 276
#define t_CASE 277
#define t_COMPONENT 278
#define t_CONFIGURATION 279
#define t_CONSTANT 280
#define t_DISCONNECT 281
#define t_DOWNTO 282
#define t_ELSE 283
#define t_ELSIF 284
#define t_END 285
#define t_ENTITY 286
#define t_EXIT 287
#define t_FILE 288
#define t_FOR 289
#define t_FUNCTION 290
#define t_GENERATE 291
#define t_GENERIC 292
#define t_GUARDED 293
#define t_IF 294
#define t_IN 295
#define t_INOUT 296
#define t_IS 297
#define t_LABEL 298
#define t_LIBRARY 299
#define t_LINKAGE 300
#define t_LOOP 301
#define t_MAP 302
#define t_NAND 303
#define t_NEW 304
#define t_NEXT 305
#define t_NOR 306
#define t_NULL 307
#define t_OF 308
#define t_ON 309
#define t_OPEN 310
#define t_OR 311
#define t_OTHERS 312
#define t_OUT 313
#define t_PACKAGE 314
#define t_PORT 315
#define t_PROCEDURE 316
#define t_PROCESS 317
#define t_RANGE 318
#define t_RECORD 319
#define t_REGISTER 320
#define t_REPORT 321
#define t_RETURN 322
#define t_SELECT 323
#define t_SEVERITY 324
#define t_SIGNAL 325
#define t_SUBTYPE 326
#define t_THEN 327
#define t_TO 328
#define t_TRANSPORT 329
#define t_TYPE 330
#define t_UNITS 331
#define t_UNTIL 332
#define t_USE 333
#define t_VARIABLE 334
#define t_WAIT 335
#define t_WHEN 336
#define t_WHILE 337
#define t_WITH 338
#define t_XOR 339
#define t_IMPURE 340
#define t_PURE 341
#define t_GROUP 342
#define t_POSTPONED 343
#define t_SHARED 344
#define t_XNOR 345
#define t_SLL 346
#define t_SRA 347
#define t_SLA 348
#define t_SRL 349
#define t_ROR 350
#define t_ROL 351
#define t_UNAFFECTED 352
#define t_ASSUME_GUARANTEE 353
#define t_ASSUME 354
#define t_CONTEXT 355
#define t_COVER 356
#define t_DEFAULT 357
#define t_FAIRNESS 358
#define t_FORCE 359
#define t_INERTIAL 360
#define t_LITERAL 361
#define t_PARAMETER 362
#define t_PROTECTED 363
#define t_PROPERTY 364
#define t_REJECT 365
#define t_RELEASE 366
#define t_RESTRICT 367
#define t_RESTRICT_GUARANTEE 368
#define t_SEQUENCE 369
#define t_STRONG 370
#define t_VMODE 371
#define t_VPROP 372
#define t_VUNIT 373
#define t_SLSL 374
#define t_SRSR 375
#define t_QQ 376
#define t_QGT 377
#define t_QLT 378
#define t_QG 379
#define t_QL 380
#define t_QEQU 381
#define t_QNEQU 382
#define t_GESym 383
#define t_GTSym 384
#define t_LESym 385
#define t_LTSym 386
#define t_NESym 387
#define t_EQSym 388
#define t_Ampersand 389
#define t_Minus 390
#define t_Plus 391
#define MED_PRECEDENCE 392
#define t_REM 393
#define t_MOD 394
#define t_Slash 395
#define t_Star 396
#define MAX_PRECEDENCE 397
#define t_NOT 398
#define t_ABS 399
#define t_DoubleStar 400
#define t_Apostrophe 401
#define t_LeftParen 402
#define t_RightParen 403
#define t_Comma 404
#define t_VarAsgn 405
#define t_Colon 406
#define t_Semicolon 407
#define t_Arrow 408
#define t_Box 409
#define t_Bar 410
#define t_Dot 411
#define t_Q 412
#define t_At 413
#define t_Neg 414
#define t_LEFTBR 415
#define t_RIGHTBR 416
#define t_ToolDir 417




/* Copy the first part of user declarations.  */


#include <stdio.h>
#include <qcstring.h>
#include <qstringlist.h>

#ifndef YYSTYPE
typedef int YYSTYPE;
#endif
	
struct  YYMM
{
  int itype;	
  QCString qstr;
};	

// define struct instead of union
#define YYSTYPE YYMM

#include "membergroup.h"
#include "vhdldocgen.h"
#include "doxygen.h"
#include "searchindex.h"
#include "vhdlscanner.h"
#include "commentscan.h"
#include "entry.h"

//-----------------------------variables ---------------------------------------------------------------------------
static MyParserVhdl* myconv=0;

static struct s_contVhdl s_str;
static QList<Entry>instFiles;
static int yyLineNr;
static Entry* lastCompound;
static Entry* currentCompound;
static Entry* lastEntity;
static Entry* current;
static Entry* tempEntry;
static Entry* current_root;
static QCString compSpec;
static QCString currName;
static int levelCounter;
static QCString confName;
static QCString genLabels;

static QList<ConfNode> configL;
static ConfNode* currNode;

static int currP=0;

//---------------------------- function --------------------------------------------------------------------------------

int vhdlScanYYlex ();
void vhdlScanYYerror (char const *);

static void addVhdlType(const QCString &name,int startLine,
                        int section,int spec,
			const char* args,const char* type,
			Protection prot=Public);
static void addCompInst(char *n, char* instName,char* comp,int line);

static void newEntry();
static void initEntry(Entry *e);
static bool isFuncProcProced();
static void popConfig();
static void pushLabel(QCString label);
static void popLabel();
static void addConfigureNode(const char* a,const char*b, 
                         bool isRoot,bool isLeave,bool inlineConf=FALSE);
static bool addLibUseClause(const QCString &type);
static bool isFuncProcProced();
static void initEntry(Entry *e);
static void addProto(const char *s1,const char *s2,const char *s3,
                     const char *s4,const char *s5,const char *s6);
static bool findInstant(QCString inst);
static void createFunction(const QCString &impure,int spec,
                           const QCString &fname);

void newVhdlEntry()
{
  newEntry();
}

Entry* getCurrentVhdlEntry()
{
  return current;
}

void initVhdlParser()
{
  lastCompound=0;
  lastEntity=0;
  currentCompound=0;
  lastEntity=0;
  current_root=s_str.root;
  current=new Entry();
  initEntry(current);
}

QList<Entry> & getVhdlInstList()
{
  return instFiles;
}




/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */


#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  6
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   2758

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  163
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  392
/* YYNRULES -- Number of rules.  */
#define YYNRULES  915
/* YYNRULES -- Number of states.  */
#define YYNSTATES  1582

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   417

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
     155,   156,   157,   158,   159,   160,   161,   162
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     7,     9,    12,    14,    16,    18,
      20,    22,    24,    26,    28,    30,    33,    34,    36,    39,
      41,    45,    48,    49,    52,    54,    56,    58,    60,    62,
      64,    66,    68,    70,    74,    78,    80,    84,    89,    97,
     101,   102,   104,   105,   108,   109,   112,   114,   115,   116,
     121,   122,   123,   128,   132,   140,   146,   152,   153,   155,
     158,   160,   161,   164,   166,   172,   173,   181,   187,   188,
     190,   192,   195,   196,   199,   201,   207,   213,   217,   218,
     220,   223,   225,   226,   228,   231,   233,   236,   238,   241,
     245,   251,   257,   262,   263,   265,   268,   272,   273,   276,
     278,   280,   282,   284,   286,   288,   290,   292,   294,   296,
     298,   300,   302,   304,   306,   308,   310,   312,   314,   316,
     318,   320,   322,   324,   326,   328,   330,   332,   334,   336,
     338,   340,   342,   344,   346,   348,   351,   353,   355,   357,
     359,   361,   363,   365,   367,   369,   371,   373,   375,   377,
     379,   381,   383,   385,   387,   389,   391,   393,   395,   397,
     399,   401,   403,   405,   407,   409,   411,   413,   415,   417,
     419,   421,   423,   425,   427,   429,   434,   436,   438,   441,
     442,   447,   454,   455,   462,   464,   467,   470,   472,   473,
     476,   478,   480,   482,   491,   498,   499,   501,   503,   505,
     508,   511,   514,   515,   518,   520,   525,   529,   530,   533,
     536,   538,   540,   543,   551,   552,   555,   556,   558,   560,
     561,   563,   564,   566,   568,   570,   572,   574,   576,   581,
     582,   585,   588,   593,   597,   601,   602,   605,   608,   612,
     614,   616,   618,   620,   624,   626,   628,   630,   632,   635,
     637,   639,   641,   643,   645,   647,   649,   651,   655,   659,
     663,   667,   671,   675,   679,   683,   687,   691,   695,   699,
     703,   706,   708,   711,   714,   717,   720,   724,   729,   733,
     737,   741,   745,   749,   753,   757,   761,   765,   769,   773,
     777,   781,   785,   789,   793,   797,   801,   805,   808,   811,
     813,   817,   819,   821,   823,   825,   829,   831,   833,   835,
     837,   839,   842,   845,   849,   851,   853,   855,   857,   859,
     863,   865,   867,   869,   871,   873,   875,   877,   879,   883,
     885,   887,   889,   892,   895,   897,   901,   906,   910,   914,
     918,   921,   927,   932,   936,   942,   946,   951,   955,   958,
     959,   961,   962,   964,   968,   970,   973,   974,   977,   980,
     982,   984,   986,   991,   996,  1000,  1001,  1004,  1006,  1008,
    1010,  1012,  1014,  1016,  1018,  1020,  1022,  1024,  1029,  1030,
    1033,  1036,  1043,  1046,  1048,  1049,  1052,  1054,  1057,  1062,
    1070,  1071,  1074,  1077,  1081,  1086,  1087,  1089,  1096,  1097,
    1100,  1102,  1107,  1110,  1114,  1120,  1124,  1127,  1129,  1130,
    1132,  1136,  1139,  1143,  1144,  1146,  1149,  1154,  1155,  1158,
    1161,  1163,  1165,  1167,  1171,  1173,  1177,  1179,  1181,  1188,
    1189,  1192,  1200,  1201,  1204,  1205,  1207,  1214,  1222,  1223,
    1226,  1228,  1230,  1232,  1235,  1237,  1239,  1241,  1243,  1251,
    1258,  1260,  1262,  1263,  1266,  1275,  1282,  1283,  1288,  1289,
    1291,  1299,  1302,  1304,  1306,  1307,  1310,  1313,  1319,  1327,
    1332,  1335,  1337,  1339,  1340,  1343,  1346,  1348,  1350,  1352,
    1354,  1356,  1358,  1360,  1362,  1364,  1366,  1368,  1370,  1372,
    1374,  1376,  1378,  1380,  1382,  1384,  1386,  1393,  1401,  1402,
    1406,  1411,  1412,  1415,  1420,  1426,  1428,  1430,  1432,  1437,
    1443,  1446,  1448,  1449,  1452,  1454,  1456,  1458,  1460,  1462,
    1464,  1466,  1468,  1483,  1484,  1486,  1487,  1490,  1492,  1493,
    1498,  1503,  1504,  1509,  1510,  1515,  1516,  1521,  1522,  1524,
    1526,  1530,  1533,  1535,  1539,  1541,  1543,  1545,  1546,  1556,
    1557,  1566,  1575,  1585,  1586,  1590,  1594,  1596,  1601,  1604,
    1608,  1610,  1615,  1618,  1622,  1624,  1629,  1632,  1637,  1640,
    1644,  1646,  1652,  1654,  1658,  1664,  1667,  1669,  1670,  1673,
    1676,  1679,  1680,  1683,  1686,  1688,  1691,  1693,  1695,  1698,
    1699,  1701,  1705,  1707,  1708,  1710,  1719,  1724,  1725,  1728,
    1733,  1734,  1737,  1739,  1742,  1743,  1752,  1757,  1761,  1762,
    1768,  1772,  1774,  1777,  1780,  1784,  1788,  1790,  1791,  1792,
    1804,  1809,  1810,  1814,  1815,  1817,  1818,  1820,  1821,  1823,
    1826,  1828,  1829,  1833,  1837,  1840,  1841,  1844,  1847,  1849,
    1850,  1853,  1855,  1857,  1860,  1862,  1864,  1866,  1868,  1870,
    1872,  1874,  1876,  1879,  1881,  1883,  1885,  1888,  1890,  1896,
    1902,  1903,  1906,  1907,  1910,  1911,  1913,  1914,  1916,  1918,
    1929,  1941,  1948,  1949,  1952,  1954,  1959,  1964,  1965,  1968,
    1969,  1971,  1981,  1989,  1990,  1993,  1994,  1997,  2002,  2011,
    2012,  2014,  2015,  2017,  2018,  2021,  2026,  2027,  2030,  2031,
    2033,  2036,  2039,  2043,  2044,  2046,  2051,  2057,  2064,  2070,
    2072,  2074,  2077,  2079,  2082,  2084,  2087,  2091,  2096,  2102,
    2103,  2106,  2107,  2110,  2111,  2114,  2116,  2120,  2124,  2128,
    2131,  2132,  2134,  2142,  2143,  2147,  2148,  2152,  2160,  2166,
    2167,  2170,  2172,  2173,  2176,  2178,  2180,  2182,  2184,  2192,
    2193,  2195,  2196,  2200,  2205,  2209,  2214,  2222,  2225,  2230,
    2233,  2237,  2239,  2241,  2243,  2247,  2248,  2252,  2253,  2257,
    2260,  2263,  2265,  2267,  2269,  2271,  2275,  2284,  2292,  2300,
    2303,  2304,  2306,  2308,  2312,  2314,  2316,  2318,  2320,  2322,
    2324,  2326,  2331,  2336,  2337,  2340,  2342,  2344,  2347,  2349,
    2351,  2353,  2355,  2361,  2367,  2368,  2371,  2373,  2376,  2380,
    2382,  2386,  2394,  2401,  2403,  2406,  2408,  2411,  2413,  2415,
    2417,  2425,  2434,  2441,  2449,  2458,  2465,  2466,  2470,  2473,
    2476,  2478,  2482,  2484,  2487,  2490,  2500,  2509,  2518,  2524,
    2529,  2532,  2534,  2537,  2541,  2543,  2545,  2553,  2562,  2569,
    2577,  2582,  2587,  2590,  2600,  2609,  2611,  2613,  2622,  2623,
    2625,  2631,  2633,  2638,  2648,  2649,  2651,  2653,  2655,  2659,
    2661,  2667,  2672,  2677,  2683,  2686,  2694,  2700,  2702,  2707,
    2709,  2711,  2713,  2715,  2719,  2727,  2734,  2736,  2738,  2739,
    2742,  2745,  2746,  2748,  2754,  2759,  2765,  2772,  2776,  2779,
    2786,  2788,  2790,  2792,  2794,  2796,  2798,  2802,  2805,  2810,
    2814,  2816,  2821,  2824,  2828,  2831
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     164,     0,    -1,   165,    -1,   166,    -1,   174,    -1,   166,
     174,    -1,   489,    -1,   491,    -1,   492,    -1,   493,    -1,
     490,    -1,   172,    -1,    52,    -1,   493,    -1,   489,    -1,
     171,   489,    -1,    -1,   492,    -1,   492,   489,    -1,   489,
      -1,   173,   149,   489,    -1,   175,   176,    -1,    -1,   175,
     177,    -1,   181,    -1,   196,    -1,   202,    -1,   191,    -1,
     208,    -1,   505,    -1,   509,    -1,   178,    -1,   179,    -1,
      44,   173,   152,    -1,    78,   180,   152,    -1,   268,    -1,
     180,   149,   268,    -1,   182,     1,   458,   152,    -1,   182,
     189,   187,   185,   184,   458,   152,    -1,    31,   489,    42,
      -1,    -1,   489,    -1,    -1,    17,   356,    -1,    -1,   185,
     186,    -1,   215,    -1,    -1,    -1,    60,   188,   236,   152,
      -1,    -1,    -1,    37,   190,   236,   152,    -1,    37,     1,
     152,    -1,   192,   194,    17,   356,    30,   193,   152,    -1,
     192,     1,    30,   193,   152,    -1,    13,   489,    53,   489,
      42,    -1,    -1,   489,    -1,    13,   489,    -1,    13,    -1,
      -1,   194,   195,    -1,   216,    -1,   198,     1,    30,   199,
     152,    -1,    -1,   198,   200,   463,    30,   199,   152,   197,
      -1,    24,   489,    53,   489,    42,    -1,    -1,   489,    -1,
      24,    -1,    24,   489,    -1,    -1,   200,   201,    -1,   222,
      -1,   203,     1,    30,   204,   152,    -1,   203,   205,    30,
     204,   152,    -1,    59,   489,    42,    -1,    -1,   489,    -1,
      59,   489,    -1,    59,    -1,    -1,   207,    -1,   205,   206,
      -1,   218,    -1,   545,   152,    -1,   545,    -1,   545,   544,
      -1,   545,   544,   152,    -1,   209,     1,    30,   210,   152,
      -1,   209,   211,    30,   210,   152,    -1,    59,    19,   489,
      42,    -1,    -1,   489,    -1,    59,    19,    -1,    59,    19,
     489,    -1,    -1,   211,   212,    -1,   219,    -1,   202,    -1,
     509,    -1,   208,    -1,   510,    -1,   284,    -1,   308,    -1,
     321,    -1,   333,    -1,   330,    -1,   224,    -1,   179,    -1,
     214,    -1,   232,    -1,   340,    -1,   341,    -1,   336,    -1,
     323,    -1,   326,    -1,   484,    -1,   483,    -1,   213,    -1,
     214,    -1,   232,    -1,   460,    -1,   340,    -1,   341,    -1,
     473,    -1,   336,    -1,   323,    -1,   326,    -1,   484,    -1,
     483,    -1,   213,    -1,   554,    -1,   216,    -1,   217,   216,
      -1,   214,    -1,   460,    -1,   340,    -1,   341,    -1,   336,
      -1,   323,    -1,   326,    -1,   484,    -1,   483,    -1,   202,
      -1,   509,    -1,   510,    -1,   214,    -1,   232,    -1,   326,
      -1,   484,    -1,   483,    -1,   340,    -1,   341,    -1,   213,
      -1,   214,    -1,   232,    -1,   340,    -1,   341,    -1,   326,
      -1,   484,    -1,   483,    -1,   213,    -1,   214,    -1,   232,
      -1,   340,    -1,   341,    -1,   326,    -1,   484,    -1,   483,
      -1,   213,    -1,   341,    -1,   179,    -1,   483,    -1,    78,
     118,   173,   152,    -1,    86,    -1,    85,    -1,   225,   152,
      -1,    -1,    61,   489,   226,   231,    -1,   223,    35,   167,
     230,    67,   267,    -1,    -1,    35,   167,   227,   230,    67,
     267,    -1,   545,    -1,   545,   544,    -1,   107,   236,    -1,
     236,    -1,    -1,   228,   229,    -1,   229,    -1,   228,    -1,
     230,    -1,   225,    42,   234,    17,   418,    30,   233,   152,
      -1,   225,    42,     1,    30,   233,   152,    -1,    -1,   167,
      -1,    35,    -1,    61,    -1,    61,   489,    -1,    35,   489,
      -1,    35,     6,    -1,    -1,   234,   235,    -1,   220,    -1,
     147,   239,   237,   148,    -1,   147,     1,   148,    -1,    -1,
     237,   238,    -1,   152,   239,    -1,   543,    -1,   537,    -1,
     243,   489,    -1,   243,   173,   151,   242,   309,   241,   240,
      -1,    -1,   150,   255,    -1,    -1,    20,    -1,    21,    -1,
      -1,   244,    -1,    -1,   328,    -1,    40,    -1,    58,    -1,
      41,    -1,    20,    -1,    45,    -1,   147,   251,   246,   148,
      -1,    -1,   246,   247,    -1,   149,   251,    -1,   147,   252,
     249,   148,    -1,   147,     1,   148,    -1,   147,    55,   148,
      -1,    -1,   249,   250,    -1,   149,   252,    -1,   253,   153,
     254,    -1,   254,    -1,   154,    -1,   102,    -1,   255,    -1,
     283,   153,   255,    -1,   318,    -1,   265,    -1,   255,    -1,
      55,    -1,   105,   255,    -1,   257,    -1,   258,    -1,    91,
      -1,    92,    -1,    93,    -1,    94,    -1,    95,    -1,    96,
      -1,   258,   256,   258,    -1,   258,    12,   258,    -1,   258,
      84,   258,    -1,   258,    56,   258,    -1,   258,    51,   258,
      -1,   258,    90,   258,    -1,   258,    48,   258,    -1,   257,
      48,   258,    -1,   257,    51,   258,    -1,   257,    90,   258,
      -1,   257,    12,   258,    -1,   257,    56,   258,    -1,   257,
      84,   258,    -1,   121,   264,    -1,   264,    -1,   136,   264,
      -1,   135,   264,    -1,   144,   264,    -1,   143,   264,    -1,
     264,   145,   264,    -1,   135,   264,   145,   264,    -1,   258,
     139,   258,    -1,   258,   138,   258,    -1,   258,   134,   258,
      -1,   258,   141,   258,    -1,   258,   136,   258,    -1,   258,
     135,   258,    -1,   258,   130,   258,    -1,   258,   128,   258,
      -1,   258,   131,   258,    -1,   258,   129,   258,    -1,   258,
     133,   258,    -1,   258,   132,   258,    -1,   258,   140,   258,
      -1,   258,   127,   258,    -1,   258,   126,   258,    -1,   258,
     125,   258,    -1,   258,   124,   258,    -1,   258,   123,   258,
      -1,   258,   122,   258,    -1,   135,   261,    -1,   136,   261,
      -1,   261,    -1,   259,   260,   261,    -1,   134,    -1,   135,
      -1,   136,    -1,   263,    -1,   263,   262,   263,    -1,   141,
      -1,   138,    -1,   139,    -1,   140,    -1,   264,    -1,   144,
     264,    -1,   143,   264,    -1,   264,   145,   264,    -1,   265,
      -1,   168,    -1,   273,    -1,   275,    -1,   276,    -1,   147,
     255,   148,    -1,   267,    -1,   266,    -1,   546,    -1,   491,
      -1,   272,    -1,   270,    -1,   489,    -1,   268,    -1,   265,
     156,   269,    -1,   167,    -1,   493,    -1,    11,    -1,   267,
     248,    -1,   266,   248,    -1,   146,    -1,   267,   271,   489,
      -1,   272,   147,   255,   148,    -1,   266,   271,   489,    -1,
     267,   271,    63,    -1,   266,   271,    63,    -1,   274,   148,
      -1,   147,   280,   153,   255,   148,    -1,   147,   279,   149,
     279,    -1,   274,   149,   279,    -1,   267,   146,   147,   255,
     148,    -1,   267,   146,   273,    -1,    49,   267,   267,   278,
      -1,    49,   267,   277,    -1,    49,   275,    -1,    -1,   248,
      -1,    -1,   248,    -1,   280,   153,   255,    -1,   255,    -1,
     283,   281,    -1,    -1,   281,   282,    -1,   155,   283,    -1,
     255,    -1,   318,    -1,    57,    -1,    75,   489,     1,   152,
      -1,    75,   489,   285,   152,    -1,    75,     1,   152,    -1,
      -1,    42,   286,    -1,   287,    -1,   313,    -1,   290,    -1,
     296,    -1,   300,    -1,   302,    -1,   306,    -1,   307,    -1,
     494,    -1,   499,    -1,   147,   169,   288,   148,    -1,    -1,
     288,   289,    -1,   149,   169,    -1,   313,    76,   294,   292,
      30,   291,    -1,    76,   489,    -1,    76,    -1,    -1,   292,
     293,    -1,   295,    -1,   489,   152,    -1,   489,   133,   170,
     152,    -1,    14,   147,   299,   297,   148,    53,   309,    -1,
      -1,   297,   298,    -1,   149,   299,    -1,   267,    63,   154,
      -1,    14,   314,    53,   309,    -1,    -1,   489,    -1,    64,
     305,   303,    30,    64,   301,    -1,    -1,   303,   304,    -1,
     305,    -1,   173,   151,   309,   152,    -1,     8,   309,    -1,
      33,    53,   267,    -1,    71,   489,    42,   309,   152,    -1,
      71,     1,   152,    -1,   267,   310,    -1,   311,    -1,    -1,
     248,    -1,   267,   267,   313,    -1,   267,   313,    -1,   267,
     267,   312,    -1,    -1,   248,    -1,    63,   319,    -1,   147,
     317,   315,   148,    -1,    -1,   315,   316,    -1,   149,   317,
      -1,   309,    -1,   319,    -1,   311,    -1,   255,   320,   255,
      -1,   272,    -1,   259,   320,   259,    -1,    73,    -1,    27,
      -1,    25,   173,   151,   309,   322,   152,    -1,    -1,   150,
     255,    -1,    70,   173,   151,   309,   325,   324,   152,    -1,
      -1,   150,   255,    -1,    -1,   329,    -1,    79,   173,   151,
     309,   327,   152,    -1,    89,    79,   173,   151,   309,   327,
     152,    -1,    -1,   150,   255,    -1,    25,    -1,    70,    -1,
      79,    -1,    89,    79,    -1,    33,    -1,    75,    -1,    21,
      -1,    65,    -1,    10,   331,   332,    42,   265,   511,   152,
      -1,    10,   331,   332,    42,     1,   152,    -1,   489,    -1,
     491,    -1,    -1,   151,   309,    -1,    33,   173,   151,   309,
      42,   335,   255,   152,    -1,    33,   173,   151,   489,   334,
     152,    -1,    -1,    55,   255,    42,   255,    -1,    -1,   244,
      -1,    26,   337,   151,   267,     9,   255,   152,    -1,   265,
     338,    -1,    57,    -1,    11,    -1,    -1,   338,   339,    -1,
     149,   265,    -1,    16,   489,   151,   267,   152,    -1,    16,
     489,    53,   342,    42,   255,   152,    -1,   343,   511,   151,
     346,    -1,   167,   344,    -1,    57,    -1,    11,    -1,    -1,
     344,   345,    -1,   149,   167,    -1,    31,    -1,    13,    -1,
      59,    -1,    24,    -1,    23,    -1,    43,    -1,    75,    -1,
      71,    -1,    61,    -1,    35,    -1,    70,    -1,    79,    -1,
      25,    -1,    87,    -1,    33,    -1,    76,    -1,   106,    -1,
     114,    -1,   109,    -1,   348,    -1,    39,   255,    36,   398,
     350,   349,    -1,    39,   452,   255,    36,   398,   350,   349,
      -1,    -1,    28,    36,   398,    -1,    28,   452,    36,   398,
      -1,    -1,   350,   351,    -1,    29,   255,    36,   398,    -1,
      29,   452,   255,    36,   398,    -1,   354,    -1,   354,    -1,
     355,    -1,    34,   489,    40,   317,    -1,    34,   452,   489,
      40,   317,    -1,    82,   255,    -1,   357,    -1,    -1,   357,
     358,    -1,   359,    -1,   360,    -1,   378,    -1,   379,    -1,
     380,    -1,   374,    -1,   399,    -1,   405,    -1,   489,   151,
      18,   369,   368,   366,   364,   362,    17,   356,    30,    18,
     361,   152,    -1,    -1,   489,    -1,    -1,   362,   363,    -1,
     216,    -1,    -1,    60,   236,   152,   365,    -1,    60,    47,
     245,   152,    -1,    -1,    37,   236,   152,   367,    -1,    -1,
      37,    47,   245,   152,    -1,    -1,   147,   255,   148,   369,
      -1,    -1,    42,    -1,   489,    -1,   370,   156,   489,    -1,
     370,   372,    -1,   370,    -1,   147,   489,   148,    -1,    24,
      -1,    31,    -1,    23,    -1,    -1,   489,   151,   265,   375,
      37,    47,   245,   377,   152,    -1,    -1,   489,   151,   265,
     376,    60,    47,   245,   152,    -1,   489,   151,   373,   371,
      60,    47,   245,   152,    -1,   489,   151,   373,   371,    37,
      47,   245,   377,   152,    -1,    -1,    60,    47,   245,    -1,
     489,   151,   423,    -1,   423,    -1,   489,   151,    88,   423,
      -1,    88,   423,    -1,   489,   151,   447,    -1,   447,    -1,
     489,   151,    88,   447,    -1,    88,   447,    -1,   489,   151,
     381,    -1,   381,    -1,   489,   151,    88,   381,    -1,    88,
     381,    -1,   489,   151,    88,   393,    -1,    88,   393,    -1,
     489,   151,   393,    -1,   393,    -1,   389,   130,   390,   382,
     152,    -1,   383,    -1,   383,    81,   255,    -1,   383,    81,
     255,    28,   382,    -1,   386,   384,    -1,    97,    -1,    -1,
     384,   385,    -1,   149,   386,    -1,   255,   387,    -1,    -1,
       9,   255,    -1,    52,   388,    -1,    52,    -1,     9,   255,
      -1,   265,    -1,   273,    -1,   392,   391,    -1,    -1,    74,
      -1,   110,   255,   105,    -1,   105,    -1,    -1,    38,    -1,
      83,   255,    68,   389,   130,   390,   394,   152,    -1,   395,
     383,    81,   280,    -1,    -1,   395,   396,    -1,   383,    81,
     280,   149,    -1,    -1,   217,    17,    -1,    17,    -1,   397,
     356,    -1,    -1,   489,   151,   400,   352,    36,   397,   356,
     401,    -1,   404,    30,   403,   152,    -1,    30,   403,   152,
      -1,    -1,   489,   151,   402,   347,   401,    -1,   489,   151,
     515,    -1,    36,    -1,    36,   489,    -1,    30,   152,    -1,
      30,   489,   152,    -1,   489,   151,   406,    -1,   406,    -1,
      -1,    -1,   410,   407,    62,   414,   412,    17,   418,    30,
     409,   152,   408,    -1,     1,    30,   409,   152,    -1,    -1,
     410,    62,   411,    -1,    -1,    88,    -1,    -1,   489,    -1,
      -1,    42,    -1,   412,   413,    -1,   221,    -1,    -1,   147,
      11,   148,    -1,   147,   415,   148,    -1,   265,   416,    -1,
      -1,   416,   417,    -1,   149,   265,    -1,   419,    -1,    -1,
     419,   420,    -1,   421,    -1,   423,    -1,   452,   423,    -1,
     428,    -1,   432,    -1,   435,    -1,   439,    -1,   443,    -1,
     446,    -1,   447,    -1,   448,    -1,   452,   450,    -1,   450,
      -1,   451,    -1,   454,    -1,   452,   454,    -1,   422,    -1,
     442,    66,   255,   424,   152,    -1,    15,   255,   425,   424,
     152,    -1,    -1,    69,   255,    -1,    -1,    66,   255,    -1,
      -1,   157,    -1,    -1,   157,    -1,   489,    -1,    22,   426,
     255,    42,   431,   429,    30,    22,   427,   152,    -1,   452,
      22,   426,   255,    42,   431,   429,    30,    22,   427,   152,
      -1,    22,     1,    30,    22,   427,   152,    -1,    -1,   429,
     430,    -1,   431,    -1,    81,   280,   153,   418,    -1,    32,
     434,   433,   152,    -1,    -1,    81,   255,    -1,    -1,   489,
      -1,    39,   255,    72,   418,   437,   436,    30,    39,   152,
      -1,    39,   255,    72,     1,    30,    39,   152,    -1,    -1,
      28,   418,    -1,    -1,   437,   438,    -1,    29,   255,    72,
     418,    -1,   442,   441,    46,   418,    30,    46,   440,   152,
      -1,    -1,   489,    -1,    -1,   353,    -1,    -1,   489,   151,
      -1,    50,   445,   444,   152,    -1,    -1,    81,   255,    -1,
      -1,   489,    -1,    52,   152,    -1,   265,   152,    -1,    67,
     449,   152,    -1,    -1,   255,    -1,   389,   130,   383,   152,
      -1,   389,   130,   530,   383,   152,    -1,   389,   130,   104,
     529,   255,   152,    -1,   389,   130,   111,   529,   152,    -1,
     523,    -1,   519,    -1,   453,   152,    -1,   531,    -1,   452,
     533,    -1,   533,    -1,   489,   151,    -1,   389,   150,   255,
      -1,   452,   389,   150,   255,    -1,    80,   457,   456,   455,
     152,    -1,    -1,    34,   255,    -1,    -1,    77,   255,    -1,
      -1,    54,   415,    -1,    30,    -1,    30,    23,   183,    -1,
      30,    13,   183,    -1,    30,    31,   183,    -1,    30,   489,
      -1,    -1,    42,    -1,    23,   489,   459,   462,   461,   458,
     152,    -1,    -1,    60,   236,   152,    -1,    -1,    37,   236,
     152,    -1,    34,   468,   466,   464,    30,    34,   152,    -1,
      34,     1,    30,    34,   152,    -1,    -1,   464,   465,    -1,
     469,    -1,    -1,   466,   467,    -1,   179,    -1,   265,    -1,
     463,    -1,   470,    -1,    34,   475,   472,   471,    30,    34,
     152,    -1,    -1,   463,    -1,    -1,   479,   478,   152,    -1,
      78,   118,   173,   152,    -1,    78,   477,   152,    -1,    34,
     475,   474,   152,    -1,    34,   475,   474,   152,    30,    34,
     152,    -1,    78,   477,    -1,    78,   118,   173,   152,    -1,
     479,   478,    -1,   476,   151,   255,    -1,   173,    -1,    11,
      -1,    57,    -1,   480,   479,   478,    -1,    -1,    60,    47,
     245,    -1,    -1,    37,    47,   245,    -1,    31,   265,    -1,
      24,   267,    -1,    55,    -1,   489,    -1,   493,    -1,   481,
      -1,   482,   149,   481,    -1,    87,   489,   151,   488,   147,
     482,   148,   152,    -1,    87,   489,    42,   147,   487,   148,
     152,    -1,    87,   489,    42,   147,     1,   152,   148,    -1,
     346,   486,    -1,    -1,   154,    -1,   485,    -1,   487,   149,
     485,    -1,   489,    -1,   491,    -1,     7,    -1,     5,    -1,
       6,    -1,     3,    -1,     4,    -1,   108,   495,    30,   497,
      -1,   108,     1,    30,   497,    -1,    -1,   495,   496,    -1,
     498,    -1,   108,    -1,   108,   489,    -1,   179,    -1,   341,
      -1,   224,    -1,   510,    -1,   108,    19,   500,    30,   502,
      -1,   108,    19,     1,    30,   502,    -1,    -1,   500,   501,
      -1,   503,    -1,   108,    19,    -1,   108,    19,   489,    -1,
     220,    -1,   100,   180,   152,    -1,   100,   489,    42,   507,
      30,   506,   152,    -1,   100,   489,    42,    30,   506,   152,
      -1,   100,    -1,   100,   489,    -1,   508,    -1,   507,   508,
      -1,   179,    -1,   178,    -1,   504,    -1,    59,   489,    42,
      49,   370,   511,   152,    -1,    59,   489,    42,    49,   370,
     511,   544,   152,    -1,    59,     1,   489,    42,    49,   152,
      -1,    35,   489,    42,    49,   370,   511,   152,    -1,    35,
     489,    42,    49,   370,   511,   544,   152,    -1,    35,   489,
      42,    49,     1,   152,    -1,    -1,   160,   512,   161,    -1,
     160,   161,    -1,    67,   267,    -1,   513,    -1,   513,    67,
     267,    -1,   267,    -1,   513,   514,    -1,   149,   267,    -1,
      22,   255,    36,   517,   518,    30,    36,   403,   152,    -1,
      22,   255,    36,   517,    30,    36,   403,   152,    -1,    22,
       1,    36,     1,    30,    36,   403,   152,    -1,    81,   452,
     280,   153,   398,    -1,    81,   280,   153,   398,    -1,   517,
     516,    -1,   516,    -1,    30,   152,    -1,    30,   489,   152,
      -1,   520,    -1,   522,    -1,   389,   130,   386,    81,   255,
     521,   152,    -1,   389,   130,   530,   386,    81,   255,   521,
     152,    -1,   389,   130,   386,    81,   255,   152,    -1,   389,
     130,   530,   386,    81,   255,   152,    -1,   389,   130,     1,
     152,    -1,    28,   255,    81,   255,    -1,    28,   255,    -1,
     389,   130,   104,   529,   255,    81,   255,   532,   152,    -1,
     389,   130,   104,   529,   255,    81,   255,   152,    -1,   524,
      -1,   528,    -1,    83,   255,    68,   426,   389,   130,   525,
     526,    -1,    -1,   530,    -1,   386,    81,   280,   149,   526,
      -1,   527,    -1,   386,    81,   280,   152,    -1,    83,   255,
      68,   426,   389,   130,   104,   529,   534,    -1,    -1,    40,
      -1,    58,    -1,    74,    -1,   110,   255,   105,    -1,   105,
      -1,   453,    81,   255,   532,   152,    -1,   453,    81,   255,
     152,    -1,    28,   255,    81,   255,    -1,   532,    28,   255,
      81,   255,    -1,    28,   255,    -1,    83,   255,    68,   426,
     536,   150,   534,    -1,   255,    81,   280,   149,   534,    -1,
     535,    -1,   255,    81,   280,   152,    -1,   265,    -1,   273,
      -1,   538,    -1,   539,    -1,    61,   489,   542,    -1,   223,
      35,   540,   542,    67,   267,   541,    -1,    35,   540,   542,
      67,   267,   541,    -1,   489,    -1,   491,    -1,    -1,    42,
     489,    -1,    42,   154,    -1,    -1,   107,    -1,   107,   147,
     239,   237,   148,    -1,   147,   239,   237,   148,    -1,    59,
     489,    42,    49,   370,    -1,    59,   489,    42,    49,   370,
     544,    -1,    37,    47,   245,    -1,    37,   236,    -1,   119,
     547,   548,   151,   309,   120,    -1,    25,    -1,    70,    -1,
      79,    -1,   549,    -1,   550,    -1,   553,    -1,   156,   552,
     489,    -1,   156,   489,    -1,   159,   156,   552,   489,    -1,
     159,   156,   489,    -1,   489,    -1,   489,   147,   255,   148,
      -1,   551,   156,    -1,   552,   551,   156,    -1,   158,   370,
      -1,   162,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   335,   335,   338,   340,   341,   344,   345,   348,   349,
     350,   351,   352,   355,   356,   358,   360,   361,   363,   365,
     366,   373,   375,   376,   378,   379,   380,   381,   382,   383,
     384,   387,   388,   391,   397,   409,   410,   416,   418,   421,
     431,   432,   435,   436,   438,   439,   442,   444,   445,   445,
     447,   448,   448,   449,   454,   455,   457,   466,   467,   468,
     469,   471,   472,   474,   476,   477,   477,   483,   489,   490,
     491,   492,   493,   494,   495,   497,   498,   499,   519,   520,
     521,   522,   524,   525,   526,   527,   529,   530,   531,   532,
     534,   535,   536,   543,   544,   545,   546,   549,   550,   551,
     559,   560,   561,   562,   565,   566,   567,   568,   569,   570,
     571,   573,   574,   575,   576,   577,   578,   579,   580,   581,
     582,   585,   586,   587,   588,   589,   590,   591,   592,   593,
     594,   595,   596,   597,   598,   599,   602,   603,   604,   605,
     606,   607,   608,   609,   610,   611,   612,   613,   615,   616,
     617,   618,   619,   620,   621,   622,   624,   625,   626,   627,
     628,   629,   630,   631,   633,   634,   635,   636,   637,   638,
     639,   640,   642,   643,   644,   645,   650,   651,   653,   655,
     655,   656,   658,   657,   668,   669,   671,   672,   674,   675,
     676,   677,   679,   681,   685,   689,   690,   691,   692,   693,
     694,   695,   698,   700,   701,   707,   708,   709,   710,   711,
     714,   715,   716,   717,   733,   734,   735,   736,   737,   738,
     739,   740,   741,   743,   744,   745,   746,   747,   749,   750,
     751,   752,   754,   760,   761,   763,   764,   765,   767,   768,
     769,   770,   773,   774,   775,   777,   779,   780,   781,   789,
     790,   792,   793,   794,   795,   796,   797,   799,   800,   801,
     802,   803,   804,   805,   806,   807,   808,   809,   810,   811,
     818,   819,   820,   821,   822,   823,   824,   825,   829,   830,
     831,   832,   833,   834,   835,   836,   837,   838,   839,   840,
     841,   842,   843,   844,   845,   846,   847,   851,   852,   853,
     854,   856,   857,   858,   861,   862,   865,   866,   867,   868,
     870,   871,   872,   873,   876,   877,   878,   879,   880,   881,
     884,   885,   886,   887,   888,   889,   891,   892,   894,   896,
     897,   898,   900,   901,   904,   907,   908,   909,   910,   911,
     913,   914,   917,   918,   921,   922,   925,   926,   927,   928,
     929,   930,   931,   938,   940,   942,   943,   944,   945,   947,
     948,   949,   954,   955,   959,   961,   962,   964,   965,   966,
     967,   968,   969,   970,   971,   972,   973,   976,   977,   978,
     979,   981,   990,   991,   994,   995,   996,   998,  1000,  1002,
    1012,  1013,  1014,  1016,  1018,  1020,  1021,  1023,  1035,  1036,
    1040,  1042,  1044,  1046,  1052,  1056,  1057,  1058,  1059,  1060,
    1062,  1063,  1064,  1065,  1066,  1068,  1072,  1073,  1074,  1075,
    1078,  1079,  1081,  1082,  1084,  1085,  1088,  1089,  1095,  1101,
    1102,  1104,  1109,  1110,  1111,  1112,  1118,  1122,  1127,  1128,
    1130,  1131,  1132,  1133,  1134,  1135,  1137,  1138,  1140,  1145,
    1147,  1148,  1150,  1151,  1155,  1160,  1166,  1167,  1170,  1171,
    1173,  1175,  1176,  1177,  1178,  1179,  1180,  1186,  1191,  1197,
    1199,  1200,  1201,  1202,  1203,  1204,  1206,  1207,  1208,  1209,
    1210,  1211,  1212,  1213,  1214,  1215,  1216,  1217,  1218,  1219,
    1220,  1221,  1222,  1223,  1224,  1233,  1236,  1237,  1239,  1240,
    1241,  1242,  1243,  1244,  1245,  1247,  1249,  1250,  1252,  1253,
    1255,  1261,  1262,  1263,  1264,  1266,  1267,  1268,  1269,  1270,
    1271,  1272,  1274,  1277,  1278,  1279,  1280,  1281,  1282,  1283,
    1285,  1286,  1287,  1288,  1289,  1290,  1291,  1292,  1293,  1295,
    1296,  1299,  1300,  1302,  1304,  1305,  1306,  1308,  1308,  1312,
    1312,  1317,  1321,  1325,  1326,  1328,  1329,  1331,  1332,  1334,
    1335,  1337,  1338,  1341,  1342,  1344,  1345,  1347,  1348,  1350,
    1351,  1354,  1356,  1357,  1358,  1360,  1361,  1362,  1363,  1364,
    1366,  1367,  1368,  1369,  1370,  1373,  1375,  1376,  1378,  1380,
    1381,  1382,  1383,  1385,  1386,  1388,  1390,  1391,  1392,  1393,
    1395,  1396,  1397,  1403,  1405,  1405,  1409,  1410,  1412,  1412,
    1415,  1417,  1418,  1422,  1423,  1427,  1435,  1442,  1443,  1442,
    1447,  1450,  1451,  1453,  1454,  1456,  1457,  1459,  1460,  1461,
    1462,  1463,  1464,  1465,  1467,  1468,  1469,  1470,  1476,  1477,
    1478,  1479,  1481,  1482,  1483,  1484,  1485,  1486,  1487,  1488,
    1489,  1490,  1491,  1492,  1493,  1494,  1495,  1496,  1500,  1502,
    1503,  1504,  1505,  1506,  1508,  1509,  1511,  1512,  1513,  1515,
    1516,  1518,  1519,  1520,  1521,  1523,  1525,  1526,  1527,  1528,
    1529,  1531,  1532,  1533,  1534,  1535,  1536,  1537,  1539,  1540,
    1541,  1542,  1543,  1544,  1545,  1547,  1548,  1549,  1550,  1551,
    1553,  1555,  1557,  1558,  1559,  1561,  1562,  1563,  1564,  1565,
    1566,  1571,  1572,  1573,  1574,  1576,  1577,  1578,  1580,  1581,
    1582,  1583,  1584,  1585,  1586,  1592,  1593,  1594,  1595,  1596,
    1598,  1599,  1601,  1606,  1607,  1608,  1609,  1611,  1616,  1617,
    1618,  1622,  1623,  1624,  1628,  1630,  1639,  1643,  1647,  1652,
    1653,  1654,  1656,  1657,  1658,  1663,  1664,  1666,  1667,  1668,
    1670,  1678,  1679,  1680,  1682,  1687,  1689,  1691,  1693,  1696,
    1698,  1700,  1703,  1704,  1707,  1708,  1711,  1718,  1724,  1725,
    1727,  1728,  1730,  1731,  1734,  1735,  1737,  1743,  1749,  1754,
    1759,  1769,  1770,  1772,  1773,  1774,  1775,  1776,  1778,  1779,
    1780,  1781,  1783,  1784,  1786,  1787,  1788,  1790,  1791,  1793,
    1801,  1803,  1804,  1806,  1807,  1809,  1810,  1812,  1813,  1814,
    1816,  1817,  1818,  1820,  1821,  1822,  1824,  1825,  1826,  1830,
    1831,  1832,  1834,  1835,  1836,  1838,  1839,  1840,  1842,  1843,
    1844,  1845,  1847,  1848,  1850,  1851,  1853,  1854,  1856,  1857,
    1858,  1860,  1861,  1863,  1864,  1866,  1867,  1869,  1872,  1873,
    1875,  1876,  1878,  1880,  1883,  1884,  1885,  1887,  1888,  1889,
    1891,  1892,  1894,  1895,  1896,  1898,  1900,  1901,  1903,  1905,
    1906,  1908,  1909,  1911,  1912,  1913,  1916,  1917,  1920,  1921,
    1922,  1924,  1925,  1926,  1927,  1929,  1930,  1932,  1935,  1937,
    1939,  1940,  1941,  1943,  1944,  1945,  1948,  1949,  1951,  1952,
    1954,  1955,  1958,  1959,  1961,  1963
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "t_ABSTRLIST", "t_CHARLIST", "t_DIGIT",
  "t_STRING", "t_LETTER", "t_ACCESS", "t_AFTER", "t_ALIAS", "t_ALL",
  "t_AND", "t_ARCHITECTURE", "t_ARRAY", "t_ASSERT", "t_ATTRIBUTE",
  "t_BEGIN", "t_BLOCK", "t_BODY", "t_BUFFER", "t_BUS", "t_CASE",
  "t_COMPONENT", "t_CONFIGURATION", "t_CONSTANT", "t_DISCONNECT",
  "t_DOWNTO", "t_ELSE", "t_ELSIF", "t_END", "t_ENTITY", "t_EXIT", "t_FILE",
  "t_FOR", "t_FUNCTION", "t_GENERATE", "t_GENERIC", "t_GUARDED", "t_IF",
  "t_IN", "t_INOUT", "t_IS", "t_LABEL", "t_LIBRARY", "t_LINKAGE", "t_LOOP",
  "t_MAP", "t_NAND", "t_NEW", "t_NEXT", "t_NOR", "t_NULL", "t_OF", "t_ON",
  "t_OPEN", "t_OR", "t_OTHERS", "t_OUT", "t_PACKAGE", "t_PORT",
  "t_PROCEDURE", "t_PROCESS", "t_RANGE", "t_RECORD", "t_REGISTER",
  "t_REPORT", "t_RETURN", "t_SELECT", "t_SEVERITY", "t_SIGNAL",
  "t_SUBTYPE", "t_THEN", "t_TO", "t_TRANSPORT", "t_TYPE", "t_UNITS",
  "t_UNTIL", "t_USE", "t_VARIABLE", "t_WAIT", "t_WHEN", "t_WHILE",
  "t_WITH", "t_XOR", "t_IMPURE", "t_PURE", "t_GROUP", "t_POSTPONED",
  "t_SHARED", "t_XNOR", "t_SLL", "t_SRA", "t_SLA", "t_SRL", "t_ROR",
  "t_ROL", "t_UNAFFECTED", "t_ASSUME_GUARANTEE", "t_ASSUME", "t_CONTEXT",
  "t_COVER", "t_DEFAULT", "t_FAIRNESS", "t_FORCE", "t_INERTIAL",
  "t_LITERAL", "t_PARAMETER", "t_PROTECTED", "t_PROPERTY", "t_REJECT",
  "t_RELEASE", "t_RESTRICT", "t_RESTRICT_GUARANTEE", "t_SEQUENCE",
  "t_STRONG", "t_VMODE", "t_VPROP", "t_VUNIT", "t_SLSL", "t_SRSR", "t_QQ",
  "t_QGT", "t_QLT", "t_QG", "t_QL", "t_QEQU", "t_QNEQU", "t_GESym",
  "t_GTSym", "t_LESym", "t_LTSym", "t_NESym", "t_EQSym", "t_Ampersand",
  "t_Minus", "t_Plus", "MED_PRECEDENCE", "t_REM", "t_MOD", "t_Slash",
  "t_Star", "MAX_PRECEDENCE", "t_NOT", "t_ABS", "t_DoubleStar",
  "t_Apostrophe", "t_LeftParen", "t_RightParen", "t_Comma", "t_VarAsgn",
  "t_Colon", "t_Semicolon", "t_Arrow", "t_Box", "t_Bar", "t_Dot", "t_Q",
  "t_At", "t_Neg", "t_LEFTBR", "t_RIGHTBR", "t_ToolDir", "$accept",
  "start", "design_file", "design_unit_list", "designator", "literal",
  "enumeration_literal", "physical_literal", "physical_literal_1",
  "physical_literal_no_default", "idf_list", "design_unit", "context_list",
  "lib_unit", "context_item", "lib_clause", "use_clause", "sel_list",
  "entity_decl", "entity_start", "entity_decl_5", "entity_decl_4",
  "entity_decl_3", "entity_decl_6", "entity_decl_2", "@1", "entity_decl_1",
  "@2", "arch_body", "arch_start", "arch_body_2", "arch_body_1",
  "arch_body_3", "config_decl", "@3", "config_start", "config_decl_2",
  "config_decl_1", "config_decl_3", "package_decl", "package_start",
  "package_decl_2", "package_decl_1", "package_decl_3", "package_decl_22",
  "package_body", "pack_body_start", "package_body_2", "package_body_1",
  "package_body_3", "common_decltve_item_1", "common_decltve_item",
  "entity_decltve_item", "block_decltve_item", "block_declarative_part",
  "package_decltve_item", "package_body_decltve_item",
  "subprog_decltve_item", "procs_decltve_item", "config_decltve_item",
  "func_prec", "subprog_decl", "subprog_spec", "@4", "@5",
  "subprog_spec_22", "subprog_spec_33", "subprog_spec_2", "subprog_spec_1",
  "subprog_body", "subprog_body_2", "subprog_body_1", "subprog_body_3",
  "interf_list", "interf_list_1", "interf_list_2", "interf_element",
  "interf_element_4", "interf_element_3", "interf_element_2",
  "interf_element_1", "mode", "association_list", "association_list_1",
  "association_list_2", "gen_association_list", "gen_association_list_1",
  "gen_association_list_2", "association_element",
  "gen_association_element", "formal_part", "actual_part", "expr",
  "shift_op", "and_relation", "relation", "simple_exp", "adding_op",
  "term", "multiplying_operator", "factor", "primary", "name", "name2",
  "mark", "sel_name", "suffix", "ifts_name", "sigma", "attribute_name",
  "aggregate", "element_association_list2", "qualified_expr", "allocator",
  "allocator_2", "allocator_1", "element_association", "choices",
  "choices_1", "choices_2", "choice", "type_decl", "type_decl_1",
  "type_definition", "enumeration_type_definition",
  "enumeration_type_definition_1", "enumeration_type_definition_2",
  "physical_type_definition", "unit_stat", "physical_type_definition_1",
  "physical_type_definition_2", "base_unit_decl", "secondary_unit_decl",
  "unconstrained_array_definition", "unconstrained_array_definition_1",
  "unconstrained_array_definition_2", "index_subtype_definition",
  "constrained_array_definition", "record_type_simple_name",
  "record_type_definition", "record_type_definition_1",
  "record_type_definition_2", "element_decl", "access_type_definition",
  "file_type_definition", "subtype_decl", "subtype_indic",
  "subtype_indic_1", "subtype_indic1", "subtype_indic1_1",
  "range_constraint", "index_constraint", "index_constraint_1",
  "index_constraint_2", "discrete_range", "discrete_range1", "range_spec",
  "direction", "constant_decl", "constant_decl_1", "signal_decl",
  "signal_decl_2", "signal_decl_1", "variable_decl", "variable_decl_1",
  "object_class", "signal_kind", "alias_decl", "alias_name_stat",
  "alias_spec", "file_decl", "fi_dec", "file_decl_1", "disconnection_spec",
  "signal_list", "signal_list_1", "signal_list_2", "attribute_decl",
  "attribute_spec", "entity_spec", "entity_name_list",
  "entity_name_list_1", "entity_name_list_2", "entity_class",
  "if_generation_scheme", "if_scheme", "if_scheme_2", "if_scheme_1",
  "if_scheme_3", "generation_scheme", "iteration_scheme", "for_scheme",
  "while_scheme", "concurrent_stats", "concurrent_stats_1",
  "concurrent_stats_2", "concurrent_stat", "block_stat", "block_stat_5",
  "block_stat_4", "block_stat_6", "block_stat_3", "block_stat_7",
  "block_stat_2", "block_stat_8", "block_stat_1", "block_stat_0",
  "dot_name", "mark_comp", "comp_1", "vcomp_stat", "comp_inst_stat", "@6",
  "@7", "comp_inst_stat_1", "concurrent_assertion_stat",
  "concurrent_procedure_call", "concurrent_signal_assign_stat",
  "condal_signal_assign", "condal_wavefrms", "wavefrm", "wavefrm_1",
  "wavefrm_2", "wavefrm_element", "wavefrm_element_1", "wavefrm_element_2",
  "target", "opts", "opts_2", "opts_1", "sel_signal_assign",
  "sel_wavefrms", "sel_wavefrms_1", "sel_wavefrms_2", "gen_stat1",
  "generate_statement_body", "generate_stat", "@8", "opstat", "@9",
  "generate_stat_1", "end_stats", "procs_stat", "procs_stat1", "@10",
  "@11", "procs_stat1_3", "procs_stat1_5", "procs_stat1_6",
  "procs_stat1_2", "procs_stat1_4", "procs_stat1_1", "sensitivity_list",
  "sensitivity_list_1", "sensitivity_list_2", "seq_stats", "seq_stats_1",
  "seq_stats_2", "seq_stat", "report_statement", "assertion_stat",
  "assertion_stat_2", "assertion_stat_1", "choice_stat", "choice_stat_1",
  "case_stat", "case_stat_1", "case_stat_2", "case_stat_alternative",
  "exit_stat", "exit_stat_2", "exit_stat_1", "if_stat", "if_stat_2",
  "if_stat_1", "if_stat_3", "loop_stat", "loop_stat_3", "loop_stat_2",
  "loop_stat_1", "next_stat", "next_stat_2", "next_stat_1", "null_stat",
  "procedure_call_stat", "return_stat", "return_stat_1",
  "signal_assign_stat", "variable_assign_stat", "lable",
  "variable_assign_stat_1", "wait_stat", "wait_stat_3", "wait_stat_2",
  "wait_stat_1", "comp_end_dec", "iss", "comp_decl", "comp_decl_2",
  "comp_decl_1", "block_config", "block_config_2", "block_config_3",
  "block_config_1", "block_config_4", "block_spec", "config_item",
  "comp_config", "comp_config_2", "comp_config_1", "config_spec",
  "comp_spec_stat", "comp_spec", "inst_list", "binding_indic",
  "binding_indic_2", "binding_indic_1", "entity_aspect",
  "group_constituent", "group_constituent_list", "group_declaration",
  "group_template_declaration", "entity_class_entry", "tbox",
  "entity_class_entry_list", "group_name", "t_Identifier",
  "t_BitStringLit", "t_StringLit", "t_AbstractLit", "t_CharacterLit",
  "protected_type_declaration", "protected_stats", "protected_stat_decl_1",
  "protected_stat_1", "protected_type_declaration_item",
  "protected_type_body", "protected_body_stats",
  "protected_body_stat_decl_1", "protected_body_stat_1",
  "protected_type_body_declaration_item", "context_ref", "context_decl",
  "context_stat_1", "libustcont_stats", "libustcont_stat",
  "package_instantiation_decl", "subprogram_instantiation_decl",
  "signature", "signature1", "mark_stats", "mark_stats_1", "case_scheme",
  "when_stats_1", "when_stats", "ttend", "conditional_signal_assignment",
  "conditional_waveform_assignment", "else_wave_list",
  "conditional_force_assignment", "selected_signal_assignment",
  "selected_waveform_assignment", "delay_stat", "sel_wave_list",
  "sel_wave_list_1", "selected_force_assignment", "inout_stat",
  "delay_mechanism", "conditional_variable_assignment", "else_stat",
  "selected_variable_assignment", "sel_var_list", "sel_var_list_1",
  "select_name", "interface_subprogram_decl", "iproc", "ifunc",
  "func_name", "return_is", "param", "interface_package_decl",
  "gen_assoc_list", "gen_interface_list", "external_name", "sig_stat",
  "external_pathname", "absolute_pathname", "relative_pathname",
  "pathname_element", "pathname_element_list", "package_path_name",
  "tool_directive", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   387,   388,   389,   390,   391,   392,   393,   394,
     395,   396,   397,   398,   399,   400,   401,   402,   403,   404,
     405,   406,   407,   408,   409,   410,   411,   412,   413,   414,
     415,   416,   417
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   163,   164,   165,   166,   166,   167,   167,   168,   168,
     168,   168,   168,   169,   169,   170,   171,   171,   172,   173,
     173,   174,   175,   175,   176,   176,   176,   176,   176,   176,
     176,   177,   177,   178,   179,   180,   180,   181,   181,   182,
     183,   183,   184,   184,   185,   185,   186,   187,   188,   187,
     189,   190,   189,   189,   191,   191,   192,   193,   193,   193,
     193,   194,   194,   195,   196,   197,   196,   198,   199,   199,
     199,   199,   200,   200,   201,   202,   202,   203,   204,   204,
     204,   204,   205,   205,   205,   206,   207,   207,   207,   207,
     208,   208,   209,   210,   210,   210,   210,   211,   211,   212,
     213,   213,   213,   213,   214,   214,   214,   214,   214,   214,
     214,   215,   215,   215,   215,   215,   215,   215,   215,   215,
     215,   216,   216,   216,   216,   216,   216,   216,   216,   216,
     216,   216,   216,   216,   217,   217,   218,   218,   218,   218,
     218,   218,   218,   218,   218,   218,   218,   218,   219,   219,
     219,   219,   219,   219,   219,   219,   220,   220,   220,   220,
     220,   220,   220,   220,   221,   221,   221,   221,   221,   221,
     221,   221,   222,   222,   222,   222,   223,   223,   224,   226,
     225,   225,   227,   225,   228,   228,   229,   229,   230,   230,
     230,   230,   231,   232,   232,   233,   233,   233,   233,   233,
     233,   233,   234,   234,   235,   236,   236,   237,   237,   238,
     239,   239,   239,   239,   240,   240,   241,   241,   241,   242,
     242,   243,   243,   244,   244,   244,   244,   244,   245,   246,
     246,   247,   248,   248,   248,   249,   249,   250,   251,   251,
     251,   251,   252,   252,   252,   253,   254,   254,   254,   255,
     255,   256,   256,   256,   256,   256,   256,   257,   257,   257,
     257,   257,   257,   257,   257,   257,   257,   257,   257,   257,
     258,   258,   258,   258,   258,   258,   258,   258,   258,   258,
     258,   258,   258,   258,   258,   258,   258,   258,   258,   258,
     258,   258,   258,   258,   258,   258,   258,   259,   259,   259,
     259,   260,   260,   260,   261,   261,   262,   262,   262,   262,
     263,   263,   263,   263,   264,   264,   264,   264,   264,   264,
     265,   265,   265,   266,   266,   266,   267,   267,   268,   269,
     269,   269,   270,   270,   271,   272,   272,   272,   272,   272,
     273,   273,   274,   274,   275,   275,   276,   276,   276,   277,
     277,   278,   278,   279,   279,   280,   281,   281,   282,   283,
     283,   283,   284,   284,   284,   285,   285,   286,   286,   286,
     286,   286,   286,   286,   286,   286,   286,   287,   288,   288,
     289,   290,   291,   291,   292,   292,   293,   294,   295,   296,
     297,   297,   298,   299,   300,   301,   301,   302,   303,   303,
     304,   305,   306,   307,   308,   308,   309,   309,   310,   310,
     311,   311,   311,   312,   312,   313,   314,   315,   315,   316,
     317,   317,   318,   318,   319,   319,   320,   320,   321,   322,
     322,   323,   324,   324,   325,   325,   326,   326,   327,   327,
     328,   328,   328,   328,   328,   328,   329,   329,   330,   330,
     331,   331,   332,   332,   333,   333,   334,   334,   335,   335,
     336,   337,   337,   337,   338,   338,   339,   340,   341,   342,
     343,   343,   343,   344,   344,   345,   346,   346,   346,   346,
     346,   346,   346,   346,   346,   346,   346,   346,   346,   346,
     346,   346,   346,   346,   346,   347,   348,   348,   349,   349,
     349,   350,   350,   351,   351,   352,   353,   353,   354,   354,
     355,   356,   357,   357,   358,   359,   359,   359,   359,   359,
     359,   359,   360,   361,   361,   362,   362,   363,   364,   364,
     365,   366,   366,   367,   367,   368,   368,   369,   369,   370,
     370,   371,   371,   372,   373,   373,   373,   375,   374,   376,
     374,   374,   374,   377,   377,   378,   378,   378,   378,   379,
     379,   379,   379,   380,   380,   380,   380,   380,   380,   380,
     380,   381,   382,   382,   382,   383,   383,   384,   384,   385,
     386,   387,   387,   387,   387,   388,   389,   389,   390,   391,
     391,   391,   391,   392,   392,   393,   394,   395,   395,   396,
     397,   397,   397,   398,   400,   399,   401,   401,   402,   399,
     399,   403,   403,   404,   404,   405,   405,   407,   408,   406,
     406,   409,   409,   410,   410,   411,   411,   412,   412,   412,
     413,   414,   414,   414,   415,   416,   416,   417,   418,   419,
     419,   420,   421,   421,   421,   421,   421,   421,   421,   421,
     421,   421,   421,   421,   421,   421,   421,   421,   422,   423,
     424,   424,   425,   425,   426,   426,   427,   427,   427,   428,
     428,   428,   429,   429,   430,   431,   432,   433,   433,   434,
     434,   435,   435,   436,   436,   437,   437,   438,   439,   440,
     440,   441,   441,   442,   442,   443,   444,   444,   445,   445,
     446,   447,   448,   449,   449,   450,   450,   450,   450,   450,
     450,   451,   451,   451,   451,   452,   453,   453,   454,   455,
     455,   456,   456,   457,   457,   458,   458,   458,   458,   458,
     459,   459,   460,   461,   461,   462,   462,   463,   463,   464,
     464,   465,   466,   466,   467,   468,   469,   469,   470,   471,
     471,   472,   472,   472,   472,   473,   473,   474,   474,   474,
     475,   476,   476,   476,   477,   478,   478,   479,   479,   480,
     480,   480,   481,   481,   482,   482,   483,   484,   484,   485,
     486,   486,   487,   487,   488,   488,   489,   490,   491,   492,
     493,   494,   494,   495,   495,   496,   497,   497,   498,   498,
     498,   498,   499,   499,   500,   500,   501,   502,   502,   503,
     504,   505,   505,   506,   506,   507,   507,   508,   508,   508,
     509,   509,   509,   510,   510,   510,   511,   511,   511,   512,
     512,   512,   513,   513,   514,   515,   515,   515,   516,   516,
     517,   517,   518,   518,   519,   519,   520,   520,   520,   520,
     520,   521,   521,   522,   522,   523,   523,   524,   525,   525,
     526,   526,   527,   528,   529,   529,   529,   530,   530,   530,
     531,   531,   532,   532,   532,   533,   534,   534,   535,   536,
     536,   537,   537,   538,   539,   539,   540,   540,   541,   541,
     541,   542,   542,   542,   542,   543,   543,   544,   545,   546,
     547,   547,   547,   548,   548,   548,   549,   549,   550,   550,
     551,   551,   552,   552,   553,   554
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     1,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     2,     0,     1,     2,     1,
       3,     2,     0,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     3,     3,     1,     3,     4,     7,     3,
       0,     1,     0,     2,     0,     2,     1,     0,     0,     4,
       0,     0,     4,     3,     7,     5,     5,     0,     1,     2,
       1,     0,     2,     1,     5,     0,     7,     5,     0,     1,
       1,     2,     0,     2,     1,     5,     5,     3,     0,     1,
       2,     1,     0,     1,     2,     1,     2,     1,     2,     3,
       5,     5,     4,     0,     1,     2,     3,     0,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     4,     1,     1,     2,     0,
       4,     6,     0,     6,     1,     2,     2,     1,     0,     2,
       1,     1,     1,     8,     6,     0,     1,     1,     1,     2,
       2,     2,     0,     2,     1,     4,     3,     0,     2,     2,
       1,     1,     2,     7,     0,     2,     0,     1,     1,     0,
       1,     0,     1,     1,     1,     1,     1,     1,     4,     0,
       2,     2,     4,     3,     3,     0,     2,     2,     3,     1,
       1,     1,     1,     3,     1,     1,     1,     1,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       2,     1,     2,     2,     2,     2,     3,     4,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     2,     2,     1,
       3,     1,     1,     1,     1,     3,     1,     1,     1,     1,
       1,     2,     2,     3,     1,     1,     1,     1,     1,     3,
       1,     1,     1,     1,     1,     1,     1,     1,     3,     1,
       1,     1,     2,     2,     1,     3,     4,     3,     3,     3,
       2,     5,     4,     3,     5,     3,     4,     3,     2,     0,
       1,     0,     1,     3,     1,     2,     0,     2,     2,     1,
       1,     1,     4,     4,     3,     0,     2,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     4,     0,     2,
       2,     6,     2,     1,     0,     2,     1,     2,     4,     7,
       0,     2,     2,     3,     4,     0,     1,     6,     0,     2,
       1,     4,     2,     3,     5,     3,     2,     1,     0,     1,
       3,     2,     3,     0,     1,     2,     4,     0,     2,     2,
       1,     1,     1,     3,     1,     3,     1,     1,     6,     0,
       2,     7,     0,     2,     0,     1,     6,     7,     0,     2,
       1,     1,     1,     2,     1,     1,     1,     1,     7,     6,
       1,     1,     0,     2,     8,     6,     0,     4,     0,     1,
       7,     2,     1,     1,     0,     2,     2,     5,     7,     4,
       2,     1,     1,     0,     2,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     6,     7,     0,     3,
       4,     0,     2,     4,     5,     1,     1,     1,     4,     5,
       2,     1,     0,     2,     1,     1,     1,     1,     1,     1,
       1,     1,    14,     0,     1,     0,     2,     1,     0,     4,
       4,     0,     4,     0,     4,     0,     4,     0,     1,     1,
       3,     2,     1,     3,     1,     1,     1,     0,     9,     0,
       8,     8,     9,     0,     3,     3,     1,     4,     2,     3,
       1,     4,     2,     3,     1,     4,     2,     4,     2,     3,
       1,     5,     1,     3,     5,     2,     1,     0,     2,     2,
       2,     0,     2,     2,     1,     2,     1,     1,     2,     0,
       1,     3,     1,     0,     1,     8,     4,     0,     2,     4,
       0,     2,     1,     2,     0,     8,     4,     3,     0,     5,
       3,     1,     2,     2,     3,     3,     1,     0,     0,    11,
       4,     0,     3,     0,     1,     0,     1,     0,     1,     2,
       1,     0,     3,     3,     2,     0,     2,     2,     1,     0,
       2,     1,     1,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     1,     1,     1,     2,     1,     5,     5,
       0,     2,     0,     2,     0,     1,     0,     1,     1,    10,
      11,     6,     0,     2,     1,     4,     4,     0,     2,     0,
       1,     9,     7,     0,     2,     0,     2,     4,     8,     0,
       1,     0,     1,     0,     2,     4,     0,     2,     0,     1,
       2,     2,     3,     0,     1,     4,     5,     6,     5,     1,
       1,     2,     1,     2,     1,     2,     3,     4,     5,     0,
       2,     0,     2,     0,     2,     1,     3,     3,     3,     2,
       0,     1,     7,     0,     3,     0,     3,     7,     5,     0,
       2,     1,     0,     2,     1,     1,     1,     1,     7,     0,
       1,     0,     3,     4,     3,     4,     7,     2,     4,     2,
       3,     1,     1,     1,     3,     0,     3,     0,     3,     2,
       2,     1,     1,     1,     1,     3,     8,     7,     7,     2,
       0,     1,     1,     3,     1,     1,     1,     1,     1,     1,
       1,     4,     4,     0,     2,     1,     1,     2,     1,     1,
       1,     1,     5,     5,     0,     2,     1,     2,     3,     1,
       3,     7,     6,     1,     2,     1,     2,     1,     1,     1,
       7,     8,     6,     7,     8,     6,     0,     3,     2,     2,
       1,     3,     1,     2,     2,     9,     8,     8,     5,     4,
       2,     1,     2,     3,     1,     1,     7,     8,     6,     7,
       4,     4,     2,     9,     8,     1,     1,     8,     0,     1,
       5,     1,     4,     9,     0,     1,     1,     1,     3,     1,
       5,     4,     4,     5,     2,     7,     5,     1,     4,     1,
       1,     1,     1,     3,     7,     6,     1,     1,     0,     2,
       2,     0,     1,     5,     4,     5,     6,     3,     2,     6,
       1,     1,     1,     1,     1,     1,     3,     2,     4,     3,
       1,     4,     2,     3,     2,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
      22,     0,     2,    22,     4,     0,     1,     5,     0,     0,
       0,     0,     0,     0,     0,    21,    23,    31,    32,    24,
       0,    27,     0,    25,     0,    26,     0,    28,     0,    29,
      30,   786,     0,     0,     0,     0,    19,     0,     0,     0,
     788,     0,     0,     0,   321,   320,   327,   325,   324,   326,
     323,   322,     0,     0,     0,    47,     0,     0,     0,     0,
       0,     0,     0,    83,    87,     0,     0,     0,     0,    39,
       0,    33,     0,     0,    77,   900,   901,   902,     0,     0,
      34,     0,   334,     0,   333,     0,   332,     0,     0,     0,
     725,     0,     0,     0,    48,    44,    57,     0,     0,   512,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   177,   176,     0,     0,   915,   110,    62,   100,   102,
     132,   121,    63,     0,   109,     0,   122,   104,   105,   106,
     128,   129,   108,   107,   127,   124,   125,   123,   126,   131,
     130,   101,   103,   133,    68,     0,     0,     0,     0,   173,
      73,    74,   172,     0,   174,    78,     0,   898,    78,     0,
     145,    84,   136,    85,     0,   141,   142,   140,   138,   139,
     137,   144,   143,   146,   147,     0,    86,    88,    93,    93,
      98,   155,   148,    99,   149,   150,   153,   154,   152,   151,
       0,     0,    20,     0,    92,     0,     0,     0,     0,     0,
     903,   904,   905,   327,   790,   331,   329,   328,     6,     7,
     330,     0,   789,   787,     0,    12,     0,   361,     0,     0,
       0,     0,     0,     0,   315,    11,   235,   242,   249,   250,
     271,   314,   320,   327,   316,     0,   317,   318,     0,   422,
     244,    10,     8,     9,   339,   337,   338,   335,     0,   320,
       0,     0,   818,   817,   819,     0,   815,    40,    40,    40,
     729,    37,    53,     0,     0,    42,    60,     0,    58,   452,
     450,   451,     0,     0,     0,   730,     0,   463,   462,   464,
       0,     0,   762,   763,   761,   767,     0,   182,     6,   179,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     178,    70,     0,    69,     0,     0,   745,   742,     0,     0,
      68,    81,     0,    79,     0,   440,   444,     0,     0,     0,
     441,   445,   442,     0,     0,   207,     0,   222,   211,   881,
     882,   210,     0,     0,    89,     0,     0,    94,     0,    56,
      67,     0,   826,   539,   907,     0,     0,   914,     0,     0,
     233,   349,   348,   234,   270,   273,   272,   275,   274,   359,
       0,     0,   356,   360,     0,   427,   426,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     251,   252,   253,   254,   255,   256,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   334,   413,
     411,   340,     0,     0,    18,   336,   813,     0,     0,     0,
     816,   727,    41,   726,   728,    52,     0,   512,     0,    45,
     120,   111,    46,   112,   116,   117,   115,   113,   114,   119,
     118,    59,    55,     0,     0,     0,     0,    57,     0,     0,
       0,   624,     0,   586,   587,   513,   514,   515,   519,   516,
     517,   518,   564,     0,   570,   520,   521,   616,   617,   556,
     560,   326,   731,   735,     0,   461,     0,     0,     0,     0,
       0,   765,     0,   188,     0,   188,     0,   405,     0,   364,
       0,     0,     0,     0,     0,     0,     0,   188,     0,     0,
      71,    64,     0,   739,     0,     0,    80,    75,   206,   886,
     887,   891,     0,   891,   443,     0,     0,     0,    19,    76,
       0,   897,    95,    90,    91,   822,     0,     0,     0,     0,
     912,   906,     0,   909,     0,   408,     0,   407,   350,   351,
     347,     0,   319,     0,     0,   355,   232,     0,   236,   423,
     267,   264,   265,   268,   269,   266,   258,   263,   261,   260,
     259,   262,   296,   295,   294,   293,   292,   291,   285,   287,
     284,   286,   289,   288,   280,   283,   282,   279,   278,   290,
     281,   257,   276,     0,     0,     0,     0,     0,   299,   304,
     310,   424,   415,     0,   345,   414,   412,   410,   354,   343,
       0,   243,   814,   812,   810,     0,    49,    43,     0,   453,
       0,   472,   471,   473,     0,   826,   320,     0,   621,   662,
       0,   566,   568,   558,   562,   701,   593,     0,     0,     0,
     733,   429,     0,   465,   320,     0,   326,     0,     0,     0,
     771,     0,   757,   767,   755,     0,   759,   760,     0,   191,
     190,     0,   187,   184,     0,   192,   180,   434,     0,   362,
       0,     0,     0,     0,     0,     0,   366,   367,   369,   370,
     371,   372,   373,   374,   368,   375,   376,   363,   438,     0,
       0,   784,   785,     0,     0,   195,   639,   163,   156,   204,
     157,   203,   160,   158,   159,   162,   161,     0,   744,     0,
     743,   175,    65,   892,   221,     0,     0,   883,   891,   205,
     221,   208,   219,   247,   241,     0,   240,   229,     0,   239,
     246,   314,    96,   540,     0,   828,   832,     0,   830,   820,
       0,     0,   913,   908,   332,   406,   899,   352,   346,   277,
     342,   353,     0,   357,   237,   297,   298,   312,   311,   301,
     302,   303,     0,     0,   307,   308,   309,   306,     0,     0,
     359,     0,   811,    38,     0,   826,   470,     0,     0,   467,
      54,   624,     0,     0,     0,   660,     0,   594,     0,   589,
     631,   537,     0,   546,   544,   545,   624,   547,     0,   563,
     569,     0,     0,   615,   555,   559,   610,     0,     0,     0,
       0,     0,   466,     0,   458,     0,     0,   768,   770,   769,
       0,   765,     0,     0,   186,   189,     0,   185,     0,   826,
     446,   447,   432,   435,   404,   402,     0,     0,     0,     0,
     398,     0,     0,     0,   378,    14,    13,     0,     0,     0,
       0,   477,   480,   479,   488,   476,   490,   485,   481,   478,
     484,   486,   483,   482,   491,   487,   489,   492,   494,   493,
     780,   782,     0,     0,   438,     0,   197,   198,   196,     0,
       0,   638,   738,     0,     0,   746,   740,   741,   747,    66,
     221,   207,     0,     0,     0,   209,   226,   223,   225,   227,
     224,     0,   220,   248,     0,     0,   320,   827,     0,     0,
     833,   821,   911,   341,   359,   358,   300,   425,   305,   313,
     344,   353,   449,     0,     0,   474,     0,     0,   620,   625,
     663,     0,     0,   586,     0,   576,   581,     0,   572,   577,
     590,   592,     0,   588,     0,   627,   538,   535,     0,     0,
     565,   567,   557,   561,     0,     0,   542,     0,     0,     0,
     505,     0,     0,   495,   736,     0,     0,   430,   428,     0,
     459,     0,     0,   455,   758,   764,     0,   766,   183,   825,
       0,     0,     0,   320,   390,   420,   417,   421,     0,   320,
       0,     0,     0,     0,     0,     0,   798,   800,   799,   794,
     795,   801,     0,   384,     0,   439,   436,     0,   781,   779,
       0,     0,   774,     0,   772,   773,     0,   181,   201,   200,
     199,   194,   195,     0,   679,     0,   698,     0,   703,   723,
       0,     0,   640,   641,   657,   642,   644,   645,   646,   647,
     691,   648,   649,   650,   651,   653,   654,     0,     0,   655,
     326,   710,   844,   845,   709,   855,   856,   712,   714,     0,
     751,   326,   207,     0,   888,   895,     0,   216,   228,     0,
     230,   238,   320,   834,   448,   475,   468,   469,   622,   626,
     661,   659,   593,     0,   584,   580,   571,     0,   575,     0,
       0,   635,     0,   628,     0,     0,   531,     0,     0,     0,
       0,     0,   541,     0,     0,     0,     0,   600,     0,     0,
     326,     0,   609,     0,   734,   732,   460,     0,     0,   756,
     823,     0,   433,   431,     0,     0,     0,   394,     0,     0,
     399,   400,   796,   792,     0,     0,   809,   805,   806,   791,
     377,     0,   379,     0,   387,   778,   777,   783,     0,     0,
     437,     0,     0,   665,     0,   677,   680,     0,   696,   699,
     700,   704,     0,     0,   721,     0,     0,     0,     0,     0,
     692,   506,   507,     0,   664,     0,   643,   652,   656,   713,
       0,   711,   715,   737,     0,   749,   765,     0,   894,     0,
     885,   896,   888,   217,   218,   214,   231,   597,   582,     0,
     583,   573,     0,   578,   591,   632,   634,   633,   639,   171,
     164,   630,   165,   168,   166,   167,   629,   170,   169,     0,
       0,   528,     0,     0,   841,     0,     0,     0,     0,     0,
       0,     0,     0,   715,   602,   134,     0,   512,   600,     0,
     611,   613,     0,     0,     0,   454,   457,   824,   393,     0,
       0,   391,   416,     0,   418,   401,   395,   797,     0,   803,
     802,   380,     0,   385,   386,     0,   776,   775,   193,     0,
       0,     0,     0,     0,     0,     0,   702,   724,     0,   719,
     664,     0,   867,   864,   869,     0,   864,     0,   577,     0,
     716,   660,   510,   639,     0,     0,     0,     0,     0,   750,
       0,     0,   893,   890,   889,   884,     0,   213,     0,     0,
     585,     0,   579,     0,   636,     0,   537,     0,     0,   525,
       0,     0,     0,     0,   840,     0,   553,     0,   543,   553,
       0,     0,   320,   508,   601,   135,     0,   512,   501,   600,
     612,   607,   614,     0,     0,   320,   392,   419,   397,   396,
     807,   383,   381,    16,   666,     0,   678,   676,     0,   685,
     697,   695,   722,     0,     0,     0,   850,   865,   866,     0,
       0,     0,   705,     0,     0,   577,     0,     0,     0,   717,
       0,   871,     0,     0,   754,     0,   752,   215,   595,     0,
     598,   574,   637,   621,   536,   533,     0,     0,     0,   600,
       0,     0,   842,     0,     0,     0,     0,   550,     0,   551,
     509,   605,   603,   498,   501,   606,   389,     0,   808,   382,
       0,     0,    17,   667,     0,   668,     0,   672,     0,   683,
     720,   718,   586,   587,     0,     0,     0,   868,   708,     0,
     706,     0,   658,     0,     0,   874,     0,   870,   753,     0,
       0,     0,     0,   532,     0,   512,   527,   526,     0,   839,
     600,     0,   843,     0,     0,   548,   552,     0,     0,   496,
     502,   498,   388,    15,   671,     0,     0,     0,   639,     0,
       0,   686,   858,     0,     0,   707,     0,   848,     0,     0,
     689,   672,     0,     0,   748,   596,   618,     0,     0,   529,
       0,   837,   838,   836,     0,   554,   600,     0,     0,     0,
       0,   497,   639,     0,   673,   674,   682,   684,     0,     0,
     864,     0,   859,     0,   875,   877,     0,   852,   846,   849,
       0,     0,   690,     0,   872,     0,   599,   619,     0,     0,
       0,   835,   499,   600,   600,     0,   675,   666,   639,     0,
       0,     0,   857,   861,     0,   854,     0,     0,   847,   688,
       0,   873,   534,     0,   523,   500,   503,   600,     0,   687,
     681,   863,     0,     0,   853,   851,   666,   530,     0,   524,
     504,   669,     0,     0,   878,     0,   522,     0,   862,   876,
     670,   860
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,     2,     3,   868,   224,   834,  1410,  1411,   225,
     284,     4,     5,    15,    16,   252,   116,    42,    19,    20,
     421,   428,   265,   429,    95,   264,    55,    93,    21,    22,
     267,    57,   117,    23,   879,    24,   302,    59,   150,   118,
      26,   312,    62,   161,    63,   119,    28,   336,    66,   180,
     120,   121,   432,  1225,  1226,   163,   183,   689,  1201,   151,
     123,   124,   125,   485,   483,   649,   650,   651,   656,   126,
     869,   499,   691,   652,   516,   711,   325,  1297,  1185,   891,
     326,   892,   521,   894,  1060,    86,   364,   548,   717,   226,
     718,   719,   926,   405,   228,   229,   587,   752,   588,   758,
     589,   230,   231,    44,   249,   233,   207,    47,    87,    48,
     234,   235,   236,   237,   540,   738,   360,   361,   545,   743,
     362,   127,   492,   666,   667,   992,  1132,   668,  1342,  1133,
    1253,   993,  1254,   669,  1115,  1241,   974,   670,  1338,   671,
     981,  1120,   830,   672,   673,   128,   975,   735,   537,   596,
     410,   827,  1116,  1244,   976,   363,   977,   367,   129,   801,
     130,   972,   822,   131,   839,   327,   823,   132,   269,   444,
     133,   806,   961,   134,   280,   475,   633,   135,   136,   614,
     615,   766,   915,   860,   952,   953,  1459,  1403,  1460,   949,
    1160,   950,  1162,   273,   274,   455,   456,   457,  1568,  1387,
    1447,  1309,  1489,  1211,  1443,  1086,   937,   342,   947,  1092,
     788,   458,   944,   945,  1396,   459,   460,   461,   462,   927,
     928,  1078,  1193,   929,  1075,  1190,   463,   778,   933,   779,
     464,  1298,  1299,  1380,  1327,  1328,   465,   791,  1102,   792,
    1232,  1103,   466,   467,   627,  1527,   772,   468,  1068,  1084,
    1206,   935,  1082,  1196,  1304,   870,   871,  1022,  1023,  1024,
     469,   922,   775,  1144,  1414,  1026,  1466,  1504,  1505,  1027,
    1262,  1145,  1028,  1470,  1419,  1471,  1029,  1521,  1163,  1030,
    1031,  1265,  1148,  1032,   470,  1034,  1152,  1035,  1036,  1037,
    1038,  1039,  1354,  1269,  1154,    91,   473,   137,   799,   630,
     153,   699,   876,   503,   700,   307,   877,   878,  1290,  1175,
     138,   480,   285,   286,   642,   646,   481,   643,  1002,  1003,
     139,   140,   861,   999,   862,   680,    49,   241,    50,   242,
     243,   675,   833,   989,  1123,   990,   676,   984,  1127,  1249,
    1128,   254,    29,   417,   255,   256,   141,   142,   528,   727,
     728,   900,   796,  1214,  1215,  1315,  1041,  1042,  1478,  1043,
    1044,  1045,  1511,  1542,  1543,  1046,  1359,  1279,  1047,  1372,
    1048,  1514,  1515,  1425,   328,   329,   330,   511,  1180,   705,
     331,   177,   653,    51,    78,   199,   200,   201,   345,   346,
     202,   143
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -1389
static const yytype_int16 yypact[] =
{
   -1389,   294, -1389,   353, -1389,   734, -1389, -1389,   169,   169,
     169,   169,   719,   478,   169, -1389, -1389, -1389, -1389, -1389,
    2398, -1389,   666, -1389,   575, -1389,  2154, -1389,  1728, -1389,
   -1389, -1389,   382,   409,   338,   541, -1389,   169,   169,   462,
   -1389,   129,   597,   311,   758,   758,   607, -1389,   392, -1389,
   -1389, -1389,   542,   543,   118,   532,   574,  1185,   587,   626,
     595,   483,  2496, -1389,   125,   624,  1076,   169,   169, -1389,
     169, -1389,   673,   693,   610, -1389, -1389, -1389,   803,   478,
   -1389,   699, -1389,  1902, -1389,   134, -1389,   158,  2050,   679,
     890,   625,   659,   483, -1389, -1389,   757,   974,   169, -1389,
     169,   169,   337,   169,   391,   974,   169,   169,   784,   796,
     169, -1389, -1389,   169,   741, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389,   800, -1389,   331, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389, -1389,   167,   169,   127,   410,   169, -1389,
   -1389, -1389, -1389,   812, -1389,   148,  1043, -1389,   148,   799,
   -1389, -1389, -1389, -1389,   702, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389, -1389, -1389,   814, -1389,   744,   334,   334,
   -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389,
     867,   891, -1389,   900, -1389,   169,   169,   169,   785,   818,
   -1389, -1389, -1389,   688, -1389, -1389, -1389, -1389, -1389, -1389,
   -1389,   805, -1389, -1389,   478, -1389,   810, -1389,   120,   120,
     120,   120,   120,  1965, -1389, -1389, -1389,   132,   720,  2170,
     820,   311,   363, -1389, -1389,   848, -1389, -1389,   823, -1389,
     833, -1389,   169, -1389, -1389, -1389, -1389, -1389,   843,   883,
     913,   478, -1389, -1389, -1389,   752, -1389,   169,   169,   169,
   -1389, -1389, -1389,   868,   483,  2544,   169,   873, -1389,   880,
   -1389, -1389,   145,  1004,   539,   995,   638, -1389, -1389,   311,
     896,   733, -1389, -1389,   904,   504,   898, -1389,  1003, -1389,
     774,   915,  1019,   921,   119,   788,    71,   169,   974,  2429,
   -1389,   169,   928, -1389,  1016,  1052,   311, -1389,   169,   940,
     167,   169,   943, -1389,   955, -1389, -1389,   974,   169,   169,
   -1389, -1389, -1389,  1026,  1077, -1389,   169, -1389, -1389, -1389,
   -1389, -1389,   963,   977, -1389,  1098,   969, -1389,   975, -1389,
   -1389,   984,   552, -1389,   404,   983,   169,   985,   169,   478,
   -1389,   189, -1389, -1389, -1389,   999, -1389, -1389, -1389,   285,
     997,  1006, -1389, -1389,   892, -1389, -1389,  2050,  2050,  2050,
    2050,  2050,  2050,  2050,  2050,  2050,  2050,  2050,  2050,  2050,
   -1389, -1389, -1389, -1389, -1389, -1389,  2050,  2050,  2050,  2050,
    2050,  2050,  2050,  2050,  2050,  2050,  2050,  2050,  2050,  2050,
    2050,  2050,  2050,  2050,  2050,  2050,   120,  2076,  1005,   467,
   -1389, -1389,  1965,  2050, -1389, -1389,   169,   998,   766,   913,
   -1389, -1389, -1389, -1389, -1389, -1389,  1012, -1389,   543, -1389,
   -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389,   478,  1114,   559,   478,   757,  1136,  2050,
    2050,   313,  1965,   617, -1389, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389,  1038, -1389, -1389, -1389, -1389, -1389, -1389,
   -1389,  1021, -1389,  1138,   478,  1024,   478,   478,  1129,   519,
    1025,  1123,  2050,   369,  1135,   369,   478, -1389,   478, -1389,
    1033,   655,  1034,   478,  1040,   974,   852,   369,  1158,  2576,
   -1389, -1389,  1155,  1112,   815,  1039, -1389, -1389, -1389, -1389,
   -1389,   424,  1150,   424, -1389,   974,   701,   860,   731, -1389,
    1175, -1389,   169, -1389, -1389, -1389,   169,   160,   155,  2050,
   -1389,   404,  1044,   404,   169,   210,  1074, -1389,   661,   685,
   -1389,   120, -1389,  1965,  2050,  1041, -1389,  1965, -1389, -1389,
    2145,  2145,  2145,  2145,  2145,  2145,  2145,  2145,  2145,  2145,
    2145,  2145,  2617,  2617,  2617,  2617,  2617,  2617,  2617,  2617,
    2617,  2617,  2617,  2617,   807,   807,   807, -1389, -1389, -1389,
   -1389,  2145, -1389,   531,   531,   120,   120,   545, -1389,   877,
    1054,   754, -1389,  1965, -1389,   661, -1389, -1389,   274, -1389,
    1050, -1389, -1389, -1389, -1389,  1055, -1389, -1389,  1057, -1389,
     408, -1389, -1389, -1389,  1164,  1053,   722,  1063,   427,  1151,
    1148, -1389, -1389, -1389, -1389, -1389,  1183,  1163,   361,   483,
    1166,  1081,   478, -1389,   184,  1190,    80,   977,   478,   478,
   -1389,   169, -1389,  1197,  1205,  1192, -1389, -1389,   483,   441,
   -1389,  1174, -1389,  1208,   817, -1389, -1389,   380,  1095, -1389,
     478,  1101,  1196,   169,  1308,   970, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389, -1389,  1176, -1389, -1389, -1389,  1103,  2313,
    1104, -1389, -1389,   478,  1194,   760, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389, -1389, -1389, -1389, -1389,  1107, -1389,   826,
   -1389, -1389, -1389,  1110,   909,  1195,  1217, -1389,   424, -1389,
     909, -1389,   806, -1389, -1389,  2050, -1389, -1389,  1115, -1389,
   -1389,   829, -1389, -1389,   478, -1389,   685,  1106,   133, -1389,
    1117,  1125, -1389,   404,   802, -1389, -1389,   661, -1389, -1389,
   -1389,  1127,  1965, -1389, -1389, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389,   531,  2076, -1389, -1389, -1389, -1389,   531,   120,
     351,  2050, -1389, -1389,  1124,   742,  1132,  2050,  1131, -1389,
   -1389, -1389,  1126,  1222,  2050,  1219,   176, -1389,  1995,   516,
    1139,  1247,  1868, -1389, -1389, -1389,   313,   489,   169, -1389,
   -1389,  1257,  1254, -1389, -1389, -1389, -1389,  1145,   483,   543,
    2050,  1146,   311,  2050,   806,  2050,  1147, -1389,   685,   311,
     841,  1123,  1266,   977, -1389, -1389,   478, -1389,  1149,   552,
   -1389, -1389,  1153, -1389, -1389, -1389,  2076,  1251,   478,   872,
   -1389,  1276,  2464,   846, -1389, -1389, -1389,   169,  2050,  1156,
    1160, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389,
    1159, -1389,   894,   970,  1103,   478,  1045,   169, -1389,  1165,
    1277,  2083, -1389,  1281,   440, -1389, -1389, -1389, -1389, -1389,
     909, -1389,   478,   169,  1249, -1389, -1389, -1389, -1389, -1389,
   -1389,   478, -1389, -1389,   910,  1931,   570, -1389,   478,   478,
   -1389, -1389, -1389, -1389,   121, -1389, -1389,   736, -1389, -1389,
   -1389, -1389, -1389,  1168,   974, -1389,  1169,  2334, -1389,   169,
   -1389,  2050,  1178,   311,  1198, -1389,   154,  1182,  1245, -1389,
   -1389, -1389,  2050, -1389,   414,  1295, -1389,  1193,  1303,  1306,
   -1389, -1389, -1389, -1389,  1311,  1290,   500,   592,   169,  1315,
   -1389,  2050,  1322, -1389, -1389,  1201,  1202, -1389, -1389,  1203,
   -1389,  2050,  1314, -1389, -1389, -1389,  1206, -1389,   685, -1389,
     302,  2050,  1207,   344, -1389, -1389, -1389, -1389,   478,   739,
     478,   631,  1252,  1331,  1707,  1252, -1389, -1389, -1389, -1389,
   -1389, -1389,   917, -1389,  1210, -1389, -1389,  1220, -1389, -1389,
    1221,  2334, -1389,   936, -1389, -1389,  1223,   685, -1389, -1389,
   -1389, -1389,   760,  1093,   169,  2050,   169,  1224,  2050,  1318,
    2050,    27, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389,
     708, -1389, -1389, -1389, -1389, -1389, -1389,   291,    68, -1389,
    1226, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389,  1227,
     327,   875, -1389,   764,   312,    75,   478,  1068, -1389,  1175,
   -1389, -1389,   652,   685, -1389, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389,  1183,  2050,  1365, -1389, -1389,  2050,  1229,  1279,
    1233,   311,  1234, -1389,  2611,  2050,  1348,  1386,  1307,  1344,
    1345,   169, -1389,  1350,  1354,   169,    92,  1373,  1359,  2050,
    1259,   110, -1389,  1375, -1389, -1389, -1389,  1262,  2050, -1389,
   -1389,  1263, -1389, -1389,  1360,   959,   971, -1389,  1265,  1347,
   -1389, -1389,   169, -1389,  1310,  1310, -1389, -1389, -1389, -1389,
   -1389,   970, -1389,   636, -1389, -1389, -1389, -1389,  1267,   970,
   -1389,  1268,  1391, -1389,  2050,  1343, -1389,  1353,  1346, -1389,
   -1389, -1389,  1274,   478,  1351,  1368,  1721,  2050,  2050,  2050,
   -1389, -1389, -1389,  1387,  1280,   269, -1389, -1389, -1389, -1389,
    2050, -1389,   668, -1389,   569,  1404,  1123,   778, -1389,    79,
   -1389, -1389,   312, -1389, -1389,  1289, -1389, -1389, -1389,  2050,
   -1389,  1412,  2050, -1389, -1389, -1389,  1292, -1389, -1389, -1389,
   -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389,  1297,
     483,  1393,  1416,  1965, -1389,   347,   977,   977,  1299,   977,
     977,  1414,  2076, -1389, -1389, -1389,  1573, -1389,  1373,  1419,
     169, -1389,  1305,  1312,  1427, -1389, -1389, -1389, -1389,  1413,
     478, -1389, -1389,  2076, -1389, -1389,   169, -1389,  1446, -1389,
   -1389, -1389,  1392, -1389, -1389,  1334, -1389, -1389, -1389,  1447,
    1428,  2050,  1319,  1848,  2050,  1321, -1389, -1389,  2050,  1441,
    1280,  1324, -1389,   484, -1389,  2050,   484,  1325,  1397,  1995,
   -1389,  1219, -1389, -1389,  2050,  2050,    63,   169,  1328, -1389,
    1451,  1330, -1389, -1389, -1389, -1389,  2050, -1389,  1332,  1995,
   -1389,  1995, -1389,   478, -1389,  1453,  1247,  1335,   483, -1389,
    1450,  1336,  1965,   122, -1389,  1458,  1430,  1339, -1389,  1430,
    1341,  2076,   549, -1389, -1389, -1389,  1322, -1389, -1389,  1373,
   -1389, -1389, -1389,  1349,   478,   456, -1389, -1389, -1389, -1389,
     169,   169, -1389,  1495,    73,  1418, -1389, -1389,  1470, -1389,
   -1389, -1389, -1389,  2050,  1356,   176, -1389, -1389, -1389,  2050,
    1400,  1357, -1389,  2050,  1358,  1425,  1361,  1481,  1473, -1389,
    2050, -1389,   102,   853, -1389,  1478, -1389, -1389, -1389,  1435,
   -1389, -1389,   311,   427, -1389,  1482,  1366,  1595,  1427,  1373,
    1367,  1427, -1389,  1369,  1486,  1476,  1372, -1389,  1374, -1389,
   -1389, -1389, -1389,  1105, -1389, -1389, -1389,  1376, -1389, -1389,
    1379,   169, -1389, -1389,  1380, -1389,  1965, -1389,  1499,  1120,
   -1389, -1389,   683,  1384,  1415,  1398,   278, -1389, -1389,   117,
   -1389,  2050, -1389,  1496,  1418,  1462,  2050, -1389, -1389,  1399,
    1965,  1401,  1502, -1389,  1490, -1389, -1389, -1389,  1402, -1389,
    1373,  1403, -1389,  1427,   977, -1389, -1389,   166,  2050, -1389,
   -1389,  1105, -1389, -1389, -1389,  1406,   425,  1408, -1389,  2050,
    1522, -1389,   560,  2050,  2050, -1389,  2050, -1389,  1409,   140,
     169, -1389,  2050,  1483, -1389,  1417, -1389,   977,  1515, -1389,
    1533, -1389, -1389, -1389,  1420, -1389,  1373,  1529,  1259,  1531,
    2050, -1389, -1389,  1547, -1389, -1389, -1389, -1389,  1498,  1534,
     484,  2050, -1389,  1493, -1389, -1389,   147,  1494, -1389, -1389,
    1424,  1429, -1389,   444, -1389,  2050, -1389, -1389,  1433,   977,
    1559, -1389, -1389,  1373,  1373,  1543, -1389,    73, -1389,  1436,
    2050,  1501, -1389, -1389,  1965, -1389,   185,  2050, -1389, -1389,
    1558, -1389, -1389,  1439,   169, -1389, -1389,  1373,  1440, -1389,
   -1389, -1389,  1965,   858, -1389, -1389,    73, -1389,  1442, -1389,
   -1389, -1389,   870,  2050, -1389,  1443, -1389,  2050, -1389, -1389,
   -1389, -1389
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
   -1389, -1389, -1389, -1389,   -41, -1389,   466, -1389, -1389, -1389,
       8,  1584, -1389, -1389, -1389,  1588,    17,  1352, -1389, -1389,
     911, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389,
    1154, -1389, -1389, -1389, -1389, -1389,  1294, -1389, -1389,   139,
   -1389,  1444, -1389, -1389, -1389,  1604, -1389,  1421, -1389, -1389,
     -56,   -46, -1389,   -52, -1389, -1389, -1389,   629, -1389, -1389,
    -105,   777,   -47, -1389, -1389, -1389,   965,    20, -1389,   -24,
     603, -1389, -1389,   -50,  -812, -1389,  -594, -1389, -1389, -1389,
   -1389,   813,  -609, -1389, -1389,   -37, -1389, -1389,   557,  1072,
   -1389,   727,   272, -1389, -1389,  2333,   871, -1389,  -476, -1389,
     865,  -195,  1051, -1389,   101,    81, -1389, -1389,  1582,  -386,
    -265, -1389,  1422, -1389, -1389, -1389,  -325,  -404, -1389, -1389,
     -35, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389, -1389, -1389, -1389,   387, -1389, -1389, -1389,
   -1389, -1389,   656, -1389, -1389, -1389,  -218, -1389,   -70, -1389,
       3, -1389, -1389, -1389,  -857,   -25,  -371,  1046, -1389, -1389,
      19, -1389, -1389,   -29,   775, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389,    22, -1389, -1389, -1389,   -21,   -28, -1389,
   -1389, -1389, -1389,   721, -1389, -1389,   179,   237, -1389, -1389,
   -1389,   616, -1389,  -413, -1389, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389, -1389, -1389, -1389,   341,  -153, -1389, -1389,
   -1389, -1389, -1389, -1389,   330, -1389, -1389, -1389,  -383,   349,
   -1018, -1389, -1389, -1089, -1389, -1389,  -715,   581, -1389, -1389,
    -373, -1389, -1389, -1389,   558, -1208, -1389, -1389,   342, -1389,
   -1162, -1389, -1389,  1029, -1389, -1389,   281,  -600, -1389, -1389,
   -1389, -1389,   514, -1389, -1389, -1141, -1389, -1389, -1389, -1389,
    -405,   388, -1389, -1060,  -951, -1389,   190, -1389, -1181, -1389,
   -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389, -1389, -1389,  -368, -1389, -1389,   635, -1389,  -896,
   -1389,   639, -1389, -1389, -1389,  -363, -1389,  1613, -1389, -1389,
    -643, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389, -1389,
   -1389, -1389,   804, -1389,   503,  -745,  -593, -1389,   546, -1389,
     -27,   -13,   686, -1389, -1389, -1389,    -8, -1389,   -34,   343,
     -69, -1389, -1389, -1389,   706, -1389, -1389, -1389, -1389,   567,
   -1389, -1389, -1389,  1275, -1389,  1438,   173,   -45,  -541, -1389,
   -1389, -1389, -1389,   480, -1389, -1389, -1389, -1389,   217, -1389,
   -1389, -1389, -1389,   123, -1389, -1389, -1206,   225, -1389,   182,
     662, -1388, -1389, -1389, -1389, -1389, -1389,  1186,   520,  -428,
   -1389,  -474,  1678, -1389, -1389, -1389, -1389, -1389,  -271,  1362,
   -1389, -1389
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -911
static const yytype_int16 yytable[] =
{
      32,    33,    34,    36,    39,   122,    52,    84,   600,   454,
     181,   157,   210,   239,   607,   164,   162,   174,   773,    35,
     182,   591,    18,   354,   355,   356,   357,   358,   807,    72,
      73,   152,   154,   166,   169,   171,   592,   185,   187,   188,
     206,   168,   184,   263,   347,   186,   623,   209,   238,   172,
     811,   324,  1095,   189,   730,  1099,   875,  1305,   240,   190,
     191,   924,   192,   271,   287,   608,   965,  1278,   621,  1053,
    1361,   209,  1333,   208,   768,   532,   149,   245,   622,   247,
      31,   165,   260,   624,   167,   707,    31,   599,   268,   270,
     272,  1370,   275,    36,    46,    36,    36,   288,   289,    36,
     292,   294,    36,  1302,  1284,   296,   253,   745,   746,   276,
     881,   281,   175,   494,    45,   290,   885,    31,   295,    92,
     490,  1404,  1349,   212,   204,   213,    40,    31,   305,    31,
    1436,   536,  1222,    40,    31,   805,   303,   304,  1277,   600,
     309,    31,  1367,   594,    25,  1476,  1230,   313,   365,  1170,
     313,    39,  1561,   239,    75,    31,  1021,  1156,  1391,   365,
     203,   491,   175,  1073,  1417,    31,    40,    31,  1476,   214,
     337,   337,   215,    31,    31,  1370,    31,  1157,    30,   817,
      45,  1449,    40,    31,   232,  1579,   454,   343,   344,   343,
    1365,   301,   175,   803,   366,    40,    31,   244,   445,    76,
     898,   160,  1496,    45,   967,   366,  1074,   311,    77,   430,
    1355,   582,   590,  1436,   426,  1371,    40,    31,   740,   431,
    1171,   246,   495,   794,   913,   609,  1448,   724,    46,  1451,
    1413,   526,  -456,  1293,   414,   173,   435,   438,   439,    41,
    1177,   433,  1492,  1223,   437,   789,    41,    45,    45,   422,
     422,   422,   440,  1481,  1437,   790,   631,   497,   441,   635,
     795,  1364,  1231,   532,   209,   -51,   471,   223,   657,  1477,
     658,  -365,   253,   407,  1392,   678,   906,   176,   970,    41,
     884,  1379,   899,   510,   434,  -359,  1052,   436,  1532,    36,
     208,  1494,  1519,   500,     6,    41,   446,    40,    31,  1545,
      36,   365,   303,   506,  1540,   496,   449,   729,    41,   509,
     512,   513,   365,  1164,   538,   351,   504,  1312,   518,    40,
      31,   725,  1165,   452,   232,  1555,  1556,  1507,   449,    41,
      82,    83,    46,   409,   517,   408,    83,  1564,   531,   175,
     533,    31,   239,    40,    31,  -320,   739,   366,   277,  1570,
      40,    31,    45,    -3,  1179,   227,    82,    83,   366,  1474,
     248,  1536,   448,   454,   478,  1323,  -320,    40,    31,    40,
      31,  1019,   595,   299,  1020,    45,   449,  1313,   365,   781,
      69,   942,   239,   782,   783,   784,  1337,  -767,   590,   590,
     747,   748,   785,   335,   278,  -604,   450,  1559,    31,  1156,
    -608,   820,   282,   940,   613,  1174,    61,  1114,   602,   764,
      41,   209,   597,   941,    40,    31,    40,    31,   943,  1285,
      40,    31,  1541,  -623,   366,  1080,   407,  -359,  1213,  -359,
    1475,  1291,    41,   542,  -354,    67,   956,   208,   452,   268,
     591,   305,   825,   687,   450,   821,    40,    31,   283,   786,
     535,   282,   539,   688,  1110,  1503,    41,  1176,    82,    83,
     452,   682,    68,    41,  1400,   864,  1025,    81,  -320,   636,
     692,   694,   695,   239,  1550,   690,   648,   239,   693,  -767,
      41,   510,    41,   300,    40,    31,   696,   681,  1541,  -623,
     408,    83,  -408,  -408,   674,   359,  1111,   283,   734,   910,
    -354,   819,   737,  1033,    74,   655,  1416,   509,   452,   408,
      83,   454,   238,   232,   722,   771,   156,   684,   723,  1407,
     698,   454,   240,   239,  1357,  1416,   733,    41,   308,    41,
     407,   703,  1289,    41,   212,   204,   213,    40,    31,    88,
     448,   478,  1358,   638,   535,    40,    31,   616,   648,  -549,
     639,   529,    45,   232,   449,    40,    31,   590,   590,    41,
    -910,  1497,  1500,   590,   909,    40,    31,  -511,  -511,  -511,
     611,   704,   365,    90,   640,   535,    58,   634,   535,   797,
     214,  1181,   479,   215,    89,  -408,  1558,   535,   156,   535,
     930,   -72,    94,   638,   535,  -408,   836,    41,   814,   324,
     639,  -623,    82,    83,    96,   324,   454,  1316,  1317,   -72,
    1319,  1320,   407,    82,    83,  1575,   612,   144,   366,  -586,
    -511,   931,   450,  -320,   640,   155,   932,   451,   726,  1093,
     156,   590,  1166,    36,  1272,   946,   409,   641,    31,   549,
    1424,   625,   145,    31,   232,    81,   343,  1091,   232,   810,
      41,   209,  1094,   -72,   178,    36,   526,   835,    41,   195,
     146,  1119,   -72,   660,  1510,  1274,  1252,    56,    41,   661,
    1275,   829,   239,  1057,   585,   586,   -61,   208,   223,   749,
     750,   751,   -61,   -61,   598,   601,   452,  1287,   662,   -61,
      70,   -61,   -61,    71,   232,   408,    83,  -408,  -408,   -61,
     -61,   -61,  -694,   204,   147,    40,    31,   905,   526,   250,
     205,    45,   527,   148,  -694,   193,    82,    83,   407,   663,
      37,   619,   620,    11,   598,   -61,    31,   -61,   591,    45,
    1055,  -829,   368,    45,  -694,   194,   -61,   -61,    38,   808,
      45,   -61,   948,   592,   -61,   -61,    79,     8,   955,    80,
    -694,   -61,   -61,   -61,   647,   -61,   -35,    13,     9,   -35,
    1117,   535,  1118,   664,    31,    10,    40,    31,   369,   625,
     266,   370,   454,    81,  1158,   324,   371,   261,    11,   251,
     343,  -324,   419,   773,   535,   291,   164,    70,   991,   474,
    1159,    31,   720,    12,  1005,   866,    11,   293,    82,    83,
      37,   731,   665,    31,   372,   988,    31,  -332,  -332,  1311,
     373,   262,    13,  -831,  1326,   598,   741,  -332,   818,   227,
     297,   867,  -409,  -409,    31,   896,   886,  -324,   -61,   994,
      13,    82,    83,  -879,    14,   298,   591,   -36,  -409,    81,
     -36,  -320,   310,   232,  -409,  1495,   887,   888,  -409,   709,
     986,   889,   251,   710,   300,  1004,   873,   591,  1009,  1010,
     874,   333,   145,  1040,   890,   760,  1051,  -409,    82,    83,
     749,   750,   751,  1065,   769,   343,   985,    45,  1528,  -212,
     209,   105,    70,  -212,   477,    82,    83,    45,  -324,  -324,
    -324,  -403,  -324,  -324,  -324,  -324,   334,    31,    81,  -324,
    -324,    88,   527,   257,    82,    83,   208,   106,  1390,   339,
    -324,  1069,  1178,   258,  1402,    79,   710,   968,   604,   590,
    1553,   259,  -409,    70,    13,   486,  1292,   973,   687,   979,
     710,   111,   112,   340,   315,   591,   734,    70,   688,   493,
    1096,   348,   316,  1100,   317,   401,   402,   403,   404,   341,
    -409,  -409,  -409,   350,  -409,   692,   694,   695,   353,   196,
     690,   197,   198,   693,    70,   406,  1007,   701,   318,   349,
     319,   696,    45,    36,   204,    45,   413,    31,   209,   320,
      40,    31,  -245,  1054,   321,    81,  -360,   893,   322,   829,
      70,   415,   535,   964,   111,   112,   411,   412,   323,  1062,
    1063,    70,    70,   683,   208,  1438,  1146,  1573,  1149,    70,
    1574,   712,  1465,   416,   904,   754,   755,   756,   757,  1577,
     425,    70,  1578,   980,   -19,   442,   -19,   590,  1199,   408,
      83,   443,  1490,   911,   447,    45,  1485,   472,  1200,   916,
     546,   547,  1000,  1001,   314,   484,   920,   476,   590,   482,
    -221,  1008,    31,    70,   939,  1203,  1205,  1207,  1058,  1059,
    1202,   488,   836,  1204,    43,  1130,  1131,   487,   315,   445,
    1005,  1208,   957,   489,   409,   959,   316,   962,   317,   535,
     501,   535,   502,  1218,  1138,  1139,    97,  1221,  1183,  1184,
    1423,   495,    98,  1233,  1142,   507,  -664,  -664,  -664,  -664,
    -664,   101,   318,   508,   319,   514,   179,  1239,  1240,   103,
     995,   105,   515,   320,  1247,   519,  1406,   522,   321,  1242,
    1243,   523,   322,   835,   520,  1255,   590,   524,   111,   112,
      43,  1004,   323,  1457,  1458,    12,   525,   106,    45,   530,
    1563,   526,  -664,   239,   541,  -664,   543,   108,  1468,  1469,
     603,   109,   593,   279,    13,   110,   610,  1182,  1572,   544,
    1307,   111,   112,   113,   606,   114,   618,   720,   626,   423,
     424,  1294,   628,   632,  1325,   629,   637,   644,   212,   204,
     213,    40,    31,   645,   654,   659,   677,   679,   685,   697,
      13,   702,   706,  1070,   736,    97,   742,   306,    43,   759,
     732,    98,    99,   761,  1079,  1100,   767,   762,   100,   763,
     101,   102,  -664,   527,  -664,   770,   776,   774,   103,   104,
     105,   777,  1330,  1098,   214,   780,   798,   215,  -664,  -664,
     713,   800,   804,  1107,   478,   812,  -664,  -664,  1339,   813,
    -664,   816,   239,  1112,    12,   175,   106,   824,   826,   828,
    1143,   863,   837,   838,    45,   107,   108,   880,  1386,   872,
     109,   865,   882,    13,   110,    43,   883,   897,   895,   901,
     111,   112,   113,   902,   114,   903,   912,   714,   918,    36,
     715,   914,   917,    43,   919,   734,   934,  1147,   921,   936,
    1151,   948,  1155,   951,    41,  1373,   218,   954,   958,   963,
     966,   969,    43,   971,   978,  1393,   982,  1012,   996,   831,
     219,   220,   997,   998,   232,  1049,  1056,  1011,   221,   222,
    1064,  1066,   223,  1322,  -793,   453,  1077,   832,  1072,   716,
    1071,   720,  1408,  1409,  1076,  1446,  1415,  1083,  -793,  1087,
    1085,  1335,  1088,  -793,  1322,  1188,   239,   115,  1089,  1191,
    1090,  1097,  1101,  1104,  1105,  1106,  1108,  1209,  1109,  1113,
    1122,  1124,  1134,   212,   204,   213,    40,    31,  1135,  -793,
     239,  1229,  1153,  1136,  1189,  1140,  1150,  1172,  1192,  1173,
    1236,  1195,  1197,    97,  1194,  1210,  -793,  1212,  1213,    98,
    1224,  1216,  1217,  -793,  -793,  1228,   100,  1219,   101,   102,
      43,  1220,    43,  1463,    45,  1234,   103,   104,   105,   214,
    1223,  1246,   215,   232,  1235,  1237,  1260,  1245,  1248,  1256,
    1258,  1259,  1322,   409,  1261,  1263,  1266,  1264,  1268,  1280,
    1281,  1282,    12,  1283,   106,   535,  1270,  1143,   146,  1296,
    1301,  1303,  1286,   107,   108,  1306,  1310,  1318,   109,  1498,
    1100,    13,   110,  1308,  1321,  1329,    45,  1331,   111,   112,
     113,  1300,   114,  1230,  1332,  1340,  1334,  1343,  1341,  1344,
    1345,  1347,  1522,  1351,   239,  1353,  1356,  1362,  1363,    41,
    1374,  1375,  1376,  1383,  1378,   904,  1388,  1385,  1394,  1389,
    1395,  1397,   239,  1399,    43,   583,   584,    43,   212,  1416,
    1418,  1405,   453,   585,   586,  1427,  1431,   223,  1421,  1428,
    1430,  1433,  1439,  1432,  1238,  1434,  1440,   232,  1444,  1442,
    1450,  1452,  1453,  1454,  1455,    43,  1456,    43,    43,  1415,
    1238,  1462,  1464,  1346,  -880,   115,  1350,    43,  1467,    43,
    1352,   232,  1480,  1482,    43,  1472,  1569,  1360,  1473,  1487,
    1488,  1484,  1509,  1486,  1491,  1493,  1368,  1369,  1415,  1502,
    1506,  1518,  1529,  1530,  1525,  1533,  1526,  1534,  1377,  1537,
    1538,   721,  1531,  1539,  1544,  1547,  1548,  1554,    43,  1557,
    1566,  1549,  1562,    97,   904,  1552,    43,     7,  1560,    98,
    1324,  1567,  1571,    17,  1576,  1580,   100,  1251,   101,   102,
     338,   617,   332,   418,   505,    97,   103,   104,   105,    27,
     987,    98,  1445,  1126,   815,  1141,  1186,   960,   100,   744,
     101,   102,  1061,   908,   907,  1420,    85,  1336,   103,   104,
     105,  1426,    12,   753,   106,  1429,   352,  1121,  1067,  1006,
    1501,  1461,  1435,   107,   108,   232,  1161,  1384,   109,  1398,
    1381,    13,   110,  1187,    12,  1227,   106,   793,   111,   112,
     113,   765,   114,   232,  1441,   107,   108,  1267,  1401,  1366,
     109,  1523,  1167,    13,   110,   170,  1168,  1288,  1050,   787,
     111,   112,   113,   802,   114,  1257,  1412,  1137,   904,    43,
     809,  1129,  1250,   420,   605,  1314,  1520,  1512,  1546,  1169,
    1581,   708,  1295,  1479,    64,     0,     0,     0,  1483,     0,
     534,    43,   904,     0,     0,     0,     0,    97,     0,     0,
       0,     0,  1271,    98,   212,   204,   213,    40,    31,    65,
    1499,     0,   101,     0,    43,   115,     0,  1125,   -97,     0,
     103,  1508,   105,     0,   -97,  1513,  1516,     0,  1517,     0,
       0,     0,     0,   -97,  1524,     0,     0,   115,   -97,     0,
       0,   -97,     0,   -97,     0,     0,    12,     0,   106,     0,
     214,     0,  1535,   215,     0,    43,     0,     0,   108,     0,
       0,     0,   109,     0,     0,    13,   110,   -97,     0,   -97,
       0,     0,   111,   112,   113,  1272,   114,  1551,     0,   -97,
       0,     0,     0,   -97,     0,     0,   -97,   -97,     0,     0,
       0,     0,  1513,   -97,   -97,   -97,   904,   -97,   925,  1565,
       0,     0,     0,     0,     0,  1273,  1274,   923,     0,     0,
       0,  1275,  1276,     0,   904,     0,     0,   453,     0,     0,
      41,     0,   218,     0,     0,  1513,     0,     0,     0,  1348,
       0,     0,     0,     0,  -639,  -639,   219,   220,     0,     0,
       0,     0,     0,  -639,   221,   222,     0,    43,   223,   938,
    -639,   212,   204,   213,    40,    31,  -639,  -639,  -639,    43,
    -639,     0,  -639,     0,     0,     0,     0,  -639,     0,     0,
       0,     0,     0,     0,  -639,     0,     0,     0,  -639,     0,
    -639,     0,     0,   211,     0,   212,   204,   213,    40,    31,
       0,     0,     0,     0,  -639,  -639,    43,   214,     0,     0,
     215,     0,   453,     0,     0,   306,     0,     0,  -639,     0,
    -639,  -639,     0,    43,   212,   204,   213,    40,    31,     0,
       0,     0,    43,     0,     0,     0,     0,     0,     0,    43,
      43,   214,     0,     0,   215,     0,     0,   216,     0,   217,
       0,     0,     0,     0,     0,     0,     0,  -639,   212,   204,
     213,    40,    31,     0,     0,     0,     0,     0,     0,     0,
     214,     0,     0,   215,     0,  1081,   713,    41,     0,   218,
       0,     0,     0,     0,     0,  -639,     0,     0,   212,   204,
     213,    40,    31,   219,   220,     0,     0,     0,     0,     0,
       0,   221,   222,     0,   214,   223,     0,   215,     0,     0,
       0,    41,   217,   218,    43,     0,     0,     0,     0,    43,
       0,    43,     0,     0,     0,     0,   715,   219,   220,     0,
       0,     0,     0,     0,   214,   221,   222,   215,     0,   223,
      41,     0,   218,   212,   204,   213,    40,    31,     0,     0,
       0,     0,     0,     0,     0,     0,   219,   220,     0,     0,
       0,     0,     0,     0,   221,   222,     0,     0,   223,   212,
     204,   213,    40,    31,    41,     0,   218,     0,   923,    40,
      31,     0,   925,     0,     0,     0,     0,     0,   449,   214,
     219,   220,   215,     0,     0,  1013,     0,    43,   221,   222,
     721,     0,   223,     0,    41,  1014,   218,  -693,     0,     0,
       0,     0,  1015,     0,     0,   214,     0,     0,   215,  -693,
     219,   220,     0,  1016,     0,  1017,     0,     0,   221,   222,
       0,     0,   223,     0,     0,     0,     0,     0,     0,  -693,
    1018,     0,     0,     0,     0,    60,     0,     0,     0,     0,
       0,     0,     0,  1019,   -82,  -693,  1020,     0,     0,    41,
     -82,   218,     0,     0,     0,     0,     0,   -82,     0,   -82,
     -82,     0,   374,     0,   -82,   219,   220,   -82,     0,   -82,
       0,    61,     0,   221,   222,    41,     0,   223,     0,     0,
       0,     0,    41,     0,  1081,     0,     0,     0,     0,     0,
       0,   583,   584,   -82,     0,   -82,     0,     0,   375,   585,
     586,   376,     0,   223,   -82,   -82,   377,     0,     0,   -82,
     452,     0,   -82,   -82,     0,     0,     0,     0,     0,   -82,
     -82,   -82,     0,   -82,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   378,     0,     0,     0,     0,     0,
     379,   380,   381,   382,   383,   384,   385,   386,   387,   388,
     389,   390,   391,   392,   393,   394,   395,   396,   397,   398,
     399,   400,     0,   401,   402,   403,   404,     0,     0,     0,
       0,    43,   386,   387,   388,   389,   390,   391,   392,   393,
     394,   395,   396,   397,   398,   399,   400,     0,   401,   402,
     403,   404,     0,     0,   840,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   841,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   842,   843,   844,     0,
       0,     0,     0,     0,   845,     0,   846,   841,   847,     0,
       0,     0,     0,     0,  1382,     0,   848,   842,   843,   844,
       0,     0,     0,     0,     0,   845,     0,   846,     0,   847,
       0,     0,   849,    43,   850,     0,     0,   848,     0,     0,
       0,     0,     0,   851,   852,    43,     0,     0,   853,   854,
       0,     0,   855,   849,     0,   850,     0,     0,     0,    53,
     856,     0,     0,     0,   851,   852,  1422,     0,   -50,   853,
     854,     0,     0,   855,   -50,   -50,     0,     0,     0,   857,
       0,   856,   858,   -50,   -50,     0,     0,   859,   -50,     0,
     498,   -50,     0,   -50,     0,    54,     0,     0,     0,  -202,
     857,     0,     0,   858,     0,  -202,  -202,     0,   859,     0,
       0,     0,     0,     0,  -202,     0,     0,   -50,   -50,   -50,
       0,     0,  -202,     0,  -202,   983,     0,     0,   -50,   -50,
       0,     0,     0,   -50,  -804,     0,   -50,   -50,     0,     0,
    -804,     0,     0,   -50,   -50,   -50,     0,   -50,  -202,  -804,
    -202,     0,     0,     0,  -804,     0,     0,  -804,     0,  -804,
    -202,     0,     0,     0,  -202,     0,    97,  -202,  -202,     0,
       0,     0,    98,     0,  -202,  -202,  -202,     0,  -202,   100,
       0,   101,   102,  -804,     0,  -804,   158,     0,     0,   103,
       0,   105,     0,     0,     0,  -804,     0,     0,     0,  -804,
       0,     0,  -804,  -804,     0,     0,     0,     0,     0,  -804,
    -804,  -804,     0,  -804,    97,   159,     0,   106,     0,     0,
      98,   427,     0,     0,     0,     0,   107,   108,     0,   101,
     102,   109,     0,     0,    13,   110,     0,   103,     0,   105,
       0,   111,   112,   113,     0,   114,    97,     0,     0,     0,
       0,     0,    98,   686,     0,     0,     0,     0,     0,     0,
       0,   101,     0,    12,     0,   106,     0,     0,     0,   103,
       0,   105,     0,     0,   107,   108,     0,     0,     0,   109,
       0,    97,    13,   110,     0,     0,     0,    98,  1198,   111,
     112,   113,     0,   114,     0,    12,   101,   106,     0,     0,
       0,     0,     0,     0,   103,     0,   105,   108,     0,     0,
       0,   109,     0,     0,    13,   110,     0,     0,     0,     0,
       0,   111,   112,   113,     0,   114,     0,     0,     0,     0,
      12,     0,   106,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   108,     0,     0,     0,   109,     0,     0,    13,
     110,     0,     0,     0,     0,     0,   111,   112,   113,     0,
     114,   550,   551,   552,   553,   554,   555,   556,   557,   558,
     559,   560,   561,     0,     0,     0,     0,     0,     0,   562,
     563,   564,   565,   566,   567,   568,   569,   570,   571,   572,
     573,   574,   575,   576,   577,   578,   579,   580,   581,  -911,
    -911,  -911,  -911,  -911,  -911,  -911,  -911,  -911,  -911,  -911,
    -911,   398,   399,   400,     0,   401,   402,   403,   404
};

static const yytype_int16 yycheck[] =
{
       8,     9,    10,    11,    12,    57,    14,    44,   412,   274,
      66,    61,    81,    83,   427,    62,    62,    62,   618,    11,
      66,   407,     5,   218,   219,   220,   221,   222,   637,    37,
      38,    59,    59,    62,    62,    62,   407,    66,    66,    66,
      81,    62,    66,    93,   197,    66,   451,    81,    83,    62,
     643,   156,   948,    66,   528,   951,   699,  1198,    83,    67,
      68,   776,    70,    97,   105,   428,   811,  1156,   451,   881,
    1276,   105,  1234,    81,   615,   346,    59,    85,   451,    87,
       7,    62,    90,   451,    62,   513,     7,   412,    96,    97,
      98,    28,   100,   101,    13,   103,   104,   105,   106,   107,
     108,   109,   110,  1192,  1164,   113,    89,   583,   584,   101,
     704,   103,    37,    42,    13,   107,   710,     7,   110,     1,
       1,  1329,  1263,     3,     4,     5,     6,     7,     1,     7,
      28,   349,    40,     6,     7,    55,   144,   145,  1156,   543,
     148,     7,  1283,   408,     5,    28,    36,   155,    27,    81,
     158,   159,  1540,   223,    25,     7,   871,   130,    36,    27,
      79,    42,    37,     9,  1345,     7,     6,     7,    28,    49,
     178,   179,    52,     7,     7,    28,     7,   150,     5,   653,
      79,  1389,     6,     7,    83,  1573,   451,   195,   196,   197,
    1279,    24,    37,     9,    73,     6,     7,    63,    53,    70,
      67,    62,    36,   102,   813,    73,    52,    59,    79,   265,
    1270,   406,   407,    28,   264,   152,     6,     7,   543,   265,
     152,    63,   151,   628,   765,   443,  1388,    67,   147,  1391,
     157,   156,   152,   154,   242,    62,   265,   265,   265,   119,
    1052,   265,  1450,   151,   265,   628,   119,   146,   147,   257,
     258,   259,   265,  1434,   152,   628,   474,   298,   266,   477,
     628,  1279,   152,   534,   298,   147,   274,   147,   486,   152,
     488,   152,   255,    63,   152,   493,   752,   152,   819,   119,
     708,  1299,   149,   317,   265,   153,   880,   265,  1496,   297,
     298,  1453,   152,   301,     0,   119,   151,     6,     7,   152,
     308,    27,   310,   311,  1510,   297,    15,   152,   119,   317,
     318,   319,    27,    22,   351,   214,   308,  1213,   326,     6,
       7,   161,  1037,   147,   223,  1533,  1534,  1468,    15,   119,
     146,   147,   251,   232,   326,   146,   147,   152,   346,    37,
     348,     7,   412,     6,     7,   156,   541,    73,    11,  1557,
       6,     7,   251,     0,    42,    83,   146,   147,    73,    81,
      88,  1502,     1,   628,    37,  1222,   156,     6,     7,     6,
       7,    80,   409,    42,    83,   274,    15,    30,    27,    18,
      42,   786,   452,    22,    23,    24,  1243,    60,   583,   584,
     585,   586,    31,    59,    57,    34,    83,  1538,     7,   130,
      39,    21,    11,   786,   445,    78,    37,    63,   416,     1,
     119,   445,   409,   786,     6,     7,     6,     7,   786,   150,
       6,     7,  1511,    62,    73,    11,    63,   153,    81,   155,
     152,  1176,   119,   148,   149,    53,   799,   445,   147,   447,
     826,     1,   660,   499,    83,    65,     6,     7,    57,    88,
     349,    11,   351,   499,   152,    30,   119,  1050,   146,   147,
     147,   495,    53,   119,  1321,   683,   871,   156,   156,   477,
     499,   499,   499,   543,    30,   499,   107,   547,   499,   152,
     119,   515,   119,   152,     6,     7,   499,   495,  1577,    62,
     146,   147,   148,   149,   491,   223,   970,    57,   535,   148,
     149,   654,   539,   871,    42,   485,    81,   515,   147,   146,
     147,   776,   547,   412,   522,    88,   147,   497,   526,    63,
     503,   786,   547,   593,    40,    81,   534,   119,   118,   119,
      63,   107,  1175,   119,     3,     4,     5,     6,     7,   147,
       1,    37,    58,    24,   443,     6,     7,   446,   107,    60,
      31,   147,   451,   452,    15,     6,     7,   752,   753,   119,
     156,  1457,  1458,   758,   759,     6,     7,    28,    29,    30,
      11,   147,    27,    30,    55,   474,     1,   476,   477,   629,
      49,  1055,    78,    52,    42,    36,  1537,   486,   147,   488,
      74,    16,    60,    24,   493,    46,   665,   119,   648,   704,
      31,    62,   146,   147,    30,   710,   871,  1216,  1217,    34,
    1219,  1220,    63,   146,   147,  1566,    57,    30,    73,   130,
      81,   105,    83,   156,    55,    30,   110,    88,   527,    37,
     147,   826,  1037,   641,    74,   788,   535,   118,     7,   367,
    1355,   152,    16,     7,   543,   156,   654,   147,   547,   641,
     119,   685,    60,    78,    30,   663,   156,   665,   119,    49,
      34,    30,    87,     8,   104,   105,    30,     1,   119,    14,
     110,   663,   742,   891,   143,   144,    10,   685,   147,   134,
     135,   136,    16,    17,   412,   413,   147,   118,    33,    23,
     149,    25,    26,   152,   593,   146,   147,   148,   149,    33,
      34,    35,    34,     4,    78,     6,     7,   742,   156,    30,
      11,   610,   160,    87,    46,    42,   146,   147,    63,    64,
       1,   449,   450,    44,   452,    59,     7,    61,  1114,   628,
     883,   161,    12,   632,    66,    42,    70,    71,    19,   638,
     639,    75,    34,  1114,    78,    79,   149,    13,   798,   152,
      82,    85,    86,    87,   482,    89,   149,    78,    24,   152,
     978,   660,   980,   108,     7,    31,     6,     7,    48,   152,
      13,    51,  1037,   156,    66,   880,    56,   152,    44,   100,
     788,    27,    30,  1383,   683,     1,   833,   149,   833,   151,
      82,     7,   520,    59,   863,    35,    44,     1,   146,   147,
       1,   529,   147,     7,    84,   833,     7,   146,   147,  1213,
      90,   152,    78,   161,  1227,   543,   544,   156,     1,   547,
      79,    61,    20,    21,     7,   724,    20,    73,   162,   837,
      78,   146,   147,   150,   100,    35,  1222,   149,    36,   156,
     152,   156,    30,   742,    42,  1454,    40,    41,    46,   148,
     833,    45,   100,   152,   152,   863,    30,  1243,   866,   867,
      34,    47,    16,   871,    58,   593,   874,    65,   146,   147,
     134,   135,   136,   914,   152,   883,    30,   776,  1487,   148,
     914,    35,   149,   152,   151,   146,   147,   786,   134,   135,
     136,   152,   138,   139,   140,   141,   152,     7,   156,   145,
     146,   147,   160,    13,   146,   147,   914,    61,  1312,    42,
     156,   919,   148,    23,  1327,   149,   152,   816,   152,  1114,
    1529,    31,   120,   149,    78,   151,   148,   826,   984,   828,
     152,    85,    86,    42,    25,  1321,   973,   149,   984,   151,
     948,   156,    33,   951,    35,   138,   139,   140,   141,    49,
     148,   149,   150,   148,   152,   984,   984,   984,   148,   156,
     984,   158,   159,   984,   149,   145,   865,   152,    59,   151,
      61,   984,   871,   981,     4,   874,   153,     7,  1012,    70,
       6,     7,   153,   882,    75,   156,   153,   715,    79,   981,
     149,   148,   891,   152,    85,    86,   148,   149,    89,   898,
     899,   149,   149,   151,  1012,   152,  1014,   149,  1016,   149,
     152,   151,  1416,   100,   742,   138,   139,   140,   141,   149,
     152,   149,   152,   151,   149,   152,   151,  1222,  1084,   146,
     147,   151,  1445,   761,    30,   934,  1440,    42,  1084,   767,
     148,   149,   148,   149,     1,    42,   774,   151,  1243,   151,
       7,     6,     7,   149,   782,  1084,  1084,  1084,   148,   149,
    1084,    42,  1131,  1084,    13,   148,   149,   152,    25,    53,
    1139,  1084,   800,   152,   973,   803,    33,   805,    35,   978,
     152,   980,    30,  1091,   148,   149,    10,  1095,    20,    21,
    1355,   151,    16,  1101,     1,   152,     3,     4,     5,     6,
       7,    25,    59,   148,    61,    79,    30,   148,   149,    33,
     838,    35,    35,    70,  1122,   152,  1334,    19,    75,   148,
     149,   152,    79,  1131,   147,  1133,  1321,   152,    85,    86,
      79,  1139,    89,    28,    29,    59,   152,    61,  1037,   156,
    1544,   156,    49,  1213,   145,    52,   149,    71,    28,    29,
     152,    75,   147,   102,    78,    79,    42,  1056,  1562,   153,
    1210,    85,    86,    87,   152,    89,    30,   895,   130,   258,
     259,  1179,   151,   149,  1226,    37,    47,   152,     3,     4,
       5,     6,     7,    60,    49,   152,   152,   147,    30,    34,
      78,   152,    42,   921,   120,    10,   155,   146,   147,   145,
     156,    16,    17,   153,   932,  1213,    42,   152,    23,   152,
      25,    26,   119,   160,   121,   152,    68,    66,    33,    34,
      35,    38,  1230,   951,    49,    62,    60,    52,   135,   136,
      55,   150,    42,   961,    37,    30,   143,   144,  1246,    47,
     147,    67,  1312,   971,    59,    37,    61,   152,   147,    53,
     157,   147,    76,   150,  1153,    70,    71,   147,  1308,   152,
      75,    67,    67,    78,    79,   214,    49,   161,   153,   152,
      85,    86,    87,   148,    89,   148,   152,   102,   152,  1287,
     105,   149,   151,   232,    62,  1322,   147,  1015,    69,    42,
    1018,    34,  1020,    39,   119,  1287,   121,   152,   152,   152,
      34,   152,   251,   150,    53,  1313,    30,    30,   152,     1,
     135,   136,   152,   154,  1213,    34,    67,   152,   143,   144,
     152,   152,   147,  1222,    16,   274,    81,    19,   130,   154,
     152,  1059,  1340,  1341,   152,  1387,  1344,    42,    30,    36,
     147,  1240,    36,    35,  1243,  1073,  1416,   162,    37,  1077,
      60,    36,    30,   152,   152,   152,    42,  1085,   152,   152,
     108,    30,   152,     3,     4,     5,     6,     7,   148,    61,
    1440,  1099,    54,   152,     9,   152,   152,   151,   149,   152,
    1108,   148,   148,    10,   105,    37,    78,     1,    81,    16,
      17,    47,    47,    85,    86,    36,    23,    47,    25,    26,
     349,    47,   351,  1411,  1303,    30,    33,    34,    35,    49,
     151,    64,    52,  1312,   152,   152,  1144,   152,   108,   152,
     152,    30,  1321,  1322,    81,    72,   152,    81,    77,  1157,
    1158,  1159,    59,    46,    61,  1334,    68,   157,    34,   150,
      28,   149,  1170,    70,    71,   148,    30,   148,    75,  1457,
    1458,    78,    79,    60,    40,    36,  1355,   152,    85,    86,
      87,  1189,    89,    36,   152,    19,    53,   133,    76,    22,
      42,   152,  1480,   152,  1544,    34,   152,   152,    81,   119,
     152,    30,   152,    30,   152,  1213,    36,   152,    30,   153,
      60,   152,  1562,   152,   443,   135,   136,   446,     3,    81,
      30,   152,   451,   143,   144,   105,    81,   147,   152,   152,
     152,    30,    34,   152,   154,    42,    81,  1416,   152,    37,
     153,   152,    36,    47,   152,   474,   152,   476,   477,  1537,
     154,   152,   152,  1261,   150,   162,  1264,   486,    39,   488,
    1268,  1440,    46,    81,   493,   130,  1554,  1275,   150,    47,
      60,   152,    30,   152,   152,   152,  1284,  1285,  1566,   153,
     152,   152,    47,    30,    81,    36,   149,    36,  1296,    22,
      72,   520,   152,    39,    81,    81,   152,    18,   527,    36,
      22,   152,    81,    10,  1312,   152,   535,     3,   152,    16,
      17,   152,   152,     5,   152,   152,    23,  1131,    25,    26,
     179,   447,   158,   251,   310,    10,    33,    34,    35,     5,
     833,    16,    17,   984,   649,  1012,  1059,   804,    23,   547,
      25,    26,   895,   758,   753,  1353,    44,  1240,    33,    34,
      35,  1359,    59,   587,    61,  1363,   214,   981,   917,   864,
    1461,  1404,  1370,    70,    71,  1544,  1030,  1306,    75,  1319,
    1301,    78,    79,  1072,    59,  1097,    61,   628,    85,    86,
      87,   610,    89,  1562,  1383,    70,    71,  1153,  1326,  1281,
      75,  1481,  1037,    78,    79,    62,  1037,  1174,   874,   628,
      85,    86,    87,   632,    89,  1139,  1343,  1001,  1416,   638,
     639,   985,  1125,   255,   419,  1215,  1479,  1472,  1516,  1037,
    1577,   515,  1182,  1431,    26,    -1,    -1,    -1,  1436,    -1,
     348,   660,  1440,    -1,    -1,    -1,    -1,    10,    -1,    -1,
      -1,    -1,     1,    16,     3,     4,     5,     6,     7,     1,
    1458,    -1,    25,    -1,   683,   162,    -1,    30,    10,    -1,
      33,  1469,    35,    -1,    16,  1473,  1474,    -1,  1476,    -1,
      -1,    -1,    -1,    25,  1482,    -1,    -1,   162,    30,    -1,
      -1,    33,    -1,    35,    -1,    -1,    59,    -1,    61,    -1,
      49,    -1,  1500,    52,    -1,   724,    -1,    -1,    71,    -1,
      -1,    -1,    75,    -1,    -1,    78,    79,    59,    -1,    61,
      -1,    -1,    85,    86,    87,    74,    89,  1525,    -1,    71,
      -1,    -1,    -1,    75,    -1,    -1,    78,    79,    -1,    -1,
      -1,    -1,  1540,    85,    86,    87,  1544,    89,    97,  1547,
      -1,    -1,    -1,    -1,    -1,   104,   105,   776,    -1,    -1,
      -1,   110,   111,    -1,  1562,    -1,    -1,   786,    -1,    -1,
     119,    -1,   121,    -1,    -1,  1573,    -1,    -1,    -1,     1,
      -1,    -1,    -1,    -1,     6,     7,   135,   136,    -1,    -1,
      -1,    -1,    -1,    15,   143,   144,    -1,   816,   147,     1,
      22,     3,     4,     5,     6,     7,    28,    29,    30,   828,
      32,    -1,    34,    -1,    -1,    -1,    -1,    39,    -1,    -1,
      -1,    -1,    -1,    -1,    46,    -1,    -1,    -1,    50,    -1,
      52,    -1,    -1,     1,    -1,     3,     4,     5,     6,     7,
      -1,    -1,    -1,    -1,    66,    67,   865,    49,    -1,    -1,
      52,    -1,   871,    -1,    -1,   874,    -1,    -1,    80,    -1,
      82,    83,    -1,   882,     3,     4,     5,     6,     7,    -1,
      -1,    -1,   891,    -1,    -1,    -1,    -1,    -1,    -1,   898,
     899,    49,    -1,    -1,    52,    -1,    -1,    55,    -1,    57,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   119,     3,     4,
       5,     6,     7,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      49,    -1,    -1,    52,    -1,   934,    55,   119,    -1,   121,
      -1,    -1,    -1,    -1,    -1,   147,    -1,    -1,     3,     4,
       5,     6,     7,   135,   136,    -1,    -1,    -1,    -1,    -1,
      -1,   143,   144,    -1,    49,   147,    -1,    52,    -1,    -1,
      -1,   119,    57,   121,   973,    -1,    -1,    -1,    -1,   978,
      -1,   980,    -1,    -1,    -1,    -1,   105,   135,   136,    -1,
      -1,    -1,    -1,    -1,    49,   143,   144,    52,    -1,   147,
     119,    -1,   121,     3,     4,     5,     6,     7,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   135,   136,    -1,    -1,
      -1,    -1,    -1,    -1,   143,   144,    -1,    -1,   147,     3,
       4,     5,     6,     7,   119,    -1,   121,    -1,  1037,     6,
       7,    -1,    97,    -1,    -1,    -1,    -1,    -1,    15,    49,
     135,   136,    52,    -1,    -1,    22,    -1,  1056,   143,   144,
    1059,    -1,   147,    -1,   119,    32,   121,    34,    -1,    -1,
      -1,    -1,    39,    -1,    -1,    49,    -1,    -1,    52,    46,
     135,   136,    -1,    50,    -1,    52,    -1,    -1,   143,   144,
      -1,    -1,   147,    -1,    -1,    -1,    -1,    -1,    -1,    66,
      67,    -1,    -1,    -1,    -1,     1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    80,    10,    82,    83,    -1,    -1,   119,
      16,   121,    -1,    -1,    -1,    -1,    -1,    23,    -1,    25,
      26,    -1,    12,    -1,    30,   135,   136,    33,    -1,    35,
      -1,    37,    -1,   143,   144,   119,    -1,   147,    -1,    -1,
      -1,    -1,   119,    -1,  1153,    -1,    -1,    -1,    -1,    -1,
      -1,   135,   136,    59,    -1,    61,    -1,    -1,    48,   143,
     144,    51,    -1,   147,    70,    71,    56,    -1,    -1,    75,
     147,    -1,    78,    79,    -1,    -1,    -1,    -1,    -1,    85,
      86,    87,    -1,    89,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    84,    -1,    -1,    -1,    -1,    -1,
      90,    91,    92,    93,    94,    95,    96,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,    -1,   138,   139,   140,   141,    -1,    -1,    -1,
      -1,  1240,   122,   123,   124,   125,   126,   127,   128,   129,
     130,   131,   132,   133,   134,   135,   136,    -1,   138,   139,
     140,   141,    -1,    -1,     1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    13,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    23,    24,    25,    -1,
      -1,    -1,    -1,    -1,    31,    -1,    33,    13,    35,    -1,
      -1,    -1,    -1,    -1,  1303,    -1,    43,    23,    24,    25,
      -1,    -1,    -1,    -1,    -1,    31,    -1,    33,    -1,    35,
      -1,    -1,    59,  1322,    61,    -1,    -1,    43,    -1,    -1,
      -1,    -1,    -1,    70,    71,  1334,    -1,    -1,    75,    76,
      -1,    -1,    79,    59,    -1,    61,    -1,    -1,    -1,     1,
      87,    -1,    -1,    -1,    70,    71,  1355,    -1,    10,    75,
      76,    -1,    -1,    79,    16,    17,    -1,    -1,    -1,   106,
      -1,    87,   109,    25,    26,    -1,    -1,   114,    30,    -1,
       1,    33,    -1,    35,    -1,    37,    -1,    -1,    -1,    10,
     106,    -1,    -1,   109,    -1,    16,    17,    -1,   114,    -1,
      -1,    -1,    -1,    -1,    25,    -1,    -1,    59,    60,    61,
      -1,    -1,    33,    -1,    35,     1,    -1,    -1,    70,    71,
      -1,    -1,    -1,    75,    10,    -1,    78,    79,    -1,    -1,
      16,    -1,    -1,    85,    86,    87,    -1,    89,    59,    25,
      61,    -1,    -1,    -1,    30,    -1,    -1,    33,    -1,    35,
      71,    -1,    -1,    -1,    75,    -1,    10,    78,    79,    -1,
      -1,    -1,    16,    -1,    85,    86,    87,    -1,    89,    23,
      -1,    25,    26,    59,    -1,    61,    30,    -1,    -1,    33,
      -1,    35,    -1,    -1,    -1,    71,    -1,    -1,    -1,    75,
      -1,    -1,    78,    79,    -1,    -1,    -1,    -1,    -1,    85,
      86,    87,    -1,    89,    10,    59,    -1,    61,    -1,    -1,
      16,    17,    -1,    -1,    -1,    -1,    70,    71,    -1,    25,
      26,    75,    -1,    -1,    78,    79,    -1,    33,    -1,    35,
      -1,    85,    86,    87,    -1,    89,    10,    -1,    -1,    -1,
      -1,    -1,    16,    17,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    25,    -1,    59,    -1,    61,    -1,    -1,    -1,    33,
      -1,    35,    -1,    -1,    70,    71,    -1,    -1,    -1,    75,
      -1,    10,    78,    79,    -1,    -1,    -1,    16,    17,    85,
      86,    87,    -1,    89,    -1,    59,    25,    61,    -1,    -1,
      -1,    -1,    -1,    -1,    33,    -1,    35,    71,    -1,    -1,
      -1,    75,    -1,    -1,    78,    79,    -1,    -1,    -1,    -1,
      -1,    85,    86,    87,    -1,    89,    -1,    -1,    -1,    -1,
      59,    -1,    61,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    71,    -1,    -1,    -1,    75,    -1,    -1,    78,
      79,    -1,    -1,    -1,    -1,    -1,    85,    86,    87,    -1,
      89,   368,   369,   370,   371,   372,   373,   374,   375,   376,
     377,   378,   379,    -1,    -1,    -1,    -1,    -1,    -1,   386,
     387,   388,   389,   390,   391,   392,   393,   394,   395,   396,
     397,   398,   399,   400,   401,   402,   403,   404,   405,   122,
     123,   124,   125,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,   136,    -1,   138,   139,   140,   141
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,   164,   165,   166,   174,   175,     0,   174,    13,    24,
      31,    44,    59,    78,   100,   176,   177,   178,   179,   181,
     182,   191,   192,   196,   198,   202,   203,   208,   209,   505,
     509,     7,   489,   489,   489,   173,   489,     1,    19,   489,
       6,   119,   180,   265,   266,   267,   268,   270,   272,   489,
     491,   546,   489,     1,    37,   189,     1,   194,     1,   200,
       1,    37,   205,   207,   545,     1,   211,    53,    53,    42,
     149,   152,   489,   489,    42,    25,    70,    79,   547,   149,
     152,   156,   146,   147,   248,   271,   248,   271,   147,    42,
      30,   458,     1,   190,    60,   187,    30,    10,    16,    17,
      23,    25,    26,    33,    34,    35,    61,    70,    71,    75,
      79,    85,    86,    87,    89,   162,   179,   195,   202,   208,
     213,   214,   216,   223,   224,   225,   232,   284,   308,   321,
     323,   326,   330,   333,   336,   340,   341,   460,   473,   483,
     484,   509,   510,   554,    30,    16,    34,    78,    87,   179,
     201,   222,   341,   463,   483,    30,   147,   236,    30,    59,
     202,   206,   214,   218,   225,   323,   326,   336,   340,   341,
     460,   483,   484,   509,   510,    37,   152,   544,    30,    30,
     212,   213,   214,   219,   232,   326,   340,   341,   483,   484,
     489,   489,   489,    42,    42,    49,   156,   158,   159,   548,
     549,   550,   553,   268,     4,    11,   167,   269,   489,   491,
     493,     1,     3,     5,    49,    52,    55,    57,   121,   135,
     136,   143,   144,   147,   168,   172,   252,   255,   257,   258,
     264,   265,   267,   268,   273,   274,   275,   276,   283,   311,
     318,   490,   492,   493,    63,   489,    63,   489,   255,   267,
      30,   100,   178,   179,   504,   507,   508,    13,    23,    31,
     489,   152,   152,   236,   188,   185,    13,   193,   489,   331,
     489,   491,   489,   356,   357,   489,   173,    11,    57,   265,
     337,   173,    11,    57,   173,   475,   476,   167,   489,   489,
     173,     1,   489,     1,   489,   173,   489,    79,    35,    42,
     152,    24,   199,   489,   489,     1,   265,   468,   118,   489,
      30,    59,   204,   489,     1,    25,    33,    35,    59,    61,
      70,    75,    79,    89,   223,   239,   243,   328,   537,   538,
     539,   543,   204,    47,   152,    59,   210,   489,   210,    42,
      42,    49,   370,   489,   489,   551,   552,   370,   156,   151,
     148,   267,   275,   148,   264,   264,   264,   264,   264,   255,
     279,   280,   283,   318,   249,    27,    73,   320,    12,    48,
      51,    56,    84,    90,    12,    48,    51,    56,    84,    90,
      91,    92,    93,    94,    95,    96,   122,   123,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,   134,   135,
     136,   138,   139,   140,   141,   256,   145,    63,   146,   267,
     313,   148,   149,   153,   489,   148,   100,   506,   180,    30,
     508,   183,   489,   183,   183,   152,   236,    17,   184,   186,
     213,   214,   215,   232,   323,   326,   336,   340,   341,   483,
     484,   489,   152,   151,   332,    53,   151,    30,     1,    15,
      83,    88,   147,   265,   273,   358,   359,   360,   374,   378,
     379,   380,   381,   389,   393,   399,   405,   406,   410,   423,
     447,   489,    42,   459,   151,   338,   151,   151,    37,    78,
     474,   479,   151,   227,    42,   226,   151,   152,    42,   152,
       1,    42,   285,   151,    42,   151,   173,   167,     1,   234,
     489,   152,    30,   466,   173,   199,   489,   152,   148,   489,
     491,   540,   489,   489,    79,    35,   237,   173,   489,   152,
     147,   245,    19,   152,   152,   152,   156,   160,   511,   147,
     156,   489,   551,   489,   552,   267,   309,   311,   248,   267,
     277,   145,   148,   149,   153,   281,   148,   149,   250,   255,
     258,   258,   258,   258,   258,   258,   258,   258,   258,   258,
     258,   258,   258,   258,   258,   258,   258,   258,   258,   258,
     258,   258,   258,   258,   258,   258,   258,   258,   258,   258,
     258,   258,   264,   135,   136,   143,   144,   259,   261,   263,
     264,   272,   319,   147,   273,   248,   312,   313,   255,   279,
     280,   255,   489,   152,   152,   506,   152,   356,   458,   309,
      42,    11,    57,   167,   342,   343,   267,   193,    30,   255,
     255,   381,   393,   423,   447,   152,   130,   407,   151,    37,
     462,   309,   149,   339,   267,   309,   489,    47,    24,    31,
      55,   118,   477,   480,   152,    60,   478,   255,   107,   228,
     229,   230,   236,   545,    49,   230,   231,   309,   309,   152,
       8,    14,    33,    64,   108,   147,   286,   287,   290,   296,
     300,   302,   306,   307,   313,   494,   499,   152,   309,   147,
     488,   489,   491,   151,   230,    30,    17,   213,   214,   220,
     232,   235,   326,   340,   341,   483,   484,    34,   179,   464,
     467,   152,   152,   107,   147,   542,    42,   542,   540,   148,
     152,   238,   151,    55,   102,   105,   154,   251,   253,   254,
     255,   265,   489,   489,    67,   161,   267,   512,   513,   152,
     544,   255,   156,   489,   248,   310,   120,   248,   278,   264,
     279,   255,   155,   282,   252,   261,   261,   264,   264,   134,
     135,   136,   260,   320,   138,   139,   140,   141,   262,   145,
     255,   153,   152,   152,     1,   265,   344,    42,   511,   152,
     152,    88,   409,   410,    66,   425,    68,    38,   390,   392,
      62,    18,    22,    23,    24,    31,    88,   265,   373,   381,
     393,   400,   402,   406,   423,   447,   515,   236,    60,   461,
     150,   322,   265,     9,    42,    55,   334,   245,   267,   265,
     173,   479,    30,    47,   236,   229,    67,   544,     1,   370,
      21,    65,   325,   329,   152,   309,   147,   314,    53,   173,
     305,     1,    19,   495,   169,   489,   493,    76,   150,   327,
       1,    13,    23,    24,    25,    31,    33,    35,    43,    59,
      61,    70,    71,    75,    76,    79,    87,   106,   109,   114,
     346,   485,   487,   147,   309,    67,    35,    61,   167,   233,
     418,   419,   152,    30,    34,   463,   465,   469,   470,   197,
     147,   239,    67,    49,   542,   239,    20,    40,    41,    45,
      58,   242,   244,   255,   246,   153,   267,   161,    67,   149,
     514,   152,   148,   148,   255,   283,   261,   259,   263,   264,
     148,   255,   152,   511,   149,   345,   255,   151,   152,    62,
     255,    69,   424,   265,   389,    97,   255,   382,   383,   386,
      74,   105,   110,   391,   147,   414,    42,   369,     1,   255,
     381,   393,   423,   447,   375,   376,   370,   371,    34,   352,
     354,    39,   347,   348,   152,   236,   458,   255,   152,   255,
     244,   335,   255,   152,   152,   478,    34,   245,   267,   152,
     511,   150,   324,   267,   299,   309,   317,   319,    53,   267,
     151,   303,    30,     1,   500,    30,   179,   224,   341,   496,
     498,   510,   288,   294,   489,   255,   152,   152,   154,   486,
     148,   149,   481,   482,   489,   493,   327,   267,     6,   489,
     489,   152,    30,    22,    32,    39,    50,    52,    67,    80,
      83,   389,   420,   421,   422,   423,   428,   432,   435,   439,
     442,   443,   446,   447,   448,   450,   451,   452,   453,   454,
     489,   519,   520,   522,   523,   524,   528,   531,   533,    34,
     475,   489,   239,   237,   267,   370,    67,   309,   148,   149,
     247,   254,   267,   267,   152,   167,   152,   346,   411,   489,
     255,   152,   130,     9,    52,   387,   152,    81,   384,   255,
      11,   265,   415,    42,   412,   147,   368,    36,    36,    37,
      60,   147,   372,    37,    60,   452,   489,    36,   255,   452,
     489,    30,   401,   404,   152,   152,   152,   255,    42,   152,
     152,   544,   255,   152,    63,   297,   315,   309,   309,    30,
     304,   305,   108,   497,    30,    30,   220,   501,   503,   497,
     148,   149,   289,   292,   152,   148,   152,   485,   148,   149,
     152,   233,     1,   157,   426,   434,   489,   255,   445,   489,
     152,   255,   449,    54,   457,   255,   130,   150,    66,    82,
     353,   354,   355,   441,    22,   389,   423,   450,   454,   533,
      81,   152,   151,   152,    78,   472,   479,   237,   148,    42,
     541,   544,   267,    20,    21,   241,   251,   390,   255,     9,
     388,   255,   149,   385,   105,   148,   416,   148,    17,   213,
     214,   221,   232,   326,   340,   341,   413,   483,   484,   255,
      37,   366,     1,    81,   516,   517,    47,    47,   489,    47,
      47,   489,    40,   151,    17,   216,   217,   397,    36,   255,
      36,   152,   403,   489,    30,   152,   255,   152,   154,   148,
     149,   298,   148,   149,   316,   152,    64,   489,   108,   502,
     502,   169,    30,   293,   295,   489,   152,   481,   152,    30,
     255,    81,   433,    72,    81,   444,   152,   415,    77,   456,
      68,     1,    74,   104,   105,   110,   111,   383,   386,   530,
     255,   255,   255,    46,   426,   150,   255,   118,   477,   463,
     471,   478,   148,   154,   489,   541,   150,   240,   394,   395,
     255,    28,   386,   149,   417,   418,   148,   236,    60,   364,
      30,   280,   452,    30,   516,   518,   245,   245,   148,   245,
     245,    40,   267,   317,    17,   216,   356,   397,   398,    36,
     489,   152,   152,   403,    53,   267,   299,   317,   301,   489,
      19,    76,   291,   133,    22,    42,   255,   152,     1,   418,
     255,   152,   255,    34,   455,   426,   152,    40,    58,   529,
     255,   529,   152,    81,   383,   386,   424,   418,   255,   255,
      28,   152,   532,   173,   152,    30,   152,   255,   152,   383,
     396,   382,   265,    30,   369,   152,   236,   362,    36,   153,
     280,    36,   152,   489,    30,    60,   377,   152,   377,   152,
     317,   401,   356,   350,   398,   152,   309,    63,   489,   489,
     170,   171,   492,   157,   427,   489,    81,   431,    30,   437,
     255,   152,   265,   273,   389,   536,   255,   105,   152,   255,
     152,    81,   152,    30,    42,   255,    28,   152,   152,    34,
      81,   409,    37,   367,   152,    17,   216,   363,   403,   398,
     153,   403,   152,    36,    47,   152,   152,    28,    29,   349,
     351,   350,   152,   489,   152,   280,   429,    39,    28,    29,
     436,   438,   130,   150,    81,   152,    28,   152,   521,   255,
      46,   431,    81,   255,   152,   280,   152,    47,    60,   365,
     356,   152,   398,   152,   403,   245,    36,   452,   489,   255,
     452,   349,   153,    30,   430,   431,   152,   418,   255,    30,
     104,   525,   530,   255,   534,   535,   255,   255,   152,   152,
     521,   440,   489,   429,   255,    81,   149,   408,   245,    47,
      30,   152,   398,    36,    36,   255,   418,    22,    72,    39,
     529,   386,   526,   527,    81,   152,   532,    81,   152,   152,
      30,   255,   152,   245,    18,   398,   398,    36,   427,   418,
     152,   534,    81,   280,   152,   255,    22,   152,   361,   489,
     398,   152,   280,   149,   152,   427,   152,   149,   152,   534,
     152,   526
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;


  /* User initialization code.  */

{ yydebug=0; }
/* Line 1078 of yacc.c.  */

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 6:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 7:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 8:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 9:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 10:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 11:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 12:

    {(yyval.qstr)="null";;}
    break;

  case 13:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 14:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 15:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 16:

    {(yyval.qstr)="";;}
    break;

  case 17:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 18:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 19:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 20:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+","+(yyvsp[(3) - (3)].qstr);}
    break;

  case 33:

    {
                 if (addLibUseClause((yyvsp[(2) - (3)].qstr)))
                   addVhdlType((yyvsp[(2) - (3)].qstr),getParsedLine(t_LIBRARY),Entry::VARIABLE_SEC,VhdlDocGen::LIBRARY,(yyvsp[(2) - (3)].qstr).data(),0);              
;}
    break;

  case 34:

    {
                 QStringList ql1=QStringList::split(",",(yyvsp[(2) - (3)].qstr),FALSE);
                 for (uint j=0;j<ql1.count();j++)
                 {
                   QStringList ql=QStringList::split(".",ql1[j],FALSE);
                   QCString it=(QCString)ql[1];;
                   if (addLibUseClause(it))
                     addVhdlType(it,getParsedLine(t_USE),Entry::VARIABLE_SEC,VhdlDocGen::USE,it.data(),0);              
                 }
 ;}
    break;

  case 35:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 36:

    {	(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+","+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 39:

    {
                        (yyval.qstr)=(yyvsp[(2) - (3)].qstr);
                        lastEntity=current;
                        addVhdlType((yyval.qstr),getParsedLine(t_ENTITY),Entry::CLASS_SEC,VhdlDocGen::ENTITY,0,0,Public);
                        //fprintf(stderr,"\n entiy %s : at line %d",$$.data(),s_str.yyLineNr);
                      ;}
    break;

  case 47:

    {(yyval.qstr)="";;}
    break;

  case 48:

    {currP=VhdlDocGen::PORT;;}
    break;

  case 49:

    {currP=0;;}
    break;

  case 50:

    {(yyval.qstr)="";;}
    break;

  case 51:

    {currP=VhdlDocGen::GENERIC;;}
    break;

  case 52:

    {currP=0;;}
    break;

  case 53:

    {currP=0;;}
    break;

  case 56:

    {
                        (yyval.qstr)=(yyvsp[(4) - (5)].qstr);
                        (yyval.qstr)+="::";
                        (yyval.qstr)+=(yyvsp[(2) - (5)].qstr);
                         pushLabel((yyvsp[(2) - (5)].qstr));
                        lastCompound=current;
                        addVhdlType((yyval.qstr),getParsedLine(t_ARCHITECTURE),Entry::CLASS_SEC,VhdlDocGen::ARCHITECTURE,0,0,Private);
                      ;}
    break;

  case 61:

    {(yyval.qstr)="";;}
    break;

  case 64:

    {genLabels.resize(0);;}
    break;

  case 65:

    {genLabels.resize(0);;}
    break;

  case 66:

    {
                             confName="";
                         ;}
    break;

  case 67:

    {
                       confName=(yyvsp[(2) - (5)].qstr)+"::"+(yyvsp[(4) - (5)].qstr);
                        addVhdlType((yyvsp[(2) - (5)].qstr).data(),getParsedLine(t_CONFIGURATION),Entry::VARIABLE_SEC,VhdlDocGen::CONFIG,"configuration",(yyvsp[(4) - (5)].qstr).data());
                      ;}
    break;

  case 68:

    {(yyval.qstr)="";;}
    break;

  case 69:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 70:

    { (yyval.qstr)="configuration";;}
    break;

  case 71:

    { (yyval.qstr)=(yyvsp[(2) - (2)].qstr);;}
    break;

  case 72:

    {(yyval.qstr)="";;}
    break;

  case 73:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 74:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 77:

    {
                          lastCompound=current;
                      
                           
         Entry *clone=new Entry(*current);
         clone->section=Entry::NAMESPACE_SEC;
         clone->spec=VhdlDocGen::PACKAGE;
           clone->name=(yyvsp[(2) - (3)].qstr);
         clone->startLine= getParsedLine(t_PACKAGE);
           clone->bodyLine= getParsedLine(t_PACKAGE);
      
         clone->protection=Package;
             current_root->addSubEntry(clone);
                
                      
                        addVhdlType((yyvsp[(2) - (3)].qstr),getParsedLine(t_PACKAGE),Entry::CLASS_SEC,VhdlDocGen::PACKAGE,0,0,Package);
                        //fprintf(stderr,"\n entiy %s : at line %d",$$.data(),s_str.yyLineNr);
                       ;}
    break;

  case 79:

    {lastCompound=0;;}
    break;

  case 80:

    {lastCompound=0;;}
    break;

  case 81:

    {lastCompound=0;;}
    break;

  case 92:

    {
                        (yyval.qstr)=(yyvsp[(3) - (4)].qstr);
                        lastCompound=current;
                        (yyval.qstr).prepend("_");
                        addVhdlType((yyval.qstr),getParsedLine(t_PACKAGE) ,Entry::CLASS_SEC,VhdlDocGen::PACKAGE_BODY,0,0,Protected);
                      ;}
    break;

  case 93:

    {(yyval.qstr)="";lastCompound=0;;}
    break;

  case 94:

    {lastCompound=0;;}
    break;

  case 95:

    {lastCompound=0;;}
    break;

  case 96:

    {lastCompound=0;;}
    break;

  case 97:

    {(yyval.qstr)="";;}
    break;

  case 172:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 173:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 174:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 175:

    { (yyval.qstr)=(yyvsp[(3) - (4)].qstr);;}
    break;

  case 178:

    {currP=0;;}
    break;

  case 179:

    {currP=VhdlDocGen::PROCEDURE; createFunction((yyvsp[(2) - (2)].qstr),currP,0); ;}
    break;

  case 180:

    {  newEntry(); ;}
    break;

  case 182:

    {
  currP=VhdlDocGen::FUNCTION;
  createFunction(0,currP,(yyvsp[(2) - (2)].qstr).data()); 
;}
    break;

  case 183:

    {
  tempEntry=current;
  current->type=(yyvsp[(6) - (6)].qstr); 
  newEntry();
;}
    break;

  case 193:

    { 
  currP=0;
;}
    break;

  case 194:

    { 
  currP=0;
;}
    break;

  case 205:

    {(yyval.qstr)="";;}
    break;

  case 206:

    {(yyval.qstr)="";;}
    break;

  case 210:

    {(yyval.qstr)="";;}
    break;

  case 211:

    {(yyval.qstr)="";;}
    break;

  case 212:

    {(yyval.qstr)="";;}
    break;

  case 213:

    {
                            if (currP!=VhdlDocGen::COMPONENT)
                            {      
                              if (currP==VhdlDocGen::FUNCTION ||  currP==VhdlDocGen::PROCEDURE)
			      {
                                addProto((yyvsp[(1) - (7)].qstr).data(),(yyvsp[(2) - (7)].qstr).data(),(yyvsp[(4) - (7)].qstr).data(),(yyvsp[(5) - (7)].qstr).data(),(yyvsp[(6) - (7)].qstr).data(),(yyvsp[(7) - (7)].qstr).data());
			      }
                              else 
			      {
                                QCString i=(yyvsp[(5) - (7)].qstr)+(yyvsp[(6) - (7)].qstr)+(yyvsp[(7) - (7)].qstr);
                                addVhdlType((yyvsp[(2) - (7)].qstr),s_str.iLine,Entry::VARIABLE_SEC,currP,i.data(),(yyvsp[(4) - (7)].qstr).data());
                              }
                               //   fprintf(stderr,"\n\n <<port  %s  >>\n",$$.data());
                             } // if component
                           ;}
    break;

  case 214:

    {(yyval.qstr)="";;}
    break;

  case 215:

    {(yyval.qstr)=":="+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 216:

    {(yyval.qstr)="";;}
    break;

  case 217:

    {(yyval.qstr)="buffer";;}
    break;

  case 218:

    {(yyval.qstr)="bus";;}
    break;

  case 219:

    {(yyval.qstr)="";;}
    break;

  case 220:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 221:

    {(yyval.qstr)="";;}
    break;

  case 222:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 223:

    {(yyval.qstr)="in";;}
    break;

  case 224:

    {(yyval.qstr)="out";;}
    break;

  case 225:

    {(yyval.qstr)="inout";;}
    break;

  case 226:

    {(yyval.qstr)="buffer";;}
    break;

  case 227:

    {(yyval.qstr)="link";;}
    break;

  case 228:

    {(yyval.qstr)="("+(yyvsp[(2) - (4)].qstr)+")";;}
    break;

  case 229:

    {(yyval.qstr)="";;}
    break;

  case 230:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 231:

    {(yyval.qstr)=", "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 232:

    {     
  QCString str="( "+(yyvsp[(2) - (4)].qstr);
  str.append(" )");
  (yyval.qstr)=str;
;}
    break;

  case 233:

    {(yyval.qstr)="";;}
    break;

  case 234:

    {(yyval.qstr)=" ( open ) ";;}
    break;

  case 235:

    {(yyval.qstr)="";;}
    break;

  case 236:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+"?? "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 237:

    {(yyval.qstr)=","+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 238:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"=>"+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 239:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 240:

    {(yyval.qstr)="<>";;}
    break;

  case 241:

    {(yyval.qstr)="default";;}
    break;

  case 242:

    {      (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 244:

    {  (yyval.qstr)=(yyvsp[(1) - (1)].qstr) ;;}
    break;

  case 245:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 246:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 247:

    {(yyval.qstr)="open";;}
    break;

  case 248:

    {(yyval.qstr)="inertial";;}
    break;

  case 249:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 250:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 270:

    {(yyval.qstr)=" ?? "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 271:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 272:

    {(yyval.qstr)="+"+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 273:

    {(yyval.qstr)="-"+(yyvsp[(2) - (2)].qstr) ;;}
    break;

  case 274:

    {(yyval.qstr)="abs"+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 275:

    {(yyval.qstr)="not "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 276:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ** "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 277:

    {(yyval.qstr)=(yyvsp[(2) - (4)].qstr)+" ** "+(yyvsp[(4) - (4)].qstr);;}
    break;

  case 278:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" mod  "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 279:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" rem "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 280:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" & "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 281:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" * "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 282:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" + "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 283:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" -  "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 284:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" <= "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 285:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" >= "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 286:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" <  "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 287:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" >  "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 288:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ==  "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 289:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" != "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 290:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" /"+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 291:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ?/="+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 292:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ?="+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 293:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ?<"+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 294:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ?>"+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 295:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ?<="+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 296:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" ?>="+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 297:

    { (yyval.qstr) = "-"+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 298:

    { (yyval.qstr) = "+"+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 299:

    { (yyval.qstr) = (yyvsp[(1) - (1)].qstr);;}
    break;

  case 300:

    { (yyval.qstr) = (yyvsp[(1) - (3)].qstr)+" "+(yyvsp[(2) - (3)].qstr)+" "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 301:

    { (yyval.qstr) = "&";;}
    break;

  case 302:

    { (yyval.qstr) = "-";;}
    break;

  case 303:

    { (yyval.qstr) = "+";;}
    break;

  case 304:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 305:

    { (yyval.qstr) = (yyvsp[(1) - (3)].qstr)+" "+(yyvsp[(2) - (3)].qstr)+" "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 306:

    { (yyval.qstr) = "*";;}
    break;

  case 307:

    { (yyval.qstr) = "rem";;}
    break;

  case 308:

    { (yyval.qstr) = "mod";;}
    break;

  case 309:

    { (yyval.qstr) = "/";;}
    break;

  case 310:

    {  (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 311:

    {  (yyval.qstr)="abs "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 312:

    {  (yyval.qstr)="not  "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 313:

    { (yyval.qstr) = (yyvsp[(1) - (3)].qstr)+" ** "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 314:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 315:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 316:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 317:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 318:

    {(yyval.qstr)="";;}
    break;

  case 319:

    {(yyval.qstr)="("+(yyvsp[(2) - (3)].qstr)+")";;}
    break;

  case 320:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 321:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 322:

    {(yyval.qstr)="";;}
    break;

  case 323:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 324:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 325:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 326:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 327:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 328:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"."+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 329:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 330:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 331:

    {(yyval.qstr)="all";;}
    break;

  case 332:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 333:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 334:

    {(yyval.qstr)="'";;}
    break;

  case 335:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"' "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 337:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" '"+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 338:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"' range ";;}
    break;

  case 339:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"' range ";;}
    break;

  case 340:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" ) ";;}
    break;

  case 341:

    {(yyval.qstr)="( "+(yyvsp[(2) - (5)].qstr)+ "=>"+(yyvsp[(4) - (5)].qstr)+" ) ";;}
    break;

  case 342:

    {(yyval.qstr)=" ( "+(yyvsp[(2) - (4)].qstr)+","+(yyvsp[(4) - (4)].qstr);;}
    break;

  case 343:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+","+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 344:

    {(yyval.qstr)=(yyvsp[(1) - (5)].qstr)+"'("+(yyvsp[(4) - (5)].qstr)+" ) ";;}
    break;

  case 345:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"'"+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 353:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"=> "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 354:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 355:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 356:

    {(yyval.qstr)="";;}
    break;

  case 357:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 358:

    {(yyval.qstr)=" | "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 359:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 360:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 361:

    {(yyval.qstr)="others";;}
    break;

  case 362:

    {(yyval.qstr)="";;}
    break;

  case 363:

    {
                             addVhdlType((yyvsp[(2) - (4)].qstr),getParsedLine(t_TYPE),Entry::VARIABLE_SEC,VhdlDocGen::TYPE,0,(yyvsp[(3) - (4)].qstr).data());
                         ;}
    break;

  case 364:

    {(yyval.qstr)="";;}
    break;

  case 365:

    {(yyval.qstr)="";;}
    break;

  case 366:

    {(yyval.qstr)="is "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 367:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 368:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 369:

    {  (yyval.qstr)=(yyvsp[(1) - (1)].qstr); ;}
    break;

  case 370:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 371:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 372:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 373:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 374:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 375:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 376:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 377:

    {(yyval.qstr)="( "+(yyvsp[(2) - (4)].qstr)+" "+(yyvsp[(3) - (4)].qstr)+" )";;}
    break;

  case 378:

    {(yyval.qstr)="";;}
    break;

  case 379:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 380:

    {(yyval.qstr)=","+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 381:

    {
                                                 (yyval.qstr)=(yyvsp[(1) - (6)].qstr);
                                                 current->args=(yyvsp[(3) - (6)].qstr)+"#"+(yyvsp[(4) - (6)].qstr);
                                                 current->args.prepend("units");
                                                 current->spec=VhdlDocGen::UNITS;
                                               ;}
    break;

  case 384:

    {(yyval.qstr)="";;}
    break;

  case 385:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 386:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr)+"#";;}
    break;

  case 387:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr);;}
    break;

  case 388:

    {(yyval.qstr)=(yyvsp[(1) - (4)].qstr)+"="+(yyvsp[(3) - (4)].qstr);}
    break;

  case 389:

    {
  QCString sr1=" array ( "+(yyvsp[(3) - (7)].qstr)+" "+(yyvsp[(4) - (7)].qstr);
  QCString sr2=" ) of "+(yyvsp[(7) - (7)].qstr);

  (yyval.qstr)=sr1+sr2;
;}
    break;

  case 390:

    {(yyval.qstr)="";;}
    break;

  case 391:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+"  "+(yyvsp[(2) - (2)].qstr);}
    break;

  case 392:

    {(yyval.qstr)=", "+(yyvsp[(2) - (2)].qstr);}
    break;

  case 393:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" range<> ";;}
    break;

  case 394:

    {(yyval.qstr)=" array "+(yyvsp[(2) - (4)].qstr)+" of "+(yyvsp[(4) - (4)].qstr);;}
    break;

  case 395:

    {(yyval.qstr)="";;}
    break;

  case 396:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 397:

    {
  QRegExp reg("[\\s]");
  QCString oo=(yyvsp[(2) - (6)].qstr)+" "+(yyvsp[(3) - (6)].qstr); 
  current->spec=VhdlDocGen::RECORD;
  current->args=oo;
   current->args.replace(reg,"%"); 
  current->args.prepend("record");
  (yyval.qstr)=(yyvsp[(2) - (6)].qstr)+" "+(yyvsp[(3) - (6)].qstr);
;}
    break;

  case 398:

    {(yyval.qstr)="";;}
    break;

  case 399:

    {
      (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr); 
    ;}
    break;

  case 400:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 401:

    {(yyval.qstr)=(yyvsp[(1) - (4)].qstr)+":"+(yyvsp[(3) - (4)].qstr)+"#"; ;}
    break;

  case 402:

    {(yyval.qstr)="access "+(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 403:

    {(yyval.qstr)="file of "+(yyvsp[(3) - (3)].qstr); ;}
    break;

  case 404:

    {
                              addVhdlType((yyvsp[(2) - (5)].qstr),getParsedLine(t_SUBTYPE),Entry::VARIABLE_SEC,VhdlDocGen::SUBTYPE,0,(yyvsp[(4) - (5)].qstr).data());
                         ;}
    break;

  case 405:

    {(yyval.qstr)="";;}
    break;

  case 406:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 407:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 408:

    {(yyval.qstr)="";;}
    break;

  case 409:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 410:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" "+(yyvsp[(2) - (3)].qstr)+" "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 411:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 412:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" "+(yyvsp[(2) - (3)].qstr)+" "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 413:

    {(yyval.qstr)="";;}
    break;

  case 414:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 415:

    { (yyval.qstr)="range "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 416:

    { (yyval.qstr)="("+(yyvsp[(2) - (4)].qstr)+" "+(yyvsp[(3) - (4)].qstr)+")";;}
    break;

  case 417:

    {(yyval.qstr)="";;}
    break;

  case 418:

    { (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 419:

    { (yyval.qstr)=","+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 420:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 421:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 422:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 423:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"  "+(yyvsp[(2) - (3)].qstr)+"  "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 424:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 425:

    { (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"  "+(yyvsp[(2) - (3)].qstr)+"  "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 426:

    {(yyval.qstr)=" to ";;}
    break;

  case 427:

    {(yyval.qstr)=" downto ";;}
    break;

  case 428:

    {
                            QCString it=(yyvsp[(4) - (6)].qstr)+" "+(yyvsp[(5) - (6)].qstr);
                          //  fprintf(stderr,"\n currP %d \n",currP);
                            addVhdlType((yyvsp[(2) - (6)].qstr),getParsedLine(t_CONSTANT),Entry::VARIABLE_SEC,VhdlDocGen::CONSTANT,0,it.data());                 
                            ;}
    break;

  case 429:

    {(yyval.qstr)="";;}
    break;

  case 430:

    {(yyval.qstr)=":="+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 431:

    {
                                      QCString s=(yyvsp[(4) - (7)].qstr)+" "+(yyvsp[(6) - (7)].qstr);
                                      addVhdlType((yyvsp[(2) - (7)].qstr),getParsedLine(t_SIGNAL),Entry::VARIABLE_SEC,VhdlDocGen::SIGNAL,0,s.data());
                               ;}
    break;

  case 432:

    {(yyval.qstr)="";;}
    break;

  case 433:

    {(yyval.qstr)=":="+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 434:

    {(yyval.qstr)="";;}
    break;

  case 435:

    {
                                                               (yyval.qstr)=(yyvsp[(1) - (1)].qstr);
                                                            ;}
    break;

  case 436:

    {
                                    (yyval.qstr)=(yyvsp[(2) - (6)].qstr)+":"+(yyvsp[(4) - (6)].qstr)+" "+(yyvsp[(5) - (6)].qstr);
                                    ;}
    break;

  case 437:

    {
                        (yyval.qstr)=(yyvsp[(5) - (7)].qstr)+" "+(yyvsp[(6) - (7)].qstr);
                          addVhdlType((yyvsp[(3) - (7)].qstr),getParsedLine(t_VARIABLE),Entry::VARIABLE_SEC,VhdlDocGen::SHAREDVARIABLE,0,(yyval.qstr).data());   
                      ;}
    break;

  case 438:

    {(yyval.qstr)="";;}
    break;

  case 439:

    {(yyval.qstr)=":="+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 440:

    {(yyval.qstr)="constant";;}
    break;

  case 441:

    {(yyval.qstr)="signal";;}
    break;

  case 442:

    {(yyval.qstr)="variable";;}
    break;

  case 443:

    {(yyval.qstr)="shared";;}
    break;

  case 444:

    {(yyval.qstr)="file";;}
    break;

  case 445:

    {(yyval.qstr)="type";;}
    break;

  case 446:

    {(yyval.qstr)="bus";;}
    break;

  case 447:

    {(yyval.qstr)="register";;}
    break;

  case 448:

    {
                                         QCString s=(yyvsp[(3) - (7)].qstr)+" "+(yyvsp[(5) - (7)].qstr)+(yyvsp[(6) - (7)].qstr);
                                         addVhdlType((yyvsp[(2) - (7)].qstr),getParsedLine(t_ALIAS),Entry::VARIABLE_SEC,VhdlDocGen::ALIAS,0,s.data());   
                        ;}
    break;

  case 449:

    {(yyval.qstr)="";;}
    break;

  case 450:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 451:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 452:

    {(yyval.qstr)="";;}
    break;

  case 453:

    { (yyval.qstr)=","+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 454:

    { 
                                         addVhdlType((yyvsp[(2) - (8)].qstr),getParsedLine(t_FILE),Entry::VARIABLE_SEC,VhdlDocGen::VFILE,0,(yyvsp[(4) - (8)].qstr).data());  
                      ;}
    break;

  case 455:

    {
                                       QCString s=(yyvsp[(4) - (6)].qstr)+" "+(yyvsp[(5) - (6)].qstr);
                                      addVhdlType((yyvsp[(2) - (6)].qstr),getParsedLine(t_FILE),Entry::VARIABLE_SEC,VhdlDocGen::VFILE,0,s.data());  
                           ;}
    break;

  case 456:

    {(yyval.qstr)="";;}
    break;

  case 457:

    {(yyval.qstr)="open "+(yyvsp[(2) - (4)].qstr)+" is "+s_str.qstr; ;}
    break;

  case 458:

    {(yyval.qstr)="";;}
    break;

  case 459:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 467:

    {
                               addVhdlType((yyvsp[(2) - (5)].qstr),getParsedLine(t_ATTRIBUTE),Entry::VARIABLE_SEC,VhdlDocGen::ATTRIBUTE,0,(yyvsp[(4) - (5)].qstr).data());
                              ;}
    break;

  case 468:

    {
                                QCString oo=(yyvsp[(4) - (7)].qstr)+" is "+(yyvsp[(6) - (7)].qstr);
                               addVhdlType((yyvsp[(2) - (7)].qstr),getParsedLine(t_ATTRIBUTE),Entry::VARIABLE_SEC,VhdlDocGen::ATTRIBUTE,0,oo.data());
                              ;}
    break;

  case 470:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 471:

    {(yyval.qstr)="others";;}
    break;

  case 472:

    {(yyval.qstr)="all";;}
    break;

  case 473:

    {(yyval.qstr)="";;}
    break;

  case 474:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 475:

    {(yyval.qstr)=","+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 476:

    {(yyval.qstr)="entity";;}
    break;

  case 477:

    {(yyval.qstr)="architecture";;}
    break;

  case 478:

    {(yyval.qstr)="package";;}
    break;

  case 479:

    {(yyval.qstr)="configuration";;}
    break;

  case 480:

    {(yyval.qstr)="component";;}
    break;

  case 481:

    {(yyval.qstr)="label";;}
    break;

  case 482:

    {(yyval.qstr)="type";;}
    break;

  case 483:

    {(yyval.qstr)="subtype";;}
    break;

  case 484:

    {(yyval.qstr)="procedure";;}
    break;

  case 485:

    {(yyval.qstr)="";;}
    break;

  case 486:

    {(yyval.qstr)="signal";;}
    break;

  case 487:

    {(yyval.qstr)="variable";;}
    break;

  case 488:

    {(yyval.qstr)="constant";;}
    break;

  case 489:

    {(yyval.qstr)="group";;}
    break;

  case 490:

    {(yyval.qstr)="file";;}
    break;

  case 491:

    {(yyval.qstr)="units";;}
    break;

  case 492:

    {(yyval.qstr)="literal";;}
    break;

  case 493:

    {(yyval.qstr)="sequence";;}
    break;

  case 494:

    {(yyval.qstr)="property";;}
    break;

  case 539:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 540:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+"."+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 541:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 542:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 543:

    {(yyval.qstr)="("+(yyvsp[(2) - (3)].qstr)+")";;}
    break;

  case 544:

    {(yyval.qstr)="configur�tion";yyLineNr=s_str.iLine;;}
    break;

  case 545:

    {(yyval.qstr)="entity";yyLineNr=s_str.iLine;;}
    break;

  case 546:

    {(yyval.qstr)="component";yyLineNr=s_str.iLine;;}
    break;

  case 547:

    {yyLineNr=s_str.iLine;;}
    break;

  case 548:

    {
                                addCompInst((yyvsp[(1) - (9)].qstr).data(),(yyvsp[(3) - (9)].qstr).data(),0,yyLineNr);
                               ;}
    break;

  case 549:

    {yyLineNr=s_str.iLine;;}
    break;

  case 550:

    {
                               addCompInst((yyvsp[(1) - (8)].qstr).data(),(yyvsp[(3) - (8)].qstr).data(),0,yyLineNr);
                             ;}
    break;

  case 551:

    {
                                  addCompInst((yyvsp[(1) - (8)].qstr).data(),(yyvsp[(4) - (8)].qstr).data(),(yyvsp[(3) - (8)].qstr).data(),yyLineNr);
                              ;}
    break;

  case 552:

    {
                                addCompInst((yyvsp[(1) - (9)].qstr).data(),(yyvsp[(4) - (9)].qstr).data(),(yyvsp[(3) - (9)].qstr).data(),yyLineNr);
                              ;}
    break;

  case 604:

    { pushLabel((yyvsp[(1) - (2)].qstr)); ;}
    break;

  case 606:

    { popLabel(); ;}
    break;

  case 607:

    { popLabel(); ;}
    break;

  case 608:

    { pushLabel((yyvsp[(1) - (2)].qstr)); ;}
    break;

  case 611:

    {   (yyval.qstr)=""; ;}
    break;

  case 612:

    {   (yyval.qstr)=(yyvsp[(2) - (2)].qstr); ;}
    break;

  case 615:

    {
                                         current->name=(yyvsp[(1) - (3)].qstr);
                                             current->endBodyLine=s_str.yyLineNr;
                                           newEntry();
                                    ;}
    break;

  case 616:

    { 
                                         current->name=VhdlDocGen::getProcessNumber(); 
                                         current->endBodyLine=s_str.yyLineNr;
                                         newEntry();
                                    ;}
    break;

  case 617:

    {currP=VhdlDocGen::PROCESS;;}
    break;

  case 618:

    {currP=0;;}
    break;

  case 619:

    {
                               createFunction(currName,VhdlDocGen::PROCESS,(yyvsp[(4) - (11)].qstr).data());
                            ;}
    break;

  case 620:

    {currP=0;;}
    break;

  case 623:

    {(yyval.qstr)="";;}
    break;

  case 624:

    {(yyval.qstr)="postponed";;}
    break;

  case 625:

    {(yyval.qstr)="";;}
    break;

  case 626:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 631:

    {(yyval.qstr)="";;}
    break;

  case 632:

    {(yyval.qstr)="all";;}
    break;

  case 633:

    {(yyval.qstr)=(yyvsp[(2) - (3)].qstr);;}
    break;

  case 634:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 635:

    {(yyval.qstr)="";;}
    break;

  case 636:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 637:

    {(yyval.qstr)=","+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 725:

    {lastEntity=0;lastCompound=0;genLabels.resize(0);;}
    break;

  case 727:

    {lastCompound=0;genLabels.resize(0);;}
    break;

  case 728:

    {lastEntity=0;genLabels.resize(0);;}
    break;

  case 729:

    {lastEntity=0;lastCompound=0;genLabels.resize(0);;}
    break;

  case 730:

    {currP=VhdlDocGen::COMPONENT;;}
    break;

  case 731:

    {currP=VhdlDocGen::COMPONENT;;}
    break;

  case 732:

    {
                            addVhdlType((yyvsp[(2) - (7)].qstr),getParsedLine(t_COMPONENT),Entry::VARIABLE_SEC,VhdlDocGen::COMPONENT,0,0);
                            currP=0;
                          ;}
    break;

  case 733:

    {(yyval.qstr)="";;}
    break;

  case 734:

    {(yyval.qstr)=(yyvsp[(2) - (3)].qstr);;}
    break;

  case 735:

    {(yyval.qstr)="";;}
    break;

  case 736:

    {(yyval.qstr)=(yyvsp[(2) - (3)].qstr);;}
    break;

  case 737:

    {
           popConfig();
          ;}
    break;

  case 738:

    {(yyval.qstr)="";;}
    break;

  case 739:

    {(yyval.qstr)="";;}
    break;

  case 740:

    {
    (yyval.qstr)=(yyvsp[(1) - (2)].qstr)+"  ";
    ;}
    break;

  case 741:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 742:

    {(yyval.qstr)="";;}
    break;

  case 743:

    {
   (yyval.qstr)=(yyvsp[(1) - (2)].qstr);
  ;}
    break;

  case 744:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 745:

    {
(yyval.qstr)=(yyvsp[(1) - (1)].qstr);
 
 if(levelCounter==0)
  addConfigureNode((yyvsp[(1) - (1)].qstr).data(),NULL,TRUE,FALSE);
 else
   addConfigureNode((yyvsp[(1) - (1)].qstr).data(),NULL,FALSE,FALSE);
;}
    break;

  case 746:

    {
(yyval.qstr)=(yyvsp[(1) - (1)].qstr);
 ;}
    break;

  case 747:

    {
                                                  (yyval.qstr)=(yyvsp[(1) - (1)].qstr);
                                                  ;}
    break;

  case 748:

    {
                           (yyval.qstr)=(yyvsp[(2) - (7)].qstr)+" "+(yyvsp[(3) - (7)].qstr)+" "+(yyvsp[(4) - (7)].qstr);
                           popConfig();
                         ;}
    break;

  case 749:

    {(yyval.qstr)="";;}
    break;

  case 750:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 751:

    {(yyval.qstr)="";;}
    break;

  case 752:

    {(yyval.qstr)="";;}
    break;

  case 753:

    {(yyval.qstr)="";;}
    break;

  case 754:

    {
                                  addConfigureNode(compSpec.data(),(yyvsp[(2) - (3)].qstr).data(),FALSE,FALSE);
                           ;}
    break;

  case 755:

    {addConfigureNode((yyvsp[(2) - (4)].qstr).data(),(yyvsp[(3) - (4)].qstr).data(),TRUE,FALSE,TRUE);currNode->confVhdl=lastCompound->name; ;}
    break;

  case 756:

    {addConfigureNode((yyvsp[(2) - (7)].qstr).data(),(yyvsp[(3) - (7)].qstr).data(),TRUE,FALSE,TRUE);currNode->confVhdl=lastCompound->name; ;}
    break;

  case 757:

    { (yyval.qstr)=(yyvsp[(2) - (2)].qstr);;}
    break;

  case 758:

    {(yyval.qstr)="";;}
    break;

  case 759:

    {(yyval.qstr)="";;}
    break;

  case 760:

    {
               (yyval.qstr)=(yyvsp[(1) - (3)].qstr)+":"+(yyvsp[(3) - (3)].qstr);
                compSpec=(yyval.qstr);
   ;}
    break;

  case 761:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 762:

    {(yyval.qstr)="all";;}
    break;

  case 763:

    {(yyval.qstr)="others";;}
    break;

  case 764:

    {
                               (yyval.qstr)=(yyvsp[(1) - (3)].qstr);
                           ;}
    break;

  case 769:

    {(yyval.qstr)="entity "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 770:

    {(yyval.qstr)="configuration "+ (yyvsp[(2) - (2)].qstr);;}
    break;

  case 771:

    {(yyval.qstr)="open ";;}
    break;

  case 772:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 773:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 774:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 775:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+","+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 776:

    {
                                  // $$=$2+":"+$4+$6;
                                  (yyval.qstr)="("+(yyvsp[(4) - (8)].qstr)+(yyvsp[(6) - (8)].qstr)+")";
                                    addVhdlType((yyvsp[(2) - (8)].qstr),getParsedLine(t_GROUP),Entry::VARIABLE_SEC,VhdlDocGen::GROUP,(yyval.qstr).data(),0);
                                  ;}
    break;

  case 777:

    {
                                   (yyval.qstr)=(yyvsp[(2) - (7)].qstr)+":"+(yyvsp[(5) - (7)].qstr);
                                   addVhdlType((yyvsp[(2) - (7)].qstr),getParsedLine(t_GROUP),Entry::VARIABLE_SEC,VhdlDocGen::GROUP,(yyvsp[(5) - (7)].qstr).data(),0);
                                  ;}
    break;

  case 778:

    {(yyval.qstr)="";;}
    break;

  case 780:

    {(yyval.qstr)="";;}
    break;

  case 781:

    {(yyval.qstr)="<>";;}
    break;

  case 782:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 783:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+","+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 784:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 785:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 786:

    {
  (yyval.qstr)=s_str.qstr;               
  ;}
    break;

  case 787:

    {
  (yyval.qstr)=s_str.qstr;                                     
 ;}
    break;

  case 788:

    {
  (yyval.qstr)=s_str.qstr;                                     
 ;}
    break;

  case 789:

    {
  (yyval.qstr)=s_str.qstr;                                     
 ;}
    break;

  case 790:

    {
  (yyval.qstr)=s_str.qstr;                                     
 ;}
    break;

  case 791:

    {(yyval.qstr)="";;}
    break;

  case 792:

    {(yyval.qstr)="";;}
    break;

  case 802:

    {(yyval.qstr)="";;}
    break;

  case 803:

    {(yyval.qstr)="";;}
    break;

  case 826:

    {(yyval.qstr)="";;}
    break;

  case 827:

    {(yyval.qstr)="["+(yyvsp[(2) - (3)].qstr)+" ]";;}
    break;

  case 828:

    {(yyval.qstr)="[ ]";;}
    break;

  case 829:

    {(yyval.qstr)="return "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 830:

    { (yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 831:

    {(yyval.qstr)=(yyvsp[(1) - (3)].qstr)+" return "+(yyvsp[(3) - (3)].qstr);;}
    break;

  case 832:

    {(yyval.qstr)=(yyvsp[(1) - (1)].qstr);;}
    break;

  case 833:

    {(yyval.qstr)=(yyvsp[(1) - (2)].qstr)+" "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 834:

    {(yyval.qstr)=" , "+(yyvsp[(2) - (2)].qstr);;}
    break;

  case 915:

    {
// fprintf(stderr,"\n  tooldir %s",s_str.qstr.data() );
;}
    break;


/* Line 1267 of yacc.c.  */

      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}




extern FILE* yyout;
extern YYSTYPE vhdlScanYYlval;

void vhdlScanYYerror(const char* /*str*/)
{
 // fprintf(stderr,"\n<---error at line %d  : [ %s]   in file : %s ---->",s_str.yyLineNr,s_str.qstr.data(),s_str.fileName);
 // exit(0);
}

int MyParserVhdl::parse(MyParserVhdl* conv)
{
  myconv=conv;
  return vhdlScanYYparse();
} 

int lex(void)
{
  return myconv->doLex(); 
}

struct s_contVhdl*  getVhdlCont()
{
  return &s_str;
}

Entry* getVhdlCompound()
{
  if (lastEntity) return lastEntity;
  if (lastCompound) return lastCompound;
  return NULL;
}

QList<ConfNode>& getVhdlConfiguration() { return  configL; }
 
static void addCompInst(char *n, char* instName, char* comp,int iLine)
{

  current->spec=VhdlDocGen::COMPONENT_INST;
  current->section=Entry::VARIABLE_SEC;
  current->startLine=iLine;
  current->bodyLine=iLine;
  current->type=instName;                                  // foo:instname e.g proto or work. proto(ttt)
  current->exception=genLabels;                       // |arch|label1:label2...
  current->name=n;                                              // foo  
  current->args=lastCompound->name;             // architecture name
  current->includeName=comp;                          // component/enity/configuration

  //printf(" \n genlable: [%s]  inst: [%s]  name: [%s] \n",genLabels.data(),instName,n);

  if (lastCompound)
  {
    current->args=lastCompound->name;
    if (!findInstant(current->type))
    {   
      initEntry(current);
      instFiles.append(new Entry(*current));
    }
    current->reset();
  }
  else
  {
    newEntry();
  }
}
 
static void pushLabel(QCString label)
{
  genLabels+="|"+label;
}

static void popLabel()
{
  int u=genLabels.findRev("|");
  if (u<0) return;
  genLabels=genLabels.left(u); 
}

static void popConfig()
{ 
  assert(currNode);
  currNode=currNode->prevNode;
  // printf("\n pop arch %s ",currNode->arch.data());
}

static void addConfigureNode(const char* a,const char*b, bool isRoot,bool isLeave,bool inlineConf)
{
  struct ConfNode* co;
  QCString ent,arch,lab;
  ent=a;
  lab =  VhdlDocGen::parseForConfig(ent,arch);

  if (b)
  {
    ent=b;
    lab=VhdlDocGen::parseForBinding(ent,arch);
  }

  co=new ConfNode(a,b,confName.data());
  if (inlineConf)
  {
    co->isInlineConf=TRUE;
  }

  if (isRoot)
  {
    co->isRoot=TRUE;
    configL.append(co);
    currNode=co;
    currNode->prevNode=currNode;
  }
  else if (!isLeave)
  {
    currNode->addNode(co);
    co->prevNode=currNode;
    currNode=co;
  }
  else
  {
    assert(0);
    co=new ConfNode(a,b,confName.data());
    currNode->addNode(co);
  }
}// addConfigure



//------------------------------------------------------------------------------------------------------------
static bool addLibUseClause(const QCString &type)
{
  static bool show=Config_getBool("SHOW_INCLUDE_FILES");
  static bool showIEEESTD=Config_getBool("FORCE_LOCAL_INCLUDES");

  if (!show)  // all libraries and included packages are not shown
  {
    return FALSE;
  }

  if (!showIEEESTD) // all standard packages and libraries are not shown
  {  
    if (type.lower().stripPrefix("ieee")) return FALSE;
    if (type.lower().stripPrefix("std")) return FALSE;
  }  
  return TRUE;
}


static bool isFuncProcProced()
{
  if (currP==VhdlDocGen::FUNCTION || 
      currP==VhdlDocGen::PROCEDURE ||  
      currP==VhdlDocGen::PROCESS
     )
  {
    return TRUE;
  }
  return FALSE;
}


static void initEntry(Entry *e)
{
  e->fileName = s_str.fileName;
  e->lang=SrcLangExt_VHDL;
  initGroupInfo(e);
}

static void addProto(const char *s1,const char *s2,const char *s3,
                     const char *s4,const char *s5,const char *s6)
{
  (void)s3; // avoid unused warning
  (void)s5; // avoid unused warning
  static QRegExp reg("[\\s]");
  QCString name=s2;
  QStringList ql=QStringList::split(",",name,FALSE);

  for (uint u=0;u<ql.count();u++)
  {
    Argument *arg=new Argument;
    arg->name=(QCString)ql[u];
    arg->type=s4;
    arg->defval=s1;
    arg->attrib=s6;
    current->argList->append(arg);
    current->args+=s2;
    current->args+=",";
  }
}

static bool findInstant(QCString inst)
{
  QListIterator<Entry> eli(instFiles);
  Entry *cur;

  for (eli.toFirst();(cur=eli.current());++eli)
  {
    if (stricmp(inst.data(),cur->type.data())==0)
    {
      return TRUE;
    }
  }
  return FALSE;
}//findInst

static void createFunction(const QCString &impure,int spec,
                           const QCString &fname)
{
  int it=0;
  current->bodyLine=getParsedLine(spec);
  current->spec=spec; 
  current->section=Entry::FUNCTION_SEC;
  current->exception=impure;
  if (currP==VhdlDocGen::PROCEDURE)
  {
    current->name=impure;
    it=t_PROCEDURE;
  }
  else
  {
    current->name=fname;
    it=t_FUNCTION;
  }

  if (spec==VhdlDocGen::PROCESS)
  {
    it=t_PROCESS;
    current->args=fname;
    current->name=impure;
    if (!fname.isEmpty())
    { 
      QStringList q1=QStringList::split(',',fname);
      for (uint ii=0;ii<q1.count();ii++)
      {
	Argument *arg=new Argument;
	arg->name=(QCString)q1[ii];    
	current->argList->append(arg);
      }
    }
  }  

  current->startLine=getParsedLine(it);
  current->bodyLine=getParsedLine(it);
}

static void addVhdlType(const QCString &name,int startLine,int section,int spec,
                        const char* args,const char* type,Protection prot)
{
  static QRegExp reg("[\\s]");

  //int startLine=getParsedLine(spec);

  if (isFuncProcProced())
  {
    return;
  }

  // more than one name   ?
  QStringList ql=QStringList::split(",",name,FALSE);

  for (uint u=0;u<ql.count();u++)
  {
    current->name=(QCString)ql[u];
    if (section==Entry::VARIABLE_SEC && 
	!(spec == VhdlDocGen::USE || spec == VhdlDocGen::LIBRARY) 
       )
    {
      current->name.prepend(VhdlDocGen::getRecordNumber());
    }
    current->startLine=startLine;
    current->bodyLine=startLine;
    current->section=section; 
    current->spec=spec;
    current->fileName=s_str.fileName;
    if (current->args.isEmpty())
    {
      current->args=args;
      current->args.replace(reg,"%"); // insert dummy chars because wihte spaces are removed
    }
    current->type=type;
    current->type.replace(reg,"%"); // insert dummy chars because white spaces are removed
    current->protection=prot;
    newEntry();
  }
}

static void newEntry()
{
  if (current->spec==VhdlDocGen::ENTITY       || 
      current->spec==VhdlDocGen::PACKAGE      || 
      current->spec==VhdlDocGen::ARCHITECTURE || 
      current->spec==VhdlDocGen::PACKAGE_BODY
     )
  {
    current_root->addSubEntry(current);
  }
  else
  {
    if (lastCompound) 
    {
      lastCompound->addSubEntry(current);
    }
    else
    {
      if (lastEntity)
      {
	lastEntity->addSubEntry(current);
      }
      else 
      {
	current_root->addSubEntry(current); 
      }
    }
  }
  current = new Entry ;
  initEntry(current);
}


